import { legacyJournal, own, progressFromJournal, put, validateJournal } from './progress-data.js';

async function nativePlugin() {
  const { registerPlugin } = await import('@capacitor/core');
  return registerPlugin('GameProgressJournal');
}

/** Read the previous native journal without creating, upgrading or writing it. */
export function readPreviousNativeJournal(key) {
  return new Promise((resolve, reject) => {
    let request, absent = false, blocked = false;
    try { request = indexedDB.open(`${key}-journal`, 1); }
    catch (error) { reject(new Error('Cannot inspect previous progress; saved data was preserved', { cause: error })); return; }
    request.onupgradeneeded = () => { absent = true; request.transaction.abort(); };
    request.onblocked = () => { blocked = true; reject(new Error('Previous progress is blocked; close other game windows and retry')); };
    request.onerror = () => absent ? resolve(null) : reject(new Error('Cannot read previous progress; retry', { cause: request.error }));
    request.onsuccess = () => {
      const db = request.result;
      if (blocked) { db.close(); return; }
      let tx, value;
      try {
        if (!db.objectStoreNames.contains('progress')) throw new Error('Previous progress journal has no progress store');
        tx = db.transaction('progress', 'readonly');
        tx.objectStore('progress').get('state').onsuccess = event => { value = event.target.result ?? null; };
      } catch (error) { db.close(); reject(error); return; }
      tx.oncomplete = () => { db.close(); resolve(value); };
      tx.onabort = () => { db.close(); reject(new Error('Previous progress could not be read; retry', { cause: tx.error })); };
      tx.onerror = () => {};
    };
  });
}

// Native I/O and previous-version reading are narrow seams for protocol/migration checks.
export function createNativeProgressStore({ key, read, apply }, getPlugin = nativePlugin, readPrevious = readPreviousNativeJournal) {
  let plugin, current, readyPromise;
  const prefix = `${key}-attempt:`;
  const progress = data => progressFromJournal(data, read, apply);
  function accept(serialized) {
    if (typeof serialized !== 'string') throw new Error('Native progress journal returned no record; retry');
    const record = JSON.parse(serialized);
    if (record?.version !== 1 || !Number.isSafeInteger(record.revision) || record.revision < 0) throw new Error('Invalid native progress record; saved data was preserved');
    validateJournal(record.journal);
    JSON.stringify(progress(record.journal));
    if (!current || record.revision >= current.revision) current = record;
    return record;
  }
  function load() {
    if (!current) throw new Error('Progress journal is not ready; retry initialization');
    return progress(current.journal);
  }
  function ready(storage) {
    if (readyPromise) return readyPromise;
    readyPromise = (async () => {
      plugin = await getPlugin();
      const existing = await plugin.load({ key });
      if (existing.record !== null) { accept(existing.record); return; }
      const previous = await readPrevious(key);
      const legacy = legacyJournal(key, storage ?? localStorage);
      let data = legacy;
      if (previous !== null) {
        validateJournal(previous);
        data = JSON.parse(JSON.stringify(previous));
        for (const [id, attempt] of Object.entries(legacy.attempts)) if (!own(data.attempts, id)) put(data.attempts, id, attempt);
      }
      data.base = JSON.stringify(progress(data));
      const baseline = JSON.stringify(data);
      accept((await plugin.load({ key, baseline })).record);
    })().finally(() => { readyPromise = null; });
    return readyPromise;
  }
  async function commit(operation) {
    if (!current || !plugin) throw new Error('Progress journal is not ready; retry initialization');
    const serialized = JSON.stringify(operation);
    const preview = JSON.parse(JSON.stringify(current.journal));
    if (operation.type === 'attempt') {
      if (!own(preview.attempts, operation.attempt.id)) put(preview.attempts, operation.attempt.id, operation.attempt);
    } else put(preview.settings, operation.name, operation.value);
    JSON.stringify(progress(preview));
    const revisionBefore = current.revision;
    const record = accept((await plugin.commit({ key, operation: serialized })).record);
    if (record.revision <= revisionBefore) throw new Error('Native progress commit was not acknowledged; retry');
    return record;
  }
  return {
    ready, load,
    isKey: entry => entry === key || Boolean(entry?.startsWith(prefix)),
    async saveSetting(name, value, storage) {
      if (JSON.stringify(value) === undefined) throw new Error('Cannot save a non-serializable setting');
      const record = await commit({ type: 'setting', name, value });
      if (!own(record.journal.settings, name)) throw new Error('Native progress setting was not committed; retry');
      const latest = load();
      (storage ?? localStorage).setItem(key, JSON.stringify(latest));
      return latest;
    },
    async saveAttempt(attempt, storage) {
      if (!attempt || typeof attempt.id !== 'string' || !attempt.id) throw new Error('Cannot save an attempt without an id');
      const record = await commit({ type: 'attempt', attempt });
      if (!own(record.journal.attempts, attempt.id)) throw new Error('Native progress attempt was not committed; retry');
      const mirror = storage ?? localStorage;
      mirror.setItem(prefix + attempt.id, JSON.stringify(record.journal.attempts[attempt.id]));
      const latest = load();
      mirror.setItem(key, JSON.stringify(latest));
      return latest;
    },
  };
}
