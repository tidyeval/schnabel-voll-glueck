# Shared games architecture

## Objective and scope

Agreed direction, 2026-11-10: one maintained implementation for platform mechanics across Schnabelglück Bucht, Bounce & Boo and Santa’s Meltdown; independently testable gameplay and separately installable/deployable games. User clarification, 2026-11-10: new Phaser + Matter editions live in separate `*-phaser-matter` worktrees. All previous game worktrees, releases, storage namespaces and native app identities remain intact. The original Schnabelglück, Bucht test and isolated playground/lab remain untouched.

Baseline: platform code copied across three games; Bucht and Bounce own requestAnimationFrame loops, and Bucht separately runs Phaser effects. Target for this change: one Phaser-owned loop and real Matter movement/collision in each experimental game, three real lifecycle/PWA consumers, two real attempt-ledger consumers, and no sibling dependency in a fresh build. Check through source ownership, production browser runs and isolated `npm ci`/build. Device performance remains an acceptance gap until measured on hardware; no efficiency gain is claimed.

## Ownership and interfaces

- Phaser owns the scene lifecycle and scheduling in Bucht/Bounce. A game supplies `create(scene)` and `update(now, seconds)`. Fixed timesteps and direct Canvas vector rendering remain game-owned. Matter owns physical integration and collision; controllers retain game rules such as swim speed, hopping, wall kicks and damage. The shared `matter` module exposes the same Phaser-bundled engine to browser and DOM-free tests. No second physics library is installed. Bucht’s effects camera and world drawing use the same scroll. HTML controls and accessible dialogs stay outside the scene.
- `bindLifecycle` owns browser/native focus and gesture registration. Games supply their suspend, foreground and audio activation actions. Returning to the foreground never resumes a paused round automatically. Native back actions remain game-specific.
- `createProgressStore` owns ledger writes, replay and preference merge. Games own keys, schema migration, validation and idempotent `apply`. Exceptions reach the game’s existing visible error handling; failed snapshots retain attempts for retry. Santa keeps its own backend and progress owner.
- `setupPwa` owns install and update state. Downloaded workers wait; games call the returned action only in their menu with no open dialog. Explicit activation is a deliberate user action. Workers keep their existing game/scope cache namespaces, network-first navigation with bounded offline fallback, and cached versioned assets. First installation does not reload the page.
- Audio synthesis, music mixing, haptics choices, movement controllers, scores, levels, artwork and UI remain game-owned. Shared lifecycle provides audio activation/suspension. No generic game inheritance hierarchy, level DSL, backend, editor or registry is added. No shared registry exists in these game repositories.
- Versioned vendored npm archives keep each game independently buildable. Source is edited here; releases are adopted explicitly. Phaser is pinned to 4.2.1. Each new native app has a separate identifier; each web edition uses a new storage/cache namespace and its own hosting scope. Deployment workflows are disabled in the experimental worktrees. Santa uses its local backend with experiment-specific keys; no existing online scores are written.

## Verification

Reference: committed pre-change game behavior, existing model/browser suites and preserved storage keys. Proposed migration criteria implement the user-approved direction, without claiming new gameplay features.

1. All existing model tests and production builds pass. Existing fish routes, bounce control rules and storage migrations provide the comparison. Matter integration changes are calibrated explicitly; the old solver cannot be retained as a fallback. Original files and saved data must remain unchanged.
2. Chromium and WebKit: real keyboard/pointer input, catch/jump, pause, focus loss, settings, resume, restart and durable progress. Check rendered pixels and simulation separately during pause. No application-owned recursive animation loop remains in Bucht/Bounce.
3. Package controls: a normal ledger save/merge passes; duplicate retry adds nothing; failed snapshot throws and later retry banks once. A blocked storage read must propagate, rather than masquerade as a malformed entry. Browser/native lifecycle must suspend and dispose registrations. Removing the suspend registration must make the corresponding check fail.
4. Real two-build update tests: install, delayed public-file-only update, no activation during gameplay/dialog, menu activation, old saves retained, unrelated origin caches retained and offline relaunch. Root and Pages subpaths must work. A manifest-only change must change the cache version; identical input must not.
5. Fresh isolated game checkout with only its tracked package archive: `npm ci` and production build pass without the source package directory.

Automated checks establish technical behavior, not subjective game feel or GPU/battery cost on phones. Record actual results and remaining gaps here after execution.

## Current implementation and next work (2026-11-10)

The three separate Phaser + Matter editions share `@tidyeval/game-platform` 0.2.3. The package is private and adopted through the same vendored archive in each game. Version 0.2.3 refreshes package documentation; its runtime and type files are unchanged from 0.2.2. Original game revisions are recorded in `original-games.json`. Original sources, installation identities, saved data and deployed releases remain separate. No commit, push or deployment has been made.

- **Schnabelglück Bucht:** one Phaser loop controls world drawing and effects. Pip's native Matter body integrates movement; terrain and net shapes use Matter queries. Restart removes the previous body. The adventure, oxygen, energy, catches, levels and artwork stay game-owned.
- **Bounce & Boo:** the scene's Matter engine integrates a compound torso and centre foot. Native contacts resolve terrain, solids, ceilings and one-way platforms; game rules retain hopping, steps and wall kicks. Convex terrain strips avoid internal triangulation edges, while the leading shoulder preserves real bank clearance. Actual floor penetration resolves through the foot contact. Standing contact follows moving platforms. Contact refresh discards old position impulses; an immobile wall contact cannot trigger another kick. Restart/respawn removes the previous bodies and listener. No manual movement/collision solver remains as a fallback.
- **Santa’s Meltdown:** Phaser owns scheduling and timers. Native bodies resolve Santa, trees, pillars and movable rocks; enemy AI and combat remain game-owned. The sled uses native terrain contacts, gravity, jumps and landings. Level transitions dispose previous physics. Pause freezes both modes and delayed actions. The experimental score backend is local and uses separate keys.

The DOM-free test adapters supply the same geometry to Matter as the game, and discard native contacts when rewinding a look-ahead branch. Scripted players were calibrated for real ceilings and moving platforms: approach the graveyard slab from the side; use the roof edge when climbing frozen orbs; discard commands from the previous boss phase. A predicted target landing now matches the actual bot's immediate replanning there, instead of requiring an extra 1.1 seconds on a blinking platform. Full completion, coin, route, obstacle, event and nine-boss-hit assertions remain in place. No level geometry or completion assertions were removed to obtain passing tests.

### Source verification

| Check | Result |
| --- | --- |
| Shared `./check` | Six package checks, including the missing-suspend negative control; original revision/clean-worktree and installation/cache isolation |
| Bucht `npm test` | 67 passed |
| Bounce `npm test` | 396 passed, including composed routes, all boss phases and native-physics regressions |
| Santa `npm test` | 12 passed |
| Production builds | All three pass; Phaser bundles produce Vite's size advisory |
| Shared browser lifecycle | All three in Chromium and WebKit: actual input, paused world/effect pixels, suspended audio, focus loss and resume |
| Bucht adventure | All four stages in Chromium and WebKit, one banking per attempt, replay, reload and offline |
| Bounce browser suite | Menu/settings/save retry, intro, long level, graveyard, root hosting and scoped offline/update flow |
| Santa mode checks | Chromium/WebKit: top-down movement, sled transition and jump, pause, focus loss, resume/restart and original-score preservation |

A first Bounce browser run timed out on an enemy stomp under concurrent test load; isolated controlled and real-time reruns passed. The current whole browser suite is the release check. The graveyard exit fixture opens the gate and allows the designed 4.5-second walk/fade/light sequence rather than teleporting behind a closed gate with a three-second limit.

### Archive adoption and reproducible checks

Pack this source once, copy the same `tidyeval-game-platform-0.2.3.tgz` to every edition's `vendor/`, and update each dependency/lockfile explicitly. Compare the packaged and installed source/type bytes with the source owner. Remove an obsolete task-created archive only after all consumers have adopted the replacement.

After adopting an archive, run `./check`, `node tests/platform-browser.mjs`, `node tests/pwa-browser.mjs` and `node tests/standalone-builds.mjs` here. Previews are on ports 4183 (Bucht), 4184 (Bounce) and 4185 (Santa). The PWA suite builds and switches two real production versions at a Pages subpath, checking manifest-only version changes, gameplay/dialog deferral, menu activation, retained saves/unrelated caches and offline restart. Standalone checks copy each source to an isolated folder and run normal `npm ci` and production build without sibling source or node_modules. `GAME=<edition>` selects one standalone/PWA consumer; `GAME=bucht|bounce|santa` selects a lifecycle case.

Physical-phone GPU/battery use, native Android/iOS builds and subjective game feel are not established by these automated checks. No efficiency gain is claimed. Existing releases stay intact while the experimental editions are assessed on real devices.


## Accepted outcome objectives (2026-11-11)

This section supersedes the migration-only acceptance scope above. Objective 16 (additional accessibility work) was explicitly excluded by the user; existing accessibility must be preserved. The original eleven technical protections remain required. Historical passes above are not evidence for a later changed build.

| ID | Required outcome | Release acceptance / evidence |
| --- | --- | --- |
| 1 | Durable, identifiable playable test releases | Stable local URLs, immutable build snapshots, source/build fingerprints, every referenced asset loads, actual browser input; reconnect in a separate process after server setup and after the tool session. Previous accepted snapshot remains reachable. |
| 2+3 | Protect originals and ship each edition independently | `./check`: original revision and clean state match `original-games.json`; distinct source, app IDs, saves and caches. Device install/update/uninstall must not affect originals or sibling editions. |
| 4+5 | One maintained technical owner makes fixes reusable | Same versioned archive/source bytes in all three consumers; Phaser schedules gameplay and Matter integrates/resolves bodies. Existing Matter negative control remains mandatory. Adopt shared fixes explicitly; independently build each consumer. |
| 6 | Preserve established behavior and improve feel deliberately | All model and applicable real-browser suites pass; document intentional rule changes with before/after situations and player evidence. No weakening assertions to obtain a pass. |
| 7+9 | Progress survives faults and version changes | Duplicate retries, multiple tabs, read/write failures, older and malformed saves, abrupt close, two production versions, deferred updates and offline relaunch. Valid recoverable records and foreign caches survive. Rollback is tested with actual old/new builds and retained progress. |
| 8 | Interruptions behave predictably | Frozen simulation/render/audio, cleared held inputs, explicit resume, disposed bodies/listeners. On hardware: screen lock, app switch and audio interruption without progress loss, surprise audio or unfair death. |
| 10 | Reproducible delivery and rollback per game | Isolated lockfile/archive `npm ci` + production build; fingerprinted installable artifacts; previous local snapshot can be selected again. Native build and installation evidence is separate from web build evidence. |
| 11 | Measured quality on agreed physical hardware | Minimum matrix: one midrange Android phone with Chrome/native Android, one iPhone with Safari/native iOS; exact models/OS recorded before acceptance. Target 60 fps; at least 95% frames <=20 ms and 99% <=50 ms over a 5-minute representative run, first usable menu <=3 seconds warm and <=5 seconds cold, no crash or unbounded memory growth over 20 minutes. These are proposed initial budgets, not measured achievements. Record thermal/battery observations and portrait/landscape behavior. |
| 12 | First success without explanation | Five unfamiliar people per game; >=4 achieve an intentional first success within two minutes without hints. Use PLAYER-ACCEPTANCE.md. |
| 13 | Defeat is legible and fair | Testers explain cause and a plausible next action after each sampled failure; inspect hitboxes, warnings, difficulty transitions and retry delay. Record contradictions as defects, not tester mistakes. |
| 14 | A concrete reason to return | Each game states its mastery/discovery/progression loop; observe voluntary next rounds and ask about actual return after several days. No synthetic retention claims. |
| 15 | Complete content sustains the experience | Inventory all stages/bosses/transitions and new decisions; complete every intended route with no dead end or unfinished section. Automated bots establish reachability; human play establishes variety and pacing. |
| 17 | Reproducible local error context | User-accessible diagnostic report includes build, environment, current situation and bounded errors without saves/personal data; no automatic remote transmission. Inject an error and reproduce from captured context. |

### Evidence discipline and pending acceptance

Every new result must record date, game, source/build fingerprint, command or human protocol, environment and artifact/result. A model pass does not establish feel; desktop emulation does not establish physical-device performance. Source revision alone does not identify these dirty experimental worktrees: record content fingerprints as well. No remote publication is authorized by this implementation request.

Implementation baseline on 2026-11-11: shared `./check` passes all six package tests and original/edition isolation. Physical-device and unfamiliar-player acceptance is open. Do not label a release accepted until each applicable row has direct evidence.


### Execution evidence, 2026-11-11 (implementation in progress)

- Baseline production builds passed for all three editions; Vite reports large Phaser bundles. Bucht model suite: 67/67; Santa: 12/12. Bounce full model suite: 396/396 passed (470.5 seconds).
- `node tests/standalone-builds.mjs`: all three isolated lockfile/archive installations and builds passed before diagnostics package adoption. Must be repeated after final dependency adoption.
- `node tests/pwa-browser.mjs`: all three real two-build Pages-subpath updates passed, including menu/dialog deferral, retained progress/foreign caches and offline restart. Log: `test-results/pwa-2026-11-11.log`. These results predate final diagnostics package adoption.
- Bucht and Santa Android `assembleDebug` passed with JDK 23 and the local Android SDK. Native web assets will need final synchronization after diagnostics adoption. Bounce Android and iOS projects and Santa iOS project were added with distinct experimental identifiers. `tests/isolation.mjs` now verifies actual Android application IDs and all iOS build configuration bundle IDs, as well as Capacitor configuration.
- Bucht iOS simulator build failed: Xcode reports iOS 26.4 platform missing. Generating an Xcode project is not a successful native build or a device installation. No Android device is attached. No human or physical-device acceptance has been performed.
- Local preview tooling and rollback usage: see `LOCAL-PREVIEWS.md` once finalized. Human acceptance scripts and complete authored-content inventory: [PLAYER-ACCEPTANCE.md](PLAYER-ACCEPTANCE.md).

Remaining work includes final shared diagnostics adoption/browser verification, preview snapshot rollback checks, final dependency/build checks, native final asset sync/builds, interruption/fault/rollback coverage gaps, and human/device acceptance. None of these is waived by the implementation work above.


Additional native evidence: Bounce Android debug build also passed; debug APK SHA-256 and sizes for all three baseline builds are recorded in `test-results/native-20261111.json`. All three iOS simulator attempts fail with the same missing iOS 26.4 platform condition. These are unsigned/debug build checks, not store or device acceptance.

Desktop timing baseline: `node tests/performance-browser.mjs` records real-input startup and real-time animation-frame intervals against fingerprinted local previews; `SAMPLE_MS` extends the default 10-second sample. Statistics self-checks pass (2 tests). Initial headless Chromium desktop menu readiness was 695/417/570 ms for Bucht/Bounce/Santa, with p95 animation-frame intervals 33.3/16.8/33.4 ms and no runtime errors. This is neither game-loop/GPU profiling nor physical-device budget acceptance; it is a repeatable baseline to investigate. Evidence: `test-results/performance-browser.json`.


### Local diagnostics (0.2.4)

The shared diagnostics module collects a bounded in-memory list of uncaught error categories and the game-supplied situation. Each game exposes a localized, selectable report in settings with its version, bundled build fingerprint and coarse device context. Messages, stacks and URLs are excluded; nothing is sent automatically. Human acceptance and physical-device checks remain open.
