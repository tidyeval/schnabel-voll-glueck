# Shared game platform

Private package for the separate Phaser + Matter editions of Schnabelglück, Bounce & Boo and Santa’s Meltdown. Source owner: this directory. [Architecture, objectives and acceptance](ARCHITECTURE.md).

```sh
npm ci
./check
npm pack --pack-destination /tmp
```

Each game tracks the exact `tidyeval-game-platform-<version>.tgz` under `vendor/`, with a `file:vendor/...` dependency and lockfile integrity. A fresh checkout builds without sibling directories, an npm account or a private registry. Change this source, bump the version, run `./check`, pack once, copy that same archive into each consumer and explicitly update their dependency. Never edit the installed or vendored copies. Nothing is published by these commands.

Exports: `runtime` (Phaser scene and scheduling), `lifecycle` (focus/native suspension and audio gestures), `storage` (attempt ledger mechanics), `pwa` (install/update controls), `matter` (physical integration/units and polygon geometry), `build` (offline fingerprint and scoped worker generation). Game-specific rules and data validation stay in each game.

See the implementation and verification evidence in [ARCHITECTURE.md](ARCHITECTURE.md#current-implementation-and-next-work-2026-11-10). `./check` also verifies that the original worktrees and experimental installation identities are isolated.

Dedicated Santa mode checks: `node tests/santa-browser.mjs`. Independent clean installations/builds: `node tests/standalone-builds.mjs` (or `GAME=<edition>` for one affected edition).
