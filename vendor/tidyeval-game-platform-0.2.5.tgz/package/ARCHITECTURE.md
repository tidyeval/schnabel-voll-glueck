# Shared games architecture

## Objective and scope

Agreed direction, 2026-11-10: one maintained implementation for platform mechanics across Schnabelglück Bucht, Bounce & Boo and Santa’s Meltdown; independently testable gameplay and separately installable/deployable games. User clarification, 2026-11-10: new Phaser + Matter editions live in separate `*-phaser-matter` worktrees. All previous game worktrees, releases, storage namespaces and native app identities remain intact. The original Schnabelglück, Bucht test and isolated playground/lab remain untouched.

Baseline: platform code copied across three games; Bucht and Bounce own requestAnimationFrame loops, and Bucht separately runs Phaser effects. Target for this change: one Phaser-owned loop and real Matter movement/collision in each experimental game, three real lifecycle/PWA consumers, two real attempt-ledger consumers, and no sibling dependency in a fresh build. Check through source ownership, production browser runs and isolated `npm ci`/build. Device performance remains an acceptance gap until measured on hardware; no efficiency gain is claimed.

## Ownership and interfaces

- Phaser owns the scene lifecycle and scheduling in Bucht/Bounce. A game supplies `create(scene)` and `update(now, seconds)`. Fixed timesteps and direct Canvas vector rendering remain game-owned. Matter owns physical integration and collision; controllers retain game rules such as swim speed, hopping, wall kicks and damage. The shared `matter` module exposes the same Phaser-bundled engine to browser and DOM-free tests. No second physics library is installed. Bucht’s effects camera and world drawing use the same scroll. HTML controls and accessible dialogs stay outside the scene.
- `bindLifecycle` owns browser/native focus and gesture registration. Games supply their suspend, foreground and audio activation actions. Returning to the foreground never resumes a paused round automatically. Native back actions remain game-specific.
- `createProgressStore` owns ledger writes, replay and preference merge. Games own keys, schema migration, validation and idempotent `apply`. Exceptions reach the game’s existing visible error handling; failed snapshots retain attempts for retry. Santa keeps its own backend and progress owner.
- `setupPwa` owns install and update state. Downloaded workers wait; games call the returned action only in their menu with no open dialog. Explicit activation is a deliberate user action. Workers keep their existing game/scope cache namespaces, network-first navigation with bounded offline fallback, and cached versioned assets. First installation does not reload the page.
- Audio synthesis, music mixing, haptics choices, movement controllers, scores, levels, artwork and UI remain game-owned. Shared lifecycle provides audio activation/suspension. No generic game inheritance hierarchy, level DSL, backend, editor or registry is added. No shared registry exists in these game repositories.
- Versioned vendored npm archives keep each game independently buildable. Source is edited here; releases are adopted explicitly. Phaser is pinned to 4.2.1. Each new native app has a separate identifier; each web edition uses a new storage/cache namespace and its own hosting scope. Deployment workflows are disabled in the experimental worktrees. Santa uses its local backend with experiment-specific keys; no existing online scores are written.

## Verification

Reference: committed pre-change game behavior, existing model/browser suites and preserved storage keys. Proposed migration criteria implement the user-approved direction, without claiming new gameplay features.

1. All existing model tests and production builds pass. Existing fish routes, bounce control rules and storage migrations provide the comparison. Matter integration changes are calibrated explicitly; the old solver cannot be retained as a fallback. Original files and saved data must remain unchanged.
2. Chromium and WebKit: real keyboard/pointer input, catch/jump, pause, focus loss, settings, resume, restart and durable progress. Check rendered pixels and simulation separately during pause. No application-owned recursive animation loop remains in Bucht/Bounce.
3. Package controls: a normal ledger save/merge passes; duplicate retry adds nothing; failed snapshot throws and later retry banks once. A blocked storage read must propagate, rather than masquerade as a malformed entry. Browser/native lifecycle must suspend and dispose registrations. Removing the suspend registration must make the corresponding check fail.
4. Real two-build update tests: install, delayed public-file-only update, no activation during gameplay/dialog, menu activation, old saves retained, unrelated origin caches retained and offline relaunch. Root and Pages subpaths must work. A manifest-only change must change the cache version; identical input must not.
5. Fresh isolated game checkout with only its tracked package archive: `npm ci` and production build pass without the source package directory.

Automated checks establish technical behavior, not subjective game feel or GPU/battery cost on phones. Record actual results and remaining gaps here after execution.

## Current implementation and next work (2026-11-10)

The three separate Phaser + Matter editions share `@tidyeval/game-platform` 0.2.3. The package is private and adopted through the same vendored archive in each game. Version 0.2.3 refreshes package documentation; its runtime and type files are unchanged from 0.2.2. Original game revisions are recorded in `original-games.json`. Original sources, installation identities, saved data and deployed releases remain separate. No commit, push or deployment has been made.

- **Schnabelglück Bucht:** one Phaser loop controls world drawing and effects. Pip's native Matter body integrates movement; terrain and net shapes use Matter queries. Restart removes the previous body. The adventure, oxygen, energy, catches, levels and artwork stay game-owned.
- **Bounce & Boo:** the scene's Matter engine integrates a compound torso and centre foot. Native contacts resolve terrain, solids, ceilings and one-way platforms; game rules retain hopping, steps and wall kicks. Convex terrain strips avoid internal triangulation edges, while the leading shoulder preserves real bank clearance. Actual floor penetration resolves through the foot contact. Standing contact follows moving platforms. Contact refresh discards old position impulses; an immobile wall contact cannot trigger another kick. Restart/respawn removes the previous bodies and listener. No manual movement/collision solver remains as a fallback.
- **Santa’s Meltdown:** Phaser owns scheduling and timers. Native bodies resolve Santa, trees, pillars and movable rocks; enemy AI and combat remain game-owned. The sled uses native terrain contacts, gravity, jumps and landings. Level transitions dispose previous physics. Pause freezes both modes and delayed actions. The experimental score backend is local and uses separate keys.

The DOM-free test adapters supply the same geometry to Matter as the game, and discard native contacts when rewinding a look-ahead branch. Scripted players were calibrated for real ceilings and moving platforms: approach the graveyard slab from the side; use the roof edge when climbing frozen orbs; discard commands from the previous boss phase. A predicted target landing now matches the actual bot's immediate replanning there, instead of requiring an extra 1.1 seconds on a blinking platform. Full completion, coin, route, obstacle, event and nine-boss-hit assertions remain in place. No level geometry or completion assertions were removed to obtain passing tests.

### Source verification

| Check | Result |
| --- | --- |
| Shared `./check` | Six package checks, including the missing-suspend negative control; original revision/clean-worktree and installation/cache isolation |
| Bucht `npm test` | 67 passed |
| Bounce `npm test` | 396 passed, including composed routes, all boss phases and native-physics regressions |
| Santa `npm test` | 12 passed |
| Production builds | All three pass; Phaser bundles produce Vite's size advisory |
| Shared browser lifecycle | All three in Chromium and WebKit: actual input, paused world/effect pixels, suspended audio, focus loss and resume |
| Bucht adventure | All four stages in Chromium and WebKit, one banking per attempt, replay, reload and offline |
| Bounce browser suite | Menu/settings/save retry, intro, long level, graveyard, root hosting and scoped offline/update flow |
| Santa mode checks | Chromium/WebKit: top-down movement, sled transition and jump, pause, focus loss, resume/restart and original-score preservation |

A first Bounce browser run timed out on an enemy stomp under concurrent test load; isolated controlled and real-time reruns passed. The current whole browser suite is the release check. The graveyard exit fixture opens the gate and allows the designed 4.5-second walk/fade/light sequence rather than teleporting behind a closed gate with a three-second limit.

### Archive adoption and reproducible checks

Pack this source once, copy the same `tidyeval-game-platform-0.2.3.tgz` to every edition's `vendor/`, and update each dependency/lockfile explicitly. Compare the packaged and installed source/type bytes with the source owner. Remove an obsolete task-created archive only after all consumers have adopted the replacement.

After adopting an archive, run `./check`, `node tests/platform-browser.mjs`, `node tests/pwa-browser.mjs` and `node tests/standalone-builds.mjs` here. Previews are on ports 4183 (Bucht), 4184 (Bounce) and 4185 (Santa). The PWA suite builds and switches two real production versions at a Pages subpath, checking manifest-only version changes, gameplay/dialog deferral, menu activation, retained saves/unrelated caches and offline restart. Standalone checks copy each source to an isolated folder and run normal `npm ci` and production build without sibling source or node_modules. `GAME=<edition>` selects one standalone/PWA consumer; `GAME=bucht|bounce|santa` selects a lifecycle case.

Physical-phone GPU/battery use, native Android/iOS builds and subjective game feel are not established by these automated checks. No efficiency gain is claimed. Existing releases stay intact while the experimental editions are assessed on real devices.


## Accepted outcome objectives (2026-11-11)

This section supersedes the migration-only acceptance scope above. Objective 16 (additional accessibility work) was explicitly excluded by the user; existing accessibility must be preserved. The original eleven technical protections remain required. Historical passes above are not evidence for a later changed build.

| ID | Required outcome | Release acceptance / evidence |
| --- | --- | --- |
| 1 | Durable, identifiable playable test releases | Stable local URLs, immutable build snapshots, source/build fingerprints, every referenced asset loads, actual browser input; reconnect in a separate process after server setup and after the tool session. Previous accepted snapshot remains reachable. |
| 2+3 | Protect originals and ship each edition independently | `./check`: original revision and clean state match `original-games.json`; distinct source, app IDs, saves and caches. Device install/update/uninstall must not affect originals or sibling editions. |
| 4+5 | One maintained technical owner makes fixes reusable | Same versioned archive/source bytes in all three consumers; Phaser schedules gameplay and Matter integrates/resolves bodies. Existing Matter negative control remains mandatory. Adopt shared fixes explicitly; independently build each consumer. |
| 6 | Preserve established behavior and improve feel deliberately | All model and applicable real-browser suites pass; document intentional rule changes with before/after situations and player evidence. No weakening assertions to obtain a pass. |
| 7+9 | Progress survives faults and version changes | Duplicate retries, multiple tabs, read/write failures, older and malformed saves, abrupt close, two production versions, deferred updates and offline relaunch. Valid recoverable records and foreign caches survive. Rollback is tested with actual old/new builds and retained progress. |
| 8 | Interruptions behave predictably | Frozen simulation/render/audio, cleared held inputs, explicit resume, disposed bodies/listeners. On hardware: screen lock, app switch and audio interruption without progress loss, surprise audio or unfair death. |
| 10 | Reproducible delivery and rollback per game | Isolated lockfile/archive `npm ci` + production build; fingerprinted installable artifacts; previous local snapshot can be selected again. Native build and installation evidence is separate from web build evidence. |
| 11 | Measured quality on agreed physical hardware | Minimum matrix: one midrange Android phone with Chrome/native Android, one iPhone with Safari/native iOS; exact models/OS recorded before acceptance. Target 60 fps; at least 95% frames <=20 ms and 99% <=50 ms over a 5-minute representative run, first usable menu <=3 seconds warm and <=5 seconds cold, no crash or unbounded memory growth over 20 minutes. These are proposed initial budgets, not measured achievements. Record thermal/battery observations and portrait/landscape behavior. |
| 12 | First success without explanation | Five unfamiliar people per game; >=4 achieve an intentional first success within two minutes without hints. Use PLAYER-ACCEPTANCE.md. |
| 13 | Defeat is legible and fair | Testers explain cause and a plausible next action after each sampled failure; inspect hitboxes, warnings, difficulty transitions and retry delay. Record contradictions as defects, not tester mistakes. |
| 14 | A concrete reason to return | Each game states its mastery/discovery/progression loop; observe voluntary next rounds and ask about actual return after several days. No synthetic retention claims. |
| 15 | Complete content sustains the experience | Inventory all stages/bosses/transitions and new decisions; complete every intended route with no dead end or unfinished section. Automated bots establish reachability; human play establishes variety and pacing. |
| 17 | Reproducible local error context | User-accessible diagnostic report includes build, environment, current situation and bounded errors without saves/personal data; no automatic remote transmission. Inject an error and reproduce from captured context. |

### Evidence discipline and pending acceptance

Every new result must record date, game, source/build fingerprint, command or human protocol, environment and artifact/result. A model pass does not establish feel; desktop emulation does not establish physical-device performance. Source revision alone does not identify these dirty experimental worktrees: record content fingerprints as well. No remote publication is authorized by this implementation request.

Implementation baseline on 2026-11-11: shared `./check` passes all six package tests and original/edition isolation. Physical-device and unfamiliar-player acceptance is open. Do not label a release accepted until each applicable row has direct evidence.


### Local diagnostics (0.2.4)

The shared diagnostics module collects a bounded in-memory list of uncaught error categories and the game-supplied situation. Each game exposes a localized, selectable report in settings with its version, bundled build fingerprint and coarse device context. Messages, stacks and URLs are excluded; nothing is sent automatically. Human acceptance and physical-device checks remain open.


### Final technical checks for 0.2.4, 2026-11-11

These results supersede the in-progress bullets above. The packaged documentation remains the historical snapshot at archive creation; runtime/type source bytes match all installed consumers.

- All three consumers use the identical 0.2.4 archive, SHA-256 `ba70cf84f3b9b42d5a2fb7061694ad53e4bd996f3caf30700cb1fdd69c1bb7d0`. Installed `src/` bytes match the source owner. Final isolated lockfile/archive installs and builds passed for all three (`test-results/standalone-final-20261111.log`).
- Shared `./check` passes including original/native identity isolation. Diagnostics UI passes Chromium and WebKit for every game: injected error category/location captured, actual build hash present, private error message omitted, report selectable.
- Production update AND rollback, with retained progress/foreign caches and offline restart, pass for every game (`test-results/pwa-rollback-20261111.log`).
- Santa now uses the shared attempt ledger as the third consumer. Its previous adapter silently swallowed write failures, and its result UI claimed success in the error path. Failures now reach a visible retry action; a stable attempt ID and retained ledger prevent duplicate credit. Snapshot failure/restart, stale services, corrupt snapshot and retries after 102 attempts pass. Santa model suite now has 13 passing tests.
- Bucht/Bounce Chromium and WebKit tests close the page after a successful ledger append and failed snapshot, reopen with malformed snapshot, and recover without duplicate credit (`tests/storage-recovery-browser.mjs`). Santa also passes Chromium/WebKit recovery through real enemy-damage game-over and actual submission UI: visible quota failure, exactly one successful retry, then score recovery after closing/reopening with corrupted snapshot.
- Final web assets were synchronized and all three Android debug builds passed with 0.2.4, including Santa's storage correction. Artifact application IDs, sizes and SHA-256 hashes: `test-results/native-20261111.json`. All three iOS attempts failed because the iOS 26.4 Xcode platform is missing. No device installation is claimed.
- Local preview persistence/snapshots and rollback commands: [LOCAL-PREVIEWS.md](LOCAL-PREVIEWS.md). These URLs are accessible only on this Mac; no public deployment was performed.

Post-session check: all three final fingerprints responded from a new tool session on 2026-11-11. Stable-preview rollback to the earlier snapshot and back also passes for all three games, retaining a valid language preference. LaunchAgent running/manual restart observed; no reboot or fresh-login test. Remaining acceptance: human first-success/fairness/content/return sessions; physical-device interruption, installation and performance; final iOS build/installation evidence; complete Santa journey and sled finish demonstration. Objective 16 remains excluded. The overall objective is not complete.


Verification maintenance: `./check` now also runs `tests/package-adoption.mjs`, comparing every archived file with its installed bytes, lockfile SHA-512 integrity, equal archive SHA-256 across all consumers, explicit version adoption and maintained runtime/type source bytes. It passes for all three 0.2.4 consumers. The source-owner block metadata includes the diagnostics contract; released archive metadata/docs retain their creation-time snapshot.


Additional iOS environment checks: explicit installed iOS 26.2 simulator destination and generic simulator destination both fail before compilation. A direct target build with simulator SDK 26.4 passes Swift/framework work but fails storyboard compilation in `ibtool` with “iOS 26.4 Platform Not Installed”. SDK file presence is therefore not proof of an installed usable platform. Logs: `/tmp/bucht-ios-explicit.log`, `/tmp/bucht-ios-generic-simulator.log`, `/tmp/bucht-ios-target.log`. No complete usable iOS app was produced.


The iOS environment blocker was subsequently resolved on 2026-11-11: `xcodebuild -downloadPlatform iOS -architectureVariant arm64` installed the iOS 26.4 (23E244) simulator component successfully. The download was monitored with an 8 GiB minimum-free-space guard; installation finished with about 16 GiB free. The three final unsigned simulator builds are now running; successful installation of a platform component is not yet a successful app build or device test. Earlier failure logs remain historical evidence.


All three final iOS simulator builds subsequently passed with `CODE_SIGNING_ALLOWED=NO`, using the newly installed platform. Actual app-bundle identifiers match the separate experimental IDs. Evidence: `test-results/ios-builds-20261111.json`; build logs `/tmp/{schnabelglueck,bounce-and-boo,santas-meltdown}-final-ios-20261111.log`. Earlier platform failures are resolved. Simulator installation/launch and physical-device acceptance remain separate gates.


Native asset verification: `tests/native-assets.py` compares current production bytes with the Android APK and built iOS app (13 Bucht, 22 Bounce, 45 Santa runtime files). Pass log: `test-results/native-assets-20261111.log`. Santa also has a tracked editor backup `sprite-walking.png~`: the existing Android aapt `!*~` rule excludes it; its iOS bytes were checked separately. It is not referenced by game source/HTML/CSS, and no source backup was deleted. Native installation tests remain distinct from this package-content check.


Full-content runtime evidence, 2026-11-11: Bucht's final-build `node tests/adventure.mjs` passes all four real-input stages in Chromium AND WebKit, including exactly-once banking, replay, reload and offline restart. Log: `test-results/bucht-adventure-final-20261111.log`. Santa's seeded sled finish is demonstrated in both engines using normal firing, dash, grenade and jump controls; no teleport, damage bypass or level shortening. Retained test: `tests/santa-completion-browser.mjs`. Santa's journey/boss still needs completion evidence.

All three iOS apps installed and launched on an isolated iOS 26.4 simulator, and private-container markers survived restart and same-build reinstall. This verifies container retention, not game-progress retention or a cross-version native update. Evidence: `test-results/ios-smoke-20261111-9810/results.json`. Bucht/Bounce menus render; Santa's initial screenshot shows its portrait rotation prompt, so its native landscape/start flow remains under test. No existing simulator was modified.


Native build retention: six content-addressed baseline artifacts (three APKs and three simulator `.app.zip` archives) are retained under `test-results/native-artifacts-20261111/`, with SHA-256, sizes and paths in `manifest.json`. This preserves the successful build baseline independently of temporary Xcode build folders. These artifacts precede the subsequent Santa read-only diagnostic snapshot extension; Santa must be resynchronized/rebuilt before calling a later source state native-verified.

The iOS simulator touch/rotation follow-up could not run because computer-use reported a locked Mac and automatic unlock failed. No lock bypass was attempted. Existing installation/launch/container checks stand, but Santa's native landscape/start and actual native gameplay remain unverified. Manual unlock is needed for that UI route; physical-device acceptance remains open regardless.


Android native acceptance evidence (emulator only): all three apps installed/launched, actual touch started play, Home/background returned to paused state, and explicit resume worked. Bounce cleared held steering; Santa's paused physics stayed frozen. Bucht's attempt ended naturally soon after resume, so sustained gameplay is not established by that smoke. App-scoped logs had no fatal events. Reinstall retained Bucht's private marker; uninstalling Bounce left Bucht/Santa installed with markers, then Bounce was restored. `test-results/android-smoke-20261111/report.json` records exact APK hashes. A private marker establishes sandbox retention, not game-progress migration or hardware audio quality.

Concrete menu defect and correction: Santa's pause panel overflowed the short landscape viewport. The existing panel now has a viewport-relative maximum height and vertical scrolling. `tests/santa-pause-layout.mjs` fails on the old snapshot and passes Chromium/WebKit after the correction. Fresh Android and iOS builds pass; native packaged bytes match the current production files (`test-results/native-assets-snapshot-20261111.log`). The fresh Android follow-up scrolls the real pause panel and taps Restart, successfully returning to play; evidence `test-results/android-santa-pause-20261111/report.json`. The new local preview fingerprint is `382bab538650cc60ce964dea812e69168f93da27139718a8d630979b9a35bbc6`. The original six native artifacts plus two newer Santa artifacts are retained in the native manifest (eight total).

The isolated Android emulator was shut down after these checks; its task-created AVD and evidence are retained. Existing user AVDs were not touched. Reopen `GamePlatformAcceptance20261111` on port 5580 before running `tests/android-smoke.mjs`; the runner refuses a different AVD. `GAME=santa` selects only Santa, and `ANDROID_SMOKE_OUTPUT` selects a separate evidence directory to preserve a baseline.


Latest browser mode check: Chromium passed. One combined-run WebKit check failed the existing movement assertion; the unchanged assertion then passed an isolated rerun and three further sequential WebKit runs. Cause remains unverified; this is not a proven gameplay defect or an unconditional green result. The assertion now includes the full snapshot in its failure message for diagnosis (`tests/santa-browser.mjs`); logs are retained under `test-results/santa-modes-latest-20261111.log` and `santa-webkit-timing-*.log`.


## Objective acceptance audit (2026-11-11, still open)

| Objective | Current direct evidence | Remaining acceptance |
| --- | --- | --- |
| 1 | Three launchd previews, retained content-addressed snapshots, version endpoints, all production files and actual browser input; reopened across tool sessions. | Fresh login/reboot was not tested; URLs are Mac-local. |
| 2 | `./check` confirms original revisions and clean source worktrees; no publication performed. Original keys and caches stay separate. | Physical-device coexistence is tracked under 3; no original source or release was changed. |
| 3 | Distinct native IDs verified in built artifacts; three apps installed together on isolated Android/iOS simulators; sandbox isolation tested. | Physical-device original/new coexistence. |
| 4 | Same 0.2.4 archive, lock SHA-512, every archived/installed byte and maintained source/type bytes checked by `tests/package-adoption.mjs`. | No technical adoption gap currently identified. |
| 5 | Phaser-owned loops, Matter movement/contact model and browser checks, missing-Matter negative control. | Hardware calibration is covered under 11. |
| 6 | 67 Bucht, 396 Bounce and 13 Santa model tests; Bucht four-stage route both engines; native/browser lifecycle and input checks. | Bounce full WebKit level suite and Santa full WebKit route are under active verification; human feel remains open. |
| 7 | Shared ledger now has three real consumers; interrupted writes, corruption/reopen, stale services/tabs, duplicate retries and honest retry UI tested. | Physical-device termination while saving. |
| 8 | Browser frozen pixels/simulation/audio/focus checks; native Android Home→paused→resume and cleared steering tested. | Physical lock/audio interruption; iOS touch route blocked by locked Mac. |
| 9 | Real two-production-version update AND rollback, menu/dialog deferral, retained progress/foreign caches, offline restart all three. | Native cross-version progress update is not established by same-build marker retention. |
| 10 | Three isolated lockfile/archive installs and production builds; Android/iOS simulator builds; retained native artifacts with hashes. | Signed physical-device delivery and installation. |
| 11 | Repeatable desktop timing baseline; Android/iOS simulator evidence. | Exact physical models/OS and 5-minute frame /20-minute stability/audio/touch measurements. |
| 12 | Game-specific first-success protocols and 4-of-5/two-minute target in `PLAYER-ACCEPTANCE.md`. | Five unfamiliar real players per game; no fabricated human results. |
| 13 | Scripted routes and loss/context traces; pause-control defect fixed from actual native screenshot. | Real players explain failures and confirm fair recovery. |
| 14 | Each game's existing mastery/progression/replay loop and 48–96h follow-up protocol inventoried. | Voluntary replay and actual later returns from real players. |
| 15 | Full Bucht route both engines; Bounce campaign/composed routes model coverage; Santa complete start→boss→sled→victory captured in Chromium. | Santa full WebKit victory, Bounce WebKit route evidence and human pacing/variety acceptance. |
| 16 | Explicitly excluded from new work. Existing controls/accessibility preserved; clipping correction belongs to functional menus. | No additional accessibility programme is claimed. |
| 17 | Shared bounded local reports, actual repeated uncaught errors, build identifiers and selectable/private-message-free output tested both engines/all three. | Real-world bug reports may require additional reproduction details; no automatic transmission. |

The previous intermittent movement check is now causally diagnosed: a seeded tree blocked rightward travel while accepted input, visible/focused document, RAF and Matter time continued. Failure JSON/screenshot are in `test-results/santa-browser-diagnostics/`. The test retains its x/time assertions and uses a verified clear starting fixture (seed 1); three consecutive combined Chromium/WebKit runs and isolated runs pass. No game rules were changed. The captured blocker case happens in Chromium too; the original failing WebKit invocation lacked a snapshot, so that individual historical run cannot be reconstructed with certainty.

Santa full Chromium route proof: `test-results/santa-journey-chromium-2026-11-11.log` and `.meta` retain actual captured stdout and build `382bab538650cc60ce964dea812e69168f93da27139718a8d630979b9a35bbc6`. It proves one full normal-input route, not controller reliability or human acceptance. Two bounded WebKit controller attempts failed; their traces show fuel/range/positioning limits, not proof of an unreachable game. Further work must preserve the victory assertion and authored gameplay.


### First-install update notification correction (0.2.5 in preparation)

Fresh Chromium and WebKit traces show the first service worker briefly occupies `registration.waiting` while no active worker exists, immediately before automatic activation. The previous shared handler therefore announced a nonexistent pending update on first install. `setupPwa` now requires an existing active worker before showing the menu-update notice. This preserves the real replacement-worker path and changes no game rules. Regression evidence before correction: `test-results/pwa-first-install-20261111/report.json`; retained verifier: `tests/pwa-first-install-browser.mjs`. Version 0.2.5 is being packed/adopted explicitly; the previous 0.2.4 archive and playable snapshots remain intact. Consumer and two-production-version checks are pending this adoption, not assumed green.
