type StorageLike = Pick<Storage, 'getItem' | 'setItem' | 'key' | 'length'>;
export function createProgressStore<P, A extends { id: string }>(options: {
  key: string; read: (raw: string | null) => P; apply: (progress: P, attempt: A) => unknown;
}): {
  load(storage?: StorageLike): P; isKey(key: string | null): boolean;
  saveSetting(key: string, value: unknown, storage?: StorageLike): P;
  saveAttempt(attempt: A, storage?: StorageLike): P;
};
