/** Mechanics only: the game owns validation, migration and attempt meaning. */
export function createProgressStore({ key, read, apply }) {
  const prefix = `${key}-attempt:`;
  function load(storage = localStorage) {
    const progress = read(storage.getItem(key));
    for (let i = 0; i < storage.length; i++) {
      const entry = storage.key(i);
      if (!entry?.startsWith(prefix)) continue;
      const raw = storage.getItem(entry);
      let attempt;
      try { attempt = JSON.parse(raw); } catch { continue; }
      apply(progress, attempt);
    }
    return progress;
  }
  return {
    load,
    isKey: entry => entry === key || Boolean(entry?.startsWith(prefix)),
    saveSetting(name, value, storage = localStorage) {
      const latest = load(storage); latest[name] = value;
      storage.setItem(key, JSON.stringify(latest));
      return latest;
    },
    saveAttempt(attempt, storage = localStorage) {
      if (!attempt || typeof attempt.id !== 'string' || !attempt.id) throw new Error('Cannot save an attempt without an id');
      // The ledger survives a failed snapshot; applying the same id must be idempotent.
      storage.setItem(prefix + attempt.id, JSON.stringify(attempt));
      const latest = load(storage);
      storage.setItem(key, JSON.stringify(latest));
      return latest;
    },
  };
}
