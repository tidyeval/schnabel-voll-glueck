// Design ontology and design-token validation, format version 1 (see DESIGN-FORMAT.md), plus
// game-neutral cross-check helpers for a game's tests/design.test.js.
// Deterministic and dependency-free: every problem is returned as an actionable message;
// nothing is thrown for malformed input. File access goes through a `read(path)` callback
// that returns the file's text, or null when the file does not exist.

export const DESIGN_FORMAT_VERSION = 1;
export const ONTOLOGY_FORMAT = 'tidyeval-design-ontology';
export const TOKENS_FORMAT = 'tidyeval-design-tokens';

const ID = /^[A-Za-z][A-Za-z0-9_.-]*$/;
const REFERENCE = /^\{([A-Za-z][A-Za-z0-9_.-]*)\}$/;
const NUMBER = '[-+]?(?:\\d+\\.?\\d*|\\.\\d+)';
const HEX = /^#(?:[0-9a-fA-F]{3,4}|[0-9a-fA-F]{6}|[0-9a-fA-F]{8})$/;
const RGB = new RegExp(`^rgba?\\(\\s*${NUMBER}\\s*,\\s*${NUMBER}\\s*,\\s*${NUMBER}\\s*(?:,\\s*${NUMBER}\\s*)?\\)$`);
const DIMENSION = new RegExp(`^${NUMBER}(?:px|cqw|cqh|%|em|rem|vw|vh|svh|dvh)$`);
const DIMENSION_FUNCTION = /^(?:clamp|min|max|calc)\(.+\)$/;
const DURATION = new RegExp(`^${NUMBER}(?:ms|s)$`);
const BEZIER = new RegExp(`^cubic-bezier\\(\\s*${NUMBER}\\s*,\\s*${NUMBER}\\s*,\\s*${NUMBER}\\s*,\\s*${NUMBER}\\s*\\)$`);
const EASINGS = ['linear', 'ease', 'ease-in', 'ease-out', 'ease-in-out'];
const WAVES = ['sine', 'triangle', 'square', 'sawtooth'];
export const TOKEN_TYPES = ['color', 'gradient', 'dimension', 'duration', 'number', 'fontFamily', 'fontWeight', 'easing', 'sound', 'haptic', 'string'];
/** Entity `status` values; an entity without `status` is `built`. */
export const ENTITY_STATUSES = ['built', 'partial', 'prototype', 'planned', 'dormant', 'unused', 'rejected'];
const FILTERS = ['lowpass', 'highpass', 'bandpass', 'lowshelf', 'highshelf', 'peaking', 'notch', 'allpass'];
const TELEGRAPH_KEYS = ['channels', 'announce', 'danger', 'leadSeconds', 'colour', 'probe', 'exception'];

const isObject = value => value !== null && typeof value === 'object' && !Array.isArray(value);
const text = value => typeof value === 'string' && value.trim() !== '';
const quote = value => JSON.stringify(value);
const reason = value => text(value) && value.trim().length >= 10;
const WORD = /[A-Za-z0-9_$]/, DIGIT = /\d/;

/**
 * True when `needle` occurs in `haystack` as whole tokens: an end that is a letter, digit, "_" or "$"
 * may not continue into another such character, and a number may not continue into a decimal
 * ("STOMP_V = 1050" does not match "STOMP_V = 10500", "0.5" does not match "10.55").
 */
export function containsExact(haystack, needle) {
  if (typeof haystack !== 'string' || typeof needle !== 'string' || needle === '') return false;
  const first = needle[0], last = needle[needle.length - 1];
  for (let i = haystack.indexOf(needle); i !== -1; i = haystack.indexOf(needle, i + 1)) {
    const before = haystack[i - 1] ?? '', after = haystack[i + needle.length] ?? '';
    if (WORD.test(first) && WORD.test(before)) continue;
    if (DIGIT.test(first) && before === '.' && DIGIT.test(haystack[i - 2] ?? '')) continue;
    if (WORD.test(last) && WORD.test(after)) continue;
    if (DIGIT.test(last) && after === '.' && DIGIT.test(haystack[i + needle.length + 1] ?? '')) continue;
    return true;
  }
  return false;
}

/** True for #rgb, #rgba, #rrggbb, #rrggbbaa, rgb(r,g,b) and rgba(r,g,b,a) with channels in range. */
export function isColor(value) {
  if (typeof value !== 'string') return false;
  if (HEX.test(value)) return true;
  if (!RGB.test(value)) return false;
  const parts = value.slice(value.indexOf('(') + 1, -1).split(',').map(Number);
  return parts.slice(0, 3).every(n => n >= 0 && n <= 255) && (parts.length === 3 || (parts[3] >= 0 && parts[3] <= 1));
}

function reporter(prefix) {
  const errors = [];
  return { errors, add: (where, message) => errors.push(`${prefix}${where ? ` ${where}` : ''}: ${message}`) };
}

function checkKeys(add, where, value, allowed) {
  for (const key of Object.keys(value)) if (!allowed.includes(key)) add(where, `unknown field ${quote(key)} (allowed: ${allowed.join(', ')})`);
}

function checkHeader(add, doc, format) {
  if (doc.format !== format) add('format', `must be ${quote(format)}, found ${quote(doc.format)}`);
  if (doc.version !== DESIGN_FORMAT_VERSION) add('version', `must be ${DESIGN_FORMAT_VERSION}, found ${quote(doc.version)}; this validator only understands format version ${DESIGN_FORMAT_VERSION}`);
  if (!text(doc.game)) add('game', 'must name the game (non-empty string)');
}

function safePath(path) {
  return text(path) && !path.startsWith('/') && !/^[A-Za-z]:/.test(path) && !path.split(/[\\/]/).includes('..');
}

// Reads each path once per validation; a failing reader is reported, not thrown.
function cachedReader(read) {
  const cache = new Map();
  return path => {
    if (!cache.has(path)) {
      let content = null, failure = null;
      try { content = typeof read === 'function' ? read(path) : null; } catch (error) { failure = error?.message || String(error); }
      cache.set(path, { content: typeof content === 'string' ? content : null, failure, missingReader: typeof read !== 'function' });
    }
    return cache.get(path);
  };
}

function checkFileContains(add, where, file, contains, read, what) {
  if (!safePath(file)) { add(where, `${what} file must be a relative path inside the game, found ${quote(file)}`); return; }
  if (!text(contains)) { add(where, `${what} needs a non-empty "contains" string that must occur in ${file}`); return; }
  const result = read(file);
  if (result.missingReader) add(where, `cannot verify ${file}: no read(path) function was supplied`);
  else if (result.failure) add(where, `cannot read ${file}: ${result.failure}`);
  else if (result.content === null) add(where, `${what} file ${file} does not exist; fix the path or remove the reference`);
  else if (!result.content.includes(contains)) add(where, `${file} does not contain ${quote(contains)}; ${what === 'evidence' ? 'update the evidence to the current code or restore the symbol' : 'use the exact current test name or restore the test'}`);
  else if (!containsExact(result.content, contains)) add(where, `${file} contains ${quote(contains)} only inside a longer word or number (for example ${quote(around(result.content, contains))}); evidence must match whole tokens, so quote the exact symbol or value`);
}

function around(content, needle) {
  const i = content.indexOf(needle);
  return content.slice(Math.max(0, i - 8), i + needle.length + 8).replace(/\s+/g, ' ');
}

function checkEvidence(add, where, evidence, read, required) {
  if (evidence === undefined) { if (required) add(where, 'needs "evidence": a non-empty list of { "file", "contains" } pointing at the real code'); return; }
  if (!Array.isArray(evidence) || (required && evidence.length === 0)) { add(where, '"evidence" must be a non-empty list of { "file", "contains" }'); return; }
  evidence.forEach((entry, i) => {
    const at = `${where}.evidence[${i}]`;
    if (!isObject(entry)) { add(at, 'must be an object { "file", "contains" }'); return; }
    checkKeys(add, at, entry, ['file', 'contains', 'note']);
    checkFileContains(add, at, entry.file, entry.contains, read, 'evidence');
  });
}

function checkList(add, doc, key, required = true) {
  if (doc[key] === undefined && !required) return [];
  if (!Array.isArray(doc[key])) { add(key, 'must be a list'); return []; }
  return doc[key];
}

function registerIds(add, ids, list, kind) {
  list.forEach((item, i) => {
    if (!isObject(item)) { add(`${kind}[${i}]`, 'must be an object'); return; }
    if (typeof item.id !== 'string' || !ID.test(item.id)) add(`${kind}[${i}]`, `id ${quote(item.id)} must start with a letter and use only letters, digits, ".", "_" or "-"`);
    else if (ids.has(item.id)) add(`${kind}[${item.id}]`, `duplicate id (already used by ${ids.get(item.id)}); ids must be unique in the file`);
    else ids.set(item.id, kind);
  });
}

const label = (kind, item, i) => `${kind}[${typeof item?.id === 'string' ? item.id : i}]`;

/**
 * Validate a design ontology document.
 * @param {unknown} doc Parsed design/ontology.json.
 * @param {(path: string) => string | null} read Returns a game file's text or null.
 * @returns {string[]} Actionable errors; empty when valid.
 */
export function validateOntology(doc, read) {
  return ontologyReport(doc, read).errors;
}

function ontologyReport(doc, read) {
  const { errors, add } = reporter('ontology');
  const warnings = [];
  const stats = { entities: 0, byStatus: {}, rules: { total: 0, automated: 0, partial: 0, manual: 0 } };
  if (!isObject(doc)) { add('', 'must be a JSON object'); return { errors, warnings, stats }; }
  const source = cachedReader(read);
  checkKeys(add, '', doc, ['format', 'version', 'game', 'description', 'concepts', 'entities', 'relationTypes', 'relations', 'rules']);
  checkHeader(add, doc, ONTOLOGY_FORMAT);
  const concepts = checkList(add, doc, 'concepts'), entities = checkList(add, doc, 'entities');
  const types = checkList(add, doc, 'relationTypes', false), relations = checkList(add, doc, 'relations', false), rules = checkList(add, doc, 'rules');
  const ids = new Map();
  registerIds(add, ids, concepts, 'concepts'); registerIds(add, ids, entities, 'entities');
  registerIds(add, ids, types, 'relationTypes'); registerIds(add, ids, rules, 'rules');
  const conceptById = new Map(concepts.filter(isObject).map(c => [c.id, c]));
  const entityById = new Map(entities.filter(isObject).map(e => [e.id, e]));
  const typeById = new Map(types.filter(isObject).map(t => [t.id, t]));

  concepts.forEach((concept, i) => {
    if (!isObject(concept)) return;
    const at = label('concepts', concept, i);
    checkKeys(add, at, concept, ['id', 'label', 'description', 'parent', 'evidence']);
    if (!text(concept.description)) add(at, 'needs a "description"');
    if (concept.parent !== undefined && !conceptById.has(concept.parent)) add(at, `parent ${quote(concept.parent)} is not a concept id`);
    checkEvidence(add, at, concept.evidence, source, false);
  });
  // Parent chains must end at a root concept.
  for (const concept of conceptById.values()) {
    const seen = new Set([concept.id]);
    for (let parent = concept.parent; parent !== undefined && conceptById.has(parent); parent = conceptById.get(parent).parent) {
      if (seen.has(parent)) { add(`concepts[${concept.id}]`, `parent chain forms a cycle through ${quote(parent)}`); break; }
      seen.add(parent);
    }
  }
  const isA = (conceptId, ancestor) => {
    for (let id = conceptId, steps = 0; id !== undefined && steps <= conceptById.size; id = conceptById.get(id)?.parent, steps++) if (id === ancestor) return true;
    return false;
  };

  entities.forEach((entity, i) => {
    if (!isObject(entity)) return;
    const at = label('entities', entity, i);
    checkKeys(add, at, entity, ['id', 'concept', 'label', 'description', 'status', 'properties', 'evidence']);
    if (!conceptById.has(entity.concept)) add(at, `concept ${quote(entity.concept)} is not a concept id`);
    if (entity.status !== undefined && !ENTITY_STATUSES.includes(entity.status)) add(at, `status ${quote(entity.status)} is not one of ${ENTITY_STATUSES.join(', ')}`);
    const status = ENTITY_STATUSES.includes(entity.status) ? entity.status : 'built';
    stats.entities++; stats.byStatus[status] = (stats.byStatus[status] ?? 0) + 1;
    if (entity.properties !== undefined && !isObject(entity.properties)) add(at, '"properties" must be an object');
    if (isObject(entity.properties)) checkConventions(add, warnings, at, entity.properties);
    checkEvidence(add, at, entity.evidence, source, true);
  });

  types.forEach((type, i) => {
    if (!isObject(type)) return;
    const at = label('relationTypes', type, i);
    checkKeys(add, at, type, ['id', 'description', 'from', 'to']);
    if (!text(type.description)) add(at, 'needs a "description"');
    for (const end of ['from', 'to']) if (type[end] !== undefined && !conceptById.has(type[end])) add(at, `${end} ${quote(type[end])} is not a concept id`);
  });

  const conceptOf = id => entityById.get(id)?.concept ?? (conceptById.has(id) ? id : undefined);
  const triples = new Set();
  relations.forEach((relation, i) => {
    const at = `relations[${i}]`;
    if (!isObject(relation)) { add(at, 'must be an object { "from", "type", "to" }'); return; }
    checkKeys(add, at, relation, ['from', 'type', 'to', 'note', 'evidence']);
    const type = typeById.get(relation.type);
    if (!type) add(at, `type ${quote(relation.type)} is not declared in relationTypes`);
    for (const end of ['from', 'to']) {
      const id = relation[end], concept = conceptOf(id);
      if (concept === undefined) add(at, `${end} ${quote(id)} is not an entity or concept id`);
      else if (type?.[end] !== undefined && !isA(concept, type[end])) add(at, `${end} ${quote(id)} must be a ${type[end]} for relation type ${quote(type.id)} (it is a ${concept})`);
    }
    const key = `${relation.from}\u0000${relation.type}\u0000${relation.to}`;
    if (triples.has(key)) add(at, `duplicate relation ${relation.from} ${relation.type} ${relation.to}`);
    triples.add(key);
    checkEvidence(add, at, relation.evidence, source, false);
  });

  rules.forEach((rule, i) => {
    if (!isObject(rule)) return;
    const at = label('rules', rule, i);
    checkKeys(add, at, rule, ['id', 'statement', 'rationale', 'appliesTo', 'check', 'evidence']);
    if (!text(rule.statement)) add(at, 'needs a "statement"');
    if (rule.appliesTo !== undefined) {
      if (!Array.isArray(rule.appliesTo)) add(at, '"appliesTo" must be a list of entity or concept ids');
      else rule.appliesTo.forEach(id => { if (conceptOf(id) === undefined) add(at, `appliesTo ${quote(id)} is not an entity or concept id`); });
    }
    const kind = checkRuleCheck(add, at, rule.check, source);
    stats.rules.total++;
    if (kind) stats.rules[kind.kind]++;
    if (kind?.kind === 'partial') warnings.push(`ontology ${at}: only partly automated; gap: ${kind.gaps.join('; ')}`);
    checkEvidence(add, at, rule.evidence, source, false);
  });
  return { errors, warnings, stats };
}

// Reserved property conventions: `constants` (map of exported name -> value) and `telegraph` /
// `telegraphs` (one telegraph, or a map of named telegraphs). Everything else in properties is free.
function checkConventions(add, warnings, at, properties) {
  if (properties.constants !== undefined) {
    if (!isObject(properties.constants)) add(`${at}.properties.constants`, 'must be an object mapping exported constant names to their values');
    else for (const name of Object.keys(properties.constants)) if (!/^[A-Za-z_$][A-Za-z0-9_$]*$/.test(name)) add(`${at}.properties.constants`, `${quote(name)} is not an exported identifier`);
  }
  if (properties.telegraph !== undefined) checkTelegraph(add, warnings, `${at}.properties.telegraph`, properties.telegraph);
  if (properties.telegraphs !== undefined) {
    if (!isObject(properties.telegraphs) || !Object.keys(properties.telegraphs).length) add(`${at}.properties.telegraphs`, 'must be a non-empty object mapping names to telegraphs');
    else for (const [name, telegraph] of Object.entries(properties.telegraphs)) checkTelegraph(add, warnings, `${at}.properties.telegraphs.${name}`, telegraph);
  }
}

function checkTelegraph(add, warnings, at, telegraph) {
  if (!isObject(telegraph)) { add(at, 'must be an object { channels, announce, danger, leadSeconds, colour?, probe?, exception? }'); return; }
  checkKeys(add, at, telegraph, TELEGRAPH_KEYS);
  const exception = telegraph.exception !== undefined;
  if (exception) {
    if (!reason(telegraph.exception)) add(at, '"exception" needs a reason of at least 10 characters why this is not telegraphed');
    else warnings.push(`ontology ${at}: telegraph exception: ${telegraph.exception.trim()}`);
  }
  if (telegraph.channels !== undefined || !exception) {
    if (!Array.isArray(telegraph.channels) || !telegraph.channels.length || !telegraph.channels.every(text)) add(at, '"channels" must be a non-empty list of how the player is warned (sound, pose, colour, text...)');
  }
  for (const key of ['announce', 'danger']) if ((telegraph[key] !== undefined || !exception) && !text(telegraph[key])) add(at, `"${key}" must be a non-empty string naming the game's ${key === 'announce' ? 'warning signal' : 'moment the danger becomes real'}`);
  if ((telegraph.leadSeconds !== undefined || !exception) && !(typeof telegraph.leadSeconds === 'number' && telegraph.leadSeconds > 0 && Number.isFinite(telegraph.leadSeconds))) add(at, '"leadSeconds" must be a positive number of seconds between announce and danger');
  if (telegraph.colour !== undefined && !(typeof telegraph.colour === 'string' && REFERENCE.test(telegraph.colour))) add(at, `"colour" must reference a colour token like "{color.danger}", found ${quote(telegraph.colour)}`);
}

// Returns { kind: 'automated' | 'partial' | 'manual', gaps } for a valid check, otherwise null.
function checkRuleCheck(add, at, check, read) {
  const howTo = 'set "check" to { "test": "<test file>", "name": "<test name>" }, a list of those, or { "manual": "<why it cannot be automated>" }';
  if (check === undefined) { add(at, `has no check; ${howTo}`); return null; }
  if (isObject(check) && 'manual' in check) {
    checkKeys(add, `${at}.check`, check, ['manual']);
    if (!reason(check.manual)) { add(`${at}.check`, 'a manual check needs a reason of at least 10 characters explaining why it is not automated'); return null; }
    return { kind: 'manual', gaps: [] };
  }
  const list = Array.isArray(check) ? check : [check];
  if (!list.length) { add(at, `has an empty check list; ${howTo}`); return null; }
  const gaps = [];
  let valid = true;
  list.forEach((entry, i) => {
    const where = Array.isArray(check) ? `${at}.check[${i}]` : `${at}.check`;
    if (!isObject(entry) || !('test' in entry)) { add(where, howTo); valid = false; return; }
    checkKeys(add, where, entry, ['test', 'name', 'runner', 'covers', 'gap']);
    checkFileContains(add, where, entry.test, entry.name, read, 'check test');
    if (entry.runner !== undefined && !(text(entry.runner) && /^[a-z][a-z0-9-]*$/.test(entry.runner))) add(where, `"runner" must be a lowercase runner name such as "node" (default) or "playwright", found ${quote(entry.runner)}`);
    if (entry.covers !== undefined && !['full', 'partial'].includes(entry.covers)) add(where, `"covers" must be "full" (default) or "partial", found ${quote(entry.covers)}`);
    if (entry.covers === 'partial') {
      if (!reason(entry.gap)) { add(where, 'a partial check needs a "gap" of at least 10 characters naming what the test does not cover'); valid = false; } else gaps.push(entry.gap.trim());
    } else if (entry.gap !== undefined) add(where, '"gap" is only allowed with "covers": "partial"');
  });
  return valid ? { kind: gaps.length ? 'partial' : 'automated', gaps } : null;
}

// `null` or "none" mark a deliberately absent value (for example a stage without a tint).
const isAbsent = value => value === null || value === 'none';

function checkTokenValue(add, at, type, value, resolveRef, read, nested = false) {
  const ref = typeof value === 'string' ? value.match(REFERENCE) : null;
  if (ref) { resolveRef(ref[1], type, at); return; }
  if (isAbsent(value) && !nested) return; // a whole token may be absent, a gradient stop may not
  switch (type) {
    case 'color': if (!isColor(value)) add(at, `${quote(value)} is not a colour (use #rgb, #rgba, #rrggbb, #rrggbbaa, rgb() or rgba())`); break;
    case 'gradient':
      if (!Array.isArray(value) || value.length < 2) { add(at, 'a gradient needs at least two stops [{ "at": 0..1, "color": ... }]'); break; }
      value.forEach((stop, i) => {
        if (!isObject(stop) || typeof stop.at !== 'number' || stop.at < 0 || stop.at > 1) add(`${at}[${i}]`, 'stop needs "at" between 0 and 1');
        else if (i && stop.at < value[i - 1]?.at) add(`${at}[${i}]`, 'stops must be in ascending "at" order');
        if (isObject(stop)) checkTokenValue(add, `${at}[${i}].color`, 'color', stop.color, resolveRef, read, true);
      });
      break;
    case 'dimension': if (!(typeof value === 'number' && Number.isFinite(value)) && !(typeof value === 'string' && (DIMENSION.test(value) || DIMENSION_FUNCTION.test(value)))) add(at, `${quote(value)} is not a dimension (number, or e.g. "12px", "4cqw", "clamp(...)")`); break;
    case 'duration': if (!(typeof value === 'string' && DURATION.test(value))) add(at, `${quote(value)} is not a duration (e.g. "0.32s" or "150ms")`); break;
    case 'number': if (typeof value !== 'number' || !Number.isFinite(value)) add(at, `${quote(value)} is not a finite number`); break;
    case 'fontWeight': if (!Number.isInteger(value) || value < 1 || value > 1000) add(at, `${quote(value)} is not a font weight (integer 1-1000)`); break;
    case 'easing': if (!(typeof value === 'string' && (EASINGS.includes(value) || BEZIER.test(value) || /^steps\(\d+(?:,\s*[a-z-]+)?\)$/.test(value)))) add(at, `${quote(value)} is not an easing (cubic-bezier(a,b,c,d), steps(n) or ${EASINGS.join('/')})`); break;
    case 'fontFamily': case 'string': if (!text(value)) add(at, 'must be a non-empty string'); break;
    case 'haptic': checkHaptic(add, at, value); break;
    case 'sound':
      if (isObject(value) && value.kind === 'sample') { checkSample(add, at, value, read); break; }
      if (isObject(value) && value.kind === 'noise') { checkNoise(add, at, value); break; }
      if (isObject(value) && value.kind !== undefined) { add(at, `sound "kind" must be "sample" or "noise" (or omitted for { "notes" }), found ${quote(value.kind)}`); break; }
      if (!isObject(value) || !Array.isArray(value.notes) || !value.notes.length) { add(at, 'a sound needs { "notes": [{ "hz", "seconds", ... }] }, { "kind": "sample", "file" } or { "kind": "noise", "duration" }'); break; }
      value.notes.forEach((note, i) => {
        const where = `${at}.notes[${i}]`;
        if (!isObject(note)) { add(where, 'must be an object'); return; }
        checkKeys(add, where, note, ['hz', 'seconds', 'volume', 'wave', 'delay', 'slideTo']);
        if (!(note.hz > 0)) add(where, '"hz" must be a positive number');
        if (!(note.seconds > 0)) add(where, '"seconds" must be a positive number');
        if (note.volume !== undefined && !(note.volume >= 0 && note.volume <= 1)) add(where, '"volume" must be between 0 and 1');
        if (note.wave !== undefined && !WAVES.includes(note.wave)) add(where, `"wave" must be one of ${WAVES.join(', ')}`);
        if (note.delay !== undefined && !(note.delay >= 0)) add(where, '"delay" must be zero or positive');
        if (note.slideTo !== undefined && !(note.slideTo > 0)) add(where, '"slideTo" must be a positive number');
      });
      break;
    default: break;
  }
}

const gain = value => typeof value === 'number' && Number.isFinite(value) && value >= 0;

function checkSample(add, at, value, read) {
  checkKeys(add, at, value, ['kind', 'file', 'gain', 'loop']);
  if (!safePath(value.file)) add(at, `a sample needs "file": a relative path inside the game, found ${quote(value.file)}`);
  else {
    const result = read(value.file);
    if (result.missingReader) add(at, `cannot verify ${value.file}: no read(path) function was supplied`);
    else if (result.failure) add(at, `cannot read ${value.file}: ${result.failure}`);
    else if (result.content === null) add(at, `sample file ${value.file} does not exist; fix the path or remove the token`);
  }
  if (value.gain !== undefined && !gain(value.gain)) add(at, '"gain" must be a number of zero or more');
  if (value.loop !== undefined && typeof value.loop !== 'boolean') add(at, '"loop" must be true or false');
}

function checkNoise(add, at, value) {
  checkKeys(add, at, value, ['kind', 'duration', 'filter', 'gain']);
  if (!(typeof value.duration === 'number' && value.duration > 0 && Number.isFinite(value.duration))) add(at, 'noise needs "duration": a positive number of seconds');
  if (value.gain !== undefined && !gain(value.gain)) add(at, '"gain" must be a number of zero or more');
  if (value.filter !== undefined) {
    const where = `${at}.filter`;
    if (!isObject(value.filter)) { add(where, 'must be { "type", "hz", "q"? }'); return; }
    checkKeys(add, where, value.filter, ['type', 'hz', 'q']);
    if (!FILTERS.includes(value.filter.type)) add(where, `"type" must be one of ${FILTERS.join(', ')}`);
    if (!(value.filter.hz > 0)) add(where, '"hz" must be a positive number');
    if (value.filter.q !== undefined && !(value.filter.q > 0)) add(where, '"q" must be a positive number');
  }
}

function checkHaptic(add, at, value) {
  const ms = n => typeof n === 'number' && Number.isFinite(n) && n >= 0;
  if (!isObject(value)) { add(at, 'a haptic needs { "web": <ms> or [<ms>, ...], "native"?: "<style>" }'); return; }
  checkKeys(add, at, value, ['web', 'native']);
  if (!(ms(value.web) || (Array.isArray(value.web) && value.web.length && value.web.every(ms)))) add(at, '"web" must be a vibration duration in ms or a non-empty list of ms (navigator.vibrate pattern)');
  if (value.native !== undefined && !text(value.native)) add(at, '"native" must name the native haptic style (non-empty string)');
}

/**
 * Validate a design tokens document (tokens, components, characters).
 * @param {unknown} doc Parsed design/tokens.json.
 * @param {(path: string) => string | null} read Returns a game file's text or null.
 * @returns {string[]} Actionable errors; empty when valid.
 */
export function validateTokens(doc, read) {
  return tokensReport(doc, read).errors;
}

function tokensReport(doc, read) {
  const { errors, add } = reporter('tokens');
  const stats = { tokens: 0, byType: {} };
  if (!isObject(doc)) { add('', 'must be a JSON object'); return { errors, warnings: [], stats }; }
  const source = cachedReader(read);
  checkKeys(add, '', doc, ['format', 'version', 'game', 'description', 'tokens', 'components', 'characters']);
  checkHeader(add, doc, TOKENS_FORMAT);
  const tokens = isObject(doc.tokens) ? doc.tokens : (add('tokens', 'must be an object mapping token ids to { "type", "value" }'), {});
  const components = checkList(add, doc, 'components', false), characters = checkList(add, doc, 'characters', false);

  const typeOf = id => isObject(tokens[id]) ? tokens[id].type : undefined;
  const resolveRef = (id, type, at) => {
    if (!Object.hasOwn(tokens, id)) add(at, `reference {${id}} does not name a token`);
    else if (type !== undefined && typeOf(id) !== type) add(at, `reference {${id}} is a ${typeOf(id)} token, expected ${type}`);
  };
  for (const [id, token] of Object.entries(tokens)) {
    const at = `tokens[${id}]`;
    if (!ID.test(id)) add(at, 'token id must start with a letter and use only letters, digits, ".", "_" or "-"');
    if (!isObject(token)) { add(at, 'must be an object { "type", "value" }'); continue; }
    checkKeys(add, at, token, ['type', 'value', 'description', 'evidence']);
    if (!TOKEN_TYPES.includes(token.type)) { add(at, `type ${quote(token.type)} is not one of ${TOKEN_TYPES.join(', ')}`); continue; }
    if (token.value === undefined) { add(at, 'needs a "value"'); continue; }
    stats.tokens++; stats.byType[token.type] = (stats.byType[token.type] ?? 0) + 1;
    checkTokenValue(add, `${at}.value`, token.type, token.value, resolveRef, source);
    const isRef = value => typeof value === 'string' && REFERENCE.test(value);
    // Literal values must be traceable to the code; aliases, gradients made only of references and
    // absent values ("none"/null) have nothing of their own to trace.
    const needsEvidence = !isRef(token.value) && !isAbsent(token.value) && !(token.type === 'gradient' && Array.isArray(token.value) && token.value.every(stop => isRef(stop?.color)));
    checkEvidence(add, at, token.evidence, source, needsEvidence);
  }
  // Alias chains must end in a literal value.
  for (const id of Object.keys(tokens)) {
    const seen = new Set([id]);
    for (let value = tokens[id]?.value; typeof value === 'string' && REFERENCE.test(value);) {
      const next = value.match(REFERENCE)[1];
      if (seen.has(next)) { add(`tokens[${id}]`, `reference chain forms a cycle through {${next}}`); break; }
      seen.add(next); value = tokens[next]?.value;
    }
  }

  const ids = new Map(Object.keys(tokens).map(id => [id, 'tokens']));
  registerIds(add, ids, components, 'components'); registerIds(add, ids, characters, 'characters');
  const checkRefs = (at, map, what) => {
    if (!isObject(map)) { add(at, `"${what}" must be an object mapping names to token references like "{color.text}"`); return; }
    for (const [name, value] of Object.entries(map)) {
      const ref = typeof value === 'string' ? value.match(REFERENCE) : null;
      if (!ref) add(`${at}.${what}.${name}`, `must reference a token like "{color.text}", found ${quote(value)}`);
      else resolveRef(ref[1], what === 'palette' ? 'color' : undefined, `${at}.${what}.${name}`);
    }
  };
  components.forEach((component, i) => {
    if (!isObject(component)) return;
    const at = label('components', component, i);
    checkKeys(add, at, component, ['id', 'label', 'description', 'selector', 'entity', 'tokens', 'variants', 'evidence']);
    if (!text(component.description)) add(at, 'needs a "description"');
    checkRefs(at, component.tokens, 'tokens');
    if (component.variants !== undefined) {
      if (!Array.isArray(component.variants)) add(at, '"variants" must be a list');
      else {
        const seen = new Set();
        component.variants.forEach((variant, j) => {
          const where = `${at}.variants[${variant?.id ?? j}]`;
          if (!isObject(variant) || !text(variant.id)) { add(where, 'needs an "id"'); return; }
          if (seen.has(variant.id)) add(where, 'duplicate variant id');
          seen.add(variant.id);
          checkKeys(add, where, variant, ['id', 'label', 'description', 'selector', 'tokens', 'evidence']);
          checkRefs(where, variant.tokens, 'tokens');
          checkEvidence(add, where, variant.evidence, source, false);
        });
      }
    }
    checkEvidence(add, at, component.evidence, source, true);
  });
  characters.forEach((character, i) => {
    if (!isObject(character)) return;
    const at = label('characters', character, i);
    checkKeys(add, at, character, ['id', 'label', 'description', 'entity', 'palette', 'proportions', 'expressions', 'evidence']);
    checkRefs(at, character.palette, 'palette');
    if (character.proportions !== undefined) {
      if (!isObject(character.proportions)) add(at, '"proportions" must be an object of numbers');
      else for (const [name, value] of Object.entries(character.proportions)) if (typeof value !== 'number' || !Number.isFinite(value)) add(`${at}.proportions.${name}`, 'must be a finite number');
    }
    if (character.expressions !== undefined) {
      if (!Array.isArray(character.expressions)) add(at, '"expressions" must be a list');
      else character.expressions.forEach((expression, j) => {
        const where = `${at}.expressions[${expression?.id ?? j}]`;
        if (!isObject(expression) || !text(expression.id) || !text(expression.description)) { add(where, 'needs an "id" and a "description"'); return; }
        checkKeys(add, where, expression, ['id', 'description', 'evidence']);
        checkEvidence(add, where, expression.evidence, source, true);
      });
    }
    checkEvidence(add, at, character.evidence, source, true);
  });
  return { errors, warnings: [], stats };
}

/**
 * Validate both documents and the links between them.
 * @param {{ ontology: unknown, tokens: unknown }} docs
 * @param {(path: string) => string | null} read
 * @returns {string[]}
 */
export function validateDesign(docs, read) {
  return validateDesignReport(docs, read).errors;
}

/**
 * Like validateDesign, plus warnings (partly automated rules, telegraph exceptions) and stats
 * (entity statuses, automated / partial / manual rule counts, token counts).
 */
export function validateDesignReport({ ontology, tokens } = {}, read) {
  const o = ontologyReport(ontology, read), t = tokensReport(tokens, read);
  const errors = [...o.errors, ...t.errors], warnings = [...o.warnings, ...t.warnings];
  const stats = { ...o.stats, tokens: t.stats.tokens, tokensByType: t.stats.byType };
  if (!isObject(ontology) || !isObject(tokens)) return { errors, warnings, stats };
  if (ontology.game !== tokens.game) errors.push(`tokens game: ${quote(tokens.game)} must match the ontology's game ${quote(ontology.game)}`);
  const entities = (Array.isArray(ontology.entities) ? ontology.entities : []).filter(isObject);
  const entityIds = new Set(entities.map(e => e.id));
  for (const kind of ['components', 'characters']) {
    if (!Array.isArray(tokens[kind])) continue;
    tokens[kind].forEach((item, i) => {
      if (isObject(item) && item.entity !== undefined && !entityIds.has(item.entity)) errors.push(`tokens ${label(kind, item, i)}: entity ${quote(item.entity)} is not an entity id in the ontology`);
    });
  }
  // Telegraph colours must name colour tokens.
  const tokenMap = isObject(tokens.tokens) ? tokens.tokens : {};
  for (const entity of entities) {
    const p = isObject(entity.properties) ? entity.properties : {};
    const list = [['telegraph', p.telegraph], ...Object.entries(isObject(p.telegraphs) ? p.telegraphs : {}).map(([name, value]) => [`telegraphs.${name}`, value])];
    for (const [where, telegraph] of list) {
      const ref = typeof telegraph?.colour === 'string' ? telegraph.colour.match(REFERENCE) : null;
      if (!ref) continue;
      const at = `ontology entities[${entity.id}].properties.${where}.colour`;
      if (!isObject(tokenMap[ref[1]])) errors.push(`${at}: {${ref[1]}} is not a token in tokens.json`);
      else if (tokenMap[ref[1]].type !== 'color') errors.push(`${at}: {${ref[1]}} is a ${tokenMap[ref[1]].type} token, expected color`);
    }
  }
  return { errors, warnings, stats };
}

/**
 * Node helper: read `<root>/design/ontology.json` and `<root>/design/tokens.json` and validate them
 * with evidence paths resolved against `root`. JSON syntax errors are reported, not thrown.
 * @param {string | URL} root The game's root directory.
 * @returns {Promise<{ errors: string[], warnings: string[], stats: object | null, ontology: unknown, tokens: unknown }>}
 */
export async function checkDesignFiles(root) {
  const { readFileSync, existsSync } = await import('node:fs');
  const { fileURLToPath } = await import('node:url');
  const { join } = await import('node:path');
  const base = root instanceof URL ? fileURLToPath(root) : String(root);
  const read = path => existsSync(join(base, path)) ? readFileSync(join(base, path), 'utf8') : null;
  const load = file => {
    const content = read(file);
    if (content === null) return { error: `${file}: file not found under ${base}` };
    try { return { doc: JSON.parse(content) }; } catch (error) { return { error: `${file}: invalid JSON (${error.message})` }; }
  };
  const ontology = load('design/ontology.json'), tokens = load('design/tokens.json');
  const loadErrors = [ontology.error, tokens.error].filter(Boolean);
  if (loadErrors.length) return { errors: loadErrors, warnings: [], stats: null, ontology: ontology.doc, tokens: tokens.doc };
  const report = validateDesignReport({ ontology: ontology.doc, tokens: tokens.doc }, read);
  return { ...report, ontology: ontology.doc, tokens: tokens.doc };
}

/** One line per error, for assertion messages. */
export function formatDesignErrors(errors) {
  return errors.length ? `${errors.length} design error(s):\n- ${errors.join('\n- ')}` : 'design files are valid';
}

// ---- Cross-check helpers ---------------------------------------------------------------------------------
// Pure functions for a game's tests/design.test.js. The game supplies its own data (code exports, CSS text,
// translations); each helper returns a list of actionable error strings (empty when fine) and never throws.

const list = value => value === undefined || value === null ? [] : typeof value === 'string' ? [value] : typeof value[Symbol.iterator] === 'function' ? [...value] : Object.keys(value);
const show = values => values.map(value => (typeof value === 'string' ? value : quote(value))).join(', ');
const tokenMapOf = tokens => (isObject(tokens?.tokens) ? tokens.tokens : isObject(tokens) ? tokens : {});
const entitiesIn = ontology => (Array.isArray(ontology) ? ontology : Array.isArray(ontology?.entities) ? ontology.entities : []).filter(isObject);

/**
 * Both directions of "the code's set equals the declared set".
 * @param {Iterable<unknown> | object} expected Usually from the code (an object counts by its keys).
 * @param {Iterable<unknown> | object} actual Usually declared in the design files.
 * @param {string} [what] Names the set in the messages.
 */
export function setEquals(expected, actual, what = 'set') {
  const want = new Set(list(expected)), have = new Set(list(actual)), errors = [];
  const missing = [...want].filter(value => !have.has(value)).sort(), extra = [...have].filter(value => !want.has(value)).sort();
  if (missing.length) errors.push(`${what}: missing ${show(missing)} (expected but not declared)`);
  if (extra.length) errors.push(`${what}: unexpected ${show(extra)} (declared but not expected)`);
  return errors;
}

/** Entities whose concept is `concept` or (unless `{ descendants: false }`) one of its sub-concepts. */
export function entitiesOf(ontology, concept, options) {
  const { descendants = true } = options ?? {};
  const parent = new Map((Array.isArray(ontology?.concepts) ? ontology.concepts : []).filter(isObject).map(c => [c.id, c.parent]));
  const isA = id => { for (let steps = 0; id !== undefined && steps <= parent.size; id = parent.get(id), steps++) if (id === concept) return true; return false; };
  return entitiesIn(ontology).filter(e => (descendants ? isA(e.concept) : e.concept === concept));
}

/** Sorted, de-duplicated "from > to" strings of the relations of one type, for comparison with the code. */
export function relationPairs(ontology, type) {
  const relations = (Array.isArray(ontology?.relations) ? ontology.relations : []).filter(r => isObject(r) && r.type === type);
  return [...new Set(relations.map(r => `${r.from} > ${r.to}`))].sort();
}

/** Every entity and concept has a non-empty description. */
export function requireDescriptions(ontology) {
  const errors = [];
  for (const kind of ['concepts', 'entities']) {
    (Array.isArray(ontology?.[kind]) ? ontology[kind] : []).forEach((item, i) => {
      if (isObject(item) && !text(item.description)) errors.push(`ontology ${label(kind, item, i)}: needs a "description"`);
    });
  }
  return errors;
}

const flatten = (value, prefix = '') => Object.entries(value).flatMap(([key, child]) => (isObject(child) ? flatten(child, `${prefix}${key}.`) : [[`${prefix}${key}`, child]]));
const placeholdersOf = value => [...new Set(String(value).match(/\{\w+\}/g) ?? [])].sort();

/**
 * Every key exists as a non-empty string in every locale, and (with `placeholders`, the default) uses the
 * same {placeholder} set as the reference locale. Nested objects are flattened to dotted keys.
 * @param {Record<string, object>} translations locale -> dictionary
 * @param {{ placeholders?: boolean, reference?: string, keys?: Iterable<string> }} [options]
 *   `reference` defaults to the first locale; `keys` are keys the code uses, which must exist too.
 */
export function localeParity(translations, options) {
  const { placeholders = true, reference, keys = [] } = options ?? {};
  if (!isObject(translations) || !Object.keys(translations).length) return ['translations: must be an object mapping locales to dictionaries'];
  const locales = Object.keys(translations), errors = [];
  const tables = Object.fromEntries(locales.map(locale => [locale, new Map(isObject(translations[locale]) ? flatten(translations[locale]) : [])]));
  for (const locale of locales) if (!isObject(translations[locale])) errors.push(`translations.${locale}: must be an object`);
  const base = reference ?? locales[0];
  if (!tables[base]) return [...errors, `translations: reference locale ${quote(base)} does not exist`];
  const all = [...new Set([...locales.flatMap(locale => [...tables[locale].keys()]), ...list(keys)])].sort();
  const used = new Set(list(keys));
  for (const key of all) {
    for (const locale of locales) {
      const value = tables[locale].get(key);
      if (!text(value)) errors.push(`translations.${locale}: ${used.has(key) && !locales.some(l => tables[l].has(key)) ? 'used key' : 'key'} ${quote(key)} is ${value === undefined ? 'missing' : 'empty or not a string'}`);
      else if (placeholders && locale !== base && text(tables[base].get(key)) && placeholdersOf(value).join() !== placeholdersOf(tables[base].get(key)).join()) {
        errors.push(`translations.${locale}: ${quote(key)} uses placeholders ${show(placeholdersOf(value)) || 'none'}, ${base} uses ${show(placeholdersOf(tables[base].get(key))) || 'none'}`);
      }
    }
  }
  return errors;
}

const CSS_COLOUR = /#[0-9a-fA-F]{3,8}\b|(?:rgba?|hsla?)\([^)]*\)/g;
/** Lowercase colour text without whitespace, the form used to compare CSS and token colours. */
export const normaliseColour = value => String(value).toLowerCase().replace(/\s+/g, '');
const stripComments = css => String(css ?? '').replace(/\/\*[\s\S]*?\*\//g, '');

function resolveToken(tokenMap, value) {
  for (let i = 0; i < 20 && typeof value === 'string' && REFERENCE.test(value); i++) value = tokenMap[value.match(REFERENCE)[1]]?.value;
  return value;
}
// Literal colours of a colour or gradient token (references resolved), skipping absent values.
function tokenColours(tokenMap, value, type) {
  const resolved = resolveToken(tokenMap, value);
  if (type === 'color') return typeof resolved === 'string' && !isAbsent(resolved) ? [resolved] : [];
  if (type === 'gradient' && Array.isArray(resolved)) return resolved.flatMap(stop => tokenColours(tokenMap, stop?.color, 'color'));
  return [];
}

/**
 * Literal colours in CSS must be token values (colour tokens and gradient stops) or listed exceptions, and
 * every exception must still be used and not already a token. Comparison is lowercase without whitespace.
 * @param {string} cssText
 * @param {object} tokens Parsed tokens.json (or its `tokens` map).
 * @param {string[] | Record<string, string>} [exceptions] Colours, or colour -> reason.
 * @param {{ functions?: boolean }} [options] `functions: false` inventories only hex colours, not rgb()/rgba()/hsl().
 */
export function cssColourInventory(cssText, tokens, exceptions = [], options) {
  const { functions = true } = options ?? {};
  const map = tokenMapOf(tokens);
  const known = new Set(Object.values(map).filter(isObject).flatMap(token => tokenColours(map, token.value, token.type)).map(normaliseColour));
  const allowed = (Array.isArray(exceptions) ? exceptions : Object.keys(exceptions ?? {})).map(normaliseColour);
  const used = [...new Set([...stripComments(cssText).matchAll(CSS_COLOUR)].map(m => normaliseColour(m[0])).filter(colour => functions || colour.startsWith('#')))].sort();
  const errors = [];
  for (const colour of used) if (!known.has(colour) && !allowed.includes(colour)) errors.push(`css colour ${colour} is neither a token value nor a listed exception; add a token to design/tokens.json or list it as an exception with a reason`);
  for (const colour of allowed) {
    if (known.has(colour)) errors.push(`css colour exception ${colour} is already a token value; remove the exception`);
    else if (!used.includes(colour)) errors.push(`css colour exception ${colour} no longer occurs in the CSS; remove the exception`);
  }
  return errors;
}

/**
 * Every literal colour of a colour token (and gradient stop) occurs in one of the token's evidence strings,
 * compared lowercase without whitespace. `forms(colour)` may return extra spellings the code uses
 * (for example "[77,166,255]" for a channel array).
 */
export function colourEvidence(tokens, options) {
  const { forms = () => [], gradients = true } = options ?? {};
  const errors = [];
  for (const [id, token] of Object.entries(tokenMapOf(tokens))) {
    if (!isObject(token) || !(token.type === 'color' || (gradients && token.type === 'gradient'))) continue;
    const literals = token.type === 'color' ? [token.value] : Array.isArray(token.value) ? token.value.map(stop => stop?.color) : [];
    const evidence = (Array.isArray(token.evidence) ? token.evidence : []).map(e => normaliseColour(e?.contains ?? ''));
    for (const colour of literals.filter(value => typeof value === 'string' && !REFERENCE.test(value) && !isAbsent(value))) {
      let extra = [];
      try { extra = typeof forms === 'function' ? list(forms(colour)) : []; } catch (error) { errors.push(`tokens[${id}]: forms(${quote(colour)}) failed: ${error?.message || error}`); }
      const spellings = [colour, ...extra].map(normaliseColour);
      if (!evidence.some(text => spellings.some(spelling => text.includes(spelling)))) errors.push(`tokens[${id}]: ${colour} does not occur in its evidence strings; quote the line that sets this colour`);
    }
  }
  return errors;
}

function splitTopLevel(textValue, separator) {
  const parts = []; let depth = 0, quoteChar = null, start = 0;
  for (let i = 0; i < textValue.length; i++) {
    const c = textValue[i];
    if (quoteChar) { if (c === quoteChar && textValue[i - 1] !== '\\') quoteChar = null; continue; }
    if (c === '"' || c === "'") quoteChar = c;
    else if (c === '(' || c === '[') depth++;
    else if (c === ')' || c === ']') depth--;
    else if (c === separator && depth === 0) { parts.push(textValue.slice(start, i)); start = i + 1; }
  }
  parts.push(textValue.slice(start));
  return parts;
}

/**
 * Flat list of CSS style rules in source order, comments removed. Rules inside @media/@supports keep their
 * at-rule chain in `atRules`; @keyframes steps are skipped. Nested CSS is not supported.
 * @returns {{ index: number, selectors: string[], body: string, declarations: { property: string, value: string, important: boolean }[], atRules: string[] }[]}
 */
export function cssRules(cssText) {
  const css = stripComments(cssText), rules = [], stack = [];
  let start = 0;
  for (let i = 0; i < css.length; i++) {
    const c = css[i];
    if (c === ';' && !css.slice(start, i).includes('{')) start = i + 1; // @import/@charset statements
    else if (c === '}') { stack.pop(); start = i + 1; }
    else if (c === '{') {
      const prelude = css.slice(start, i).trim();
      if (prelude.startsWith('@')) { stack.push(prelude); start = i + 1; continue; }
      const end = css.indexOf('}', i);
      if (end === -1) break;
      const body = css.slice(i + 1, end);
      if (!stack.some(at => /^@(?:-\w+-)?keyframes\b/.test(at))) {
        const declarations = splitTopLevel(body, ';').map(d => d.trim()).filter(Boolean).flatMap(d => {
          const colon = d.indexOf(':');
          if (colon < 1) return [];
          const value = d.slice(colon + 1).trim();
          const property = d.slice(0, colon).trim();
          return [{ property: property.startsWith('--') ? property : property.toLowerCase(), value: value.replace(/\s*!important$/i, ''), important: /!important$/i.test(value) }];
        });
        rules.push({ index: rules.length, selectors: splitTopLevel(prelude, ',').map(s => s.trim().replace(/\s+/g, ' ')).filter(Boolean), body, declarations, atRules: [...stack] });
      }
      i = end; start = end + 1;
    }
  }
  return rules;
}

/** [ids, classes/attributes/pseudo-classes, elements/pseudo-elements] of one simple CSS selector. */
export function cssSpecificity(selector) {
  let s = String(selector).replace(/"[^"]*"|'[^']*'/g, '').replace(/:(?:where)\([^)]*\)/g, '');
  const count = pattern => { const n = (s.match(pattern) ?? []).length; s = s.replace(pattern, ' '); return n; };
  const pseudoElements = count(/::[\w-]+(?:\([^)]*\))?/g);
  const ids = count(/#[\w-]+/g);
  const classes = count(/\.[\w-]+/g) + count(/\[[^\]]*\]/g) + count(/:(?!not\(|is\(|has\()[\w-]+(?:\([^)]*\))?/g);
  const elements = (s.replace(/:(?:not|is|has)\(/g, ' ').match(/(?:^|[\s>+~(])[a-zA-Z][\w-]*/g) ?? []).length;
  return [ids, classes, elements + pseudoElements];
}
const compareSpecificity = (a, b) => a[0] - b[0] || a[1] - b[1] || a[2] - b[2];
// A later declaration of `over` overrides `under` when it is the same property, its shorthand, or a longhand of it.
const overrides = (over, under) => over === under
  || (under.startsWith(`${over}-`) && !(over === 'border' && /^border-(?:\w+-)*radius$|^border-image/.test(under)))
  || over.startsWith(`${under}-`);

/**
 * Components and variants with a `selector`: a rule with exactly that selector exists, every colour or
 * gradient token they name occurs in the rules for that selector (including :hover, descendant and
 * compound forms; var(--custom) properties are substituted), and no variant declaration is overridden by its component's own rule that wins the
 * cascade (higher specificity, or equal specificity and later in the file) outside at-rules.
 */
export function checkComponents(tokens, cssText) {
  const map = tokenMapOf(tokens), rules = cssRules(cssText), errors = [];
  // Custom properties (last declaration wins) are substituted into var(--name[, fallback]).
  const vars = new Map(rules.flatMap(rule => rule.declarations.filter(d => d.property.startsWith('--')).map(d => [d.property, d.value])));
  const substitute = body => {
    for (let i = 0; i < 10 && /var\(/.test(body); i++) body = body.replace(/var\(\s*(--[\w-]+)\s*(?:,([^()]*))?\)/g, (all, name, fallback) => vars.get(name) ?? fallback ?? all);
    return body;
  };
  const related = selector => rules.filter(rule => rule.selectors.some(s => s === selector || [' ', ':', '[', '.', '>'].some(c => s.startsWith(selector + c))));
  const exact = (selector, topLevel) => rules.filter(rule => rule.selectors.includes(selector) && (!topLevel || !rule.atRules.length));
  const components = Array.isArray(tokens?.components) ? tokens.components.filter(isObject) : [];
  for (const component of components) {
    const parts = [{ at: `components[${component.id}]`, part: component }, ...(Array.isArray(component.variants) ? component.variants.filter(isObject) : []).map(v => ({ at: `components[${component.id}].variants[${v.id}]`, part: v }))];
    for (const { at, part } of parts) {
      if (!text(part.selector)) continue;
      if (!exact(part.selector).length) { errors.push(`${at}: selector ${part.selector} has no rule in the CSS`); continue; }
      const body = normaliseColour(substitute(related(part.selector).map(rule => rule.body).join(';')));
      for (const [prop, ref] of Object.entries(isObject(part.tokens) ? part.tokens : {})) {
        const id = typeof ref === 'string' ? ref.match(REFERENCE)?.[1] : undefined;
        if (!id || !isObject(map[id])) continue; // reported by validateTokens
        for (const colour of tokenColours(map, ref, map[id].type)) if (!body.includes(normaliseColour(colour))) errors.push(`${at}.tokens.${prop}: ${colour} (${ref}) is not set in the CSS for ${part.selector}`);
      }
    }
    if (!text(component.selector)) continue;
    const base = exact(component.selector, true);
    for (const { at, part } of parts.slice(1)) {
      if (!text(part.selector) || part.selector === component.selector) continue;
      const reported = new Set();
      for (const rule of exact(part.selector, true)) for (const mine of rule.declarations) for (const other of base) for (const theirs of other.declarations) {
        if (reported.has(mine.property) || !overrides(theirs.property, mine.property)) continue;
        const order = compareSpecificity(cssSpecificity(component.selector), cssSpecificity(part.selector));
        const wins = theirs.important !== mine.important ? theirs.important : order > 0 || (order === 0 && other.index > rule.index);
        if (!wins) continue;
        reported.add(mine.property);
        errors.push(`${at}: ${mine.property} in ${part.selector} is overridden by ${theirs.property} in ${component.selector} (${order > 0 ? 'higher specificity' : theirs.important !== mine.important ? '!important' : 'same specificity, later in the file'}); move the variant rule after the component rule or raise its specificity (for example ${component.selector}${part.selector})`);
      }
    }
  }
  return errors;
}

function deepEqual(a, b) {
  if (Object.is(a, b)) return true;
  if (typeof a !== 'object' || typeof b !== 'object' || a === null || b === null || Array.isArray(a) !== Array.isArray(b)) return false;
  const ka = Object.keys(a), kb = Object.keys(b);
  return ka.length === kb.length && ka.every(key => Object.hasOwn(b, key) && deepEqual(a[key], b[key]));
}

/**
 * Each entity's `properties.constants` ({ EXPORT_NAME: value }) deep-equals the named export of the given
 * module namespace(s). A name exported with different values by several modules is reported as ambiguous.
 * @param {object | object[]} ontologyOrEntities Parsed ontology or its entity list.
 * @param {object | object[]} modules One module namespace (import * as M) or a list of them.
 * @param {{ min?: number }} [options] `min`: fail when fewer constants are declared (guards against an empty check).
 */
export function constantsMatch(ontologyOrEntities, modules, options) {
  const { min = 0 } = options ?? {};
  const namespaces = (Array.isArray(modules) ? modules : [modules]).filter(m => m !== null && typeof m === 'object');
  const errors = [];
  let checked = 0;
  for (const entity of entitiesIn(ontologyOrEntities)) {
    const constants = entity.properties?.constants;
    if (!isObject(constants)) continue;
    for (const [name, value] of Object.entries(constants)) {
      checked++;
      const found = namespaces.filter(ns => Object.hasOwn(ns, name) || name in ns).map(ns => ns[name]);
      if (!found.length) { errors.push(`entities[${entity.id}].properties.constants.${name}: no given module exports ${name}`); continue; }
      if (found.some(other => !deepEqual(other, found[0]))) { errors.push(`entities[${entity.id}].properties.constants.${name}: several modules export ${name} with different values; pass only the module that owns it`); continue; }
      if (!deepEqual(value, found[0])) errors.push(`entities[${entity.id}].properties.constants.${name}: declared ${quote(value)} but the code exports ${quote(found[0])}`);
    }
  }
  if (checked < min) errors.push(`properties.constants: only ${checked} constants declared, expected at least ${min}`);
  return errors;
}
