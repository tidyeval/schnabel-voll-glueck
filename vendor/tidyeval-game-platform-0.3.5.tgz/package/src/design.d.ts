export const DESIGN_FORMAT_VERSION: 1;
export const ONTOLOGY_FORMAT: 'tidyeval-design-ontology';
export const TOKENS_FORMAT: 'tidyeval-design-tokens';
export const TOKEN_TYPES: readonly string[];
/** Entity `status` values; an entity without `status` is `built`. */
export const ENTITY_STATUSES: readonly ['built', 'partial', 'prototype', 'planned', 'dormant', 'unused', 'rejected'];
/** Returns a game file's text, or null when it does not exist. */
export type DesignReader = (path: string) => string | null;
export interface DesignStats {
  entities: number;
  byStatus: Partial<Record<(typeof ENTITY_STATUSES)[number], number>>;
  rules: { total: number; automated: number; partial: number; manual: number };
  tokens: number;
  tokensByType: Record<string, number>;
}
export interface DesignReport { errors: string[]; warnings: string[]; stats: DesignStats }
export function isColor(value: unknown): boolean;
/** `needle` occurs in `haystack` as whole tokens (no longer word or number around it). */
export function containsExact(haystack: string, needle: string): boolean;
export function validateOntology(doc: unknown, read: DesignReader): string[];
export function validateTokens(doc: unknown, read: DesignReader): string[];
export function validateDesign(docs: { ontology: unknown; tokens: unknown }, read: DesignReader): string[];
export function validateDesignReport(docs: { ontology: unknown; tokens: unknown }, read: DesignReader): DesignReport;
export function checkDesignFiles(root: string | URL): Promise<{ errors: string[]; warnings: string[]; stats: DesignStats | null; ontology: any; tokens: any }>;
export function formatDesignErrors(errors: string[]): string;

// Cross-check helpers: each returns actionable error strings (empty when fine) and never throws.
export function setEquals(expected: Iterable<unknown> | object, actual: Iterable<unknown> | object, what?: string): string[];
export function entitiesOf(ontology: unknown, concept: string, options?: { descendants?: boolean }): any[];
export function relationPairs(ontology: unknown, type: string): string[];
export function requireDescriptions(ontology: unknown): string[];
export function localeParity(translations: Record<string, object>, options?: { placeholders?: boolean; reference?: string; keys?: Iterable<string> }): string[];
export function normaliseColour(value: unknown): string;
export function cssColourInventory(cssText: string, tokens: unknown, exceptions?: string[] | Record<string, string>, options?: { functions?: boolean }): string[];
export function colourEvidence(tokens: unknown, options?: { forms?: (colour: string) => Iterable<string>; gradients?: boolean }): string[];
export interface CssRule {
  index: number;
  selectors: string[];
  body: string;
  declarations: { property: string; value: string; important: boolean }[];
  atRules: string[];
}
export function cssRules(cssText: string): CssRule[];
export function cssSpecificity(selector: string): [number, number, number];
export function checkComponents(tokens: unknown, cssText: string): string[];
export function constantsMatch(ontologyOrEntities: unknown, modules: object | object[], options?: { min?: number }): string[];
