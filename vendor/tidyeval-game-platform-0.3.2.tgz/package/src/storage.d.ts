type StorageLike = Pick<Storage, 'getItem' | 'setItem' | 'key' | 'length'>;
export function createProgressStore<P, A extends { id: string }>(options: {
  key: string; read: (raw: string | null) => P; apply: (progress: P, attempt: A) => unknown; durable?: boolean;
}): {
  ready(storage?: StorageLike): Promise<void>;
  load(storage?: StorageLike): P; isKey(key: string | null): boolean;
  saveSetting(key: string, value: unknown, storage?: StorageLike): Promise<P>;
  saveAttempt(attempt: A, storage?: StorageLike): Promise<P>;
};
