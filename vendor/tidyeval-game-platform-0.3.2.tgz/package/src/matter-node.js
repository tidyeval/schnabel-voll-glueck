import { createRequire } from 'node:module';
import { dirname, resolve } from 'node:path';
const require = createRequire(import.meta.url);
const root = dirname(require.resolve('phaser/package.json'));
// Phaser's browser entry needs a DOM; tests use its identical, pinned bundled engine.
const Matter = require(resolve(root, 'src/physics/matter-js/CustomMain.js'));
Matter.Common.setDecomp(require(resolve(root, 'src/physics/matter-js/poly-decomp/index.js')));
export default Matter;
