import Phaser from 'phaser';
export function createRuntime(options: {
  width: number; height: number; canvas?: HTMLCanvasElement; parent?: string | HTMLElement;
  create?: (scene: Phaser.Scene) => void;
  update: (now: number, seconds: number) => void;
}): Phaser.Game;
