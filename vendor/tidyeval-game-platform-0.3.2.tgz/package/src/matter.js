import Matter from '#matter-engine';

export { Matter };

/** Coordinates are game units, velocity is units/second, acceleration units/second². */
export function createPhysicsWorld(engine = Matter.Engine.create()) {
  engine.gravity.x = engine.gravity.y = engine.gravity.scale = 0;
  const owned = new Set();
  return {
    engine,
    add(body) { owned.add(body); Matter.Composite.add(engine.world, body); return body; },
    remove(body) { owned.delete(body); Matter.Composite.remove(engine.world, body); },
    step(seconds, beforeStep) {
      if (!Number.isFinite(seconds) || seconds < 0 || seconds > .1) throw new RangeError('Physics step must be between 0 and 0.1 seconds');
      const count = Math.ceil(seconds * 120);
      for (let i = 0; i < count; i++) {
        const dt = seconds / count;
        beforeStep?.(dt);
        Matter.Engine.update(engine, dt * 1000);
      }
    },
    dispose() {
      for (const body of owned) Matter.Composite.remove(engine.world, body);
      owned.clear(); Matter.Engine.clear(engine);
    },
  };
}

export function setVelocity(body, x, y) { Matter.Body.setVelocity(body, { x: x / 60, y: y / 60 }); }
export function velocity(body) { const v = Matter.Body.getVelocity(body); return { x: v.x * 60, y: v.y * 60 }; }
export function accelerate(body, x, y) { Matter.Body.applyForce(body, body.position, { x: body.mass * x / 1e6, y: body.mass * y / 1e6 }); }

/** Keep the original polygon origin when Matter recentres compound parts. */
export function polygonBody(points, options = {}) {
  const center = Matter.Vertices.centre(points);
  const { isStatic, ...bodyOptions } = options;
  // Static parts have infinite mass; build the compound before freezing its centroid.
  const body = Matter.Bodies.fromVertices(center.x, center.y, [points.map(p => ({ ...p }))], bodyOptions, true, false, 0, false);
  if (isStatic) Matter.Body.setStatic(body, true);
  return body;
}
