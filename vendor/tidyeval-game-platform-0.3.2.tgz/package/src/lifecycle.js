/** One owner for focus, visibility, audio gestures and native app lifecycle. */
export function bindLifecycle({ suspend, foreground, gesture, nativeApp, back, onError = console.error }) {
  const listeners = [], nativeListeners = [];
  const listen = (target, name, callback) => {
    target.addEventListener(name, callback);
    listeners.push(() => target.removeEventListener(name, callback));
  };
  const active = () => { if (!document.hidden) foreground?.(); };
  listen(window, 'blur', suspend);
  listen(window, 'focus', active);
  listen(window, 'pagehide', suspend);
  listen(document, 'visibilitychange', () => document.hidden ? suspend() : active());
  if (gesture) for (const name of ['pointerup', 'keydown']) listen(document, name, () => {
    if (!document.hidden) gesture();
  });
  if (nativeApp) {
    nativeListeners.push(nativeApp.addListener('appStateChange', ({ isActive }) => isActive ? active() : suspend()));
    if (back) nativeListeners.push(nativeApp.addListener('backButton', back));
    for (const pending of nativeListeners) pending.catch(error => onError('Native app lifecycle could not be registered', error));
  }
  return async function dispose() {
    for (const remove of listeners) remove();
    for (const pending of nativeListeners) {
      try { await (await pending).remove(); } catch (error) { onError('Native app lifecycle could not be removed', error); }
    }
  };
}
