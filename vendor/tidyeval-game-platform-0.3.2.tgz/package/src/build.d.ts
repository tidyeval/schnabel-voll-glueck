export function offlineVersion(bundle: Record<string, any>, assetDir: string, publicFiles: string[]): string;
export function serviceWorkerSource(namespace: string, version: string, files: string[]): string;
