export function setupPwa(options: {
  install: HTMLButtonElement; update: HTMLButtonElement; help: HTMLDialogElement; closeHelp: HTMLButtonElement;
  t: (key: string) => string; toast: (message: string) => void;
  base: string; enabled: boolean; native?: boolean;
}): () => void;
