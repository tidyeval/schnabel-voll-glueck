type Listener = Promise<{ remove(): Promise<void> }>;
export function bindLifecycle(options: {
  suspend: () => void; foreground?: () => void; gesture?: () => void;
  nativeApp?: { addListener(event: string, callback: (...args: any[]) => void): Listener };
  back?: () => void; onError?: (...args: any[]) => void;
}): () => Promise<void>;
