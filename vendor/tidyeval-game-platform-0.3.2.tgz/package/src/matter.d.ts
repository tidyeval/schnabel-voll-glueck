import 'phaser';
export const Matter: typeof MatterJS & {
  Query: typeof MatterJS.Query & { collides(body: MatterJS.BodyType, bodies: MatterJS.BodyType[]): MatterJS.ICollisionData[] };
};
export function createPhysicsWorld(engine?: MatterJS.Engine): {
  engine: MatterJS.Engine & { world: MatterJS.CompositeType };
  add<T extends MatterJS.BodyType>(body: T): T;
  remove(body: MatterJS.BodyType): void;
  step(seconds: number, beforeStep?: (seconds: number) => void): void;
  dispose(): void;
};
export function setVelocity(body: MatterJS.BodyType, x: number, y: number): void;
export function velocity(body: MatterJS.BodyType): { x: number; y: number };
export function accelerate(body: MatterJS.BodyType, x: number, y: number): void;
export function polygonBody(points: { x: number; y: number }[], options?: MatterJS.IChamferableBodyDefinition): MatterJS.BodyType;
