import Phaser from 'phaser';

/** Phaser owns scheduling; existing Canvas drawings need no texture upload. */
export function createRuntime({ width, height, canvas, parent, create, update }) {
  return new Phaser.Game({
    type: canvas ? Phaser.CANVAS : Phaser.AUTO,
    canvas, parent, width, height, transparent: true, banner: false,
    audio: { noAudio: true },
    physics: { default: 'matter', matter: { gravity: { x: 0, y: 0 }, autoUpdate: false } },
    render: { clearBeforeRender: !canvas },
    // Keep original simulation timesteps; Phaser must not smooth fake-clock or slow frames.
    fps: { smoothStep: false },
    scene: {
      create() { create?.(this); },
      update(now, delta) { update(now, Math.min(.1, Math.max(0, delta / 1000))); },
    },
  });
}
