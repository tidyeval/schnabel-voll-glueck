export function setupDiagnostics(game: string, version: string, situation: () => Record<string, unknown>, labels: Record<string, [string, string]>): void;
