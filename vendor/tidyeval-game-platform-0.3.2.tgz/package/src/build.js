import { createHash } from 'node:crypto';
import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';

export function offlineVersion(bundle, assetDir, publicFiles) {
  const hash = createHash('sha256');
  for (const name of Object.keys(bundle).sort()) {
    const output = bundle[name];
    hash.update(name).update(output.type === 'chunk' ? output.code : output.source);
  }
  for (const name of [...publicFiles].sort()) hash.update(name).update(readFileSync(resolve(assetDir, name)));
  // Changes to worker mechanics must also trigger an update.
  hash.update(readFileSync(new URL('./sw-template.js', import.meta.url)));
  return hash.digest('hex').slice(0, 12);
}

export function serviceWorkerSource(namespace, version, files) {
  if (!/^[a-z0-9-]+$/.test(namespace)) throw new Error('Invalid service worker cache namespace');
  return readFileSync(new URL('./sw-template.js', import.meta.url), 'utf8')
    .replace('__NAMESPACE__', namespace).replace('__VERSION__', version).replace('__ASSETS__', JSON.stringify(files));
}
