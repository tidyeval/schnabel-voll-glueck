// Keep error details bounded: messages, URLs and stacks can contain personal data.
export function setupDiagnostics(game, version, situation, labels) {
  const errors = [];
  const record = (kind, error, line, column) => {
    const name = ['Error', 'TypeError', 'ReferenceError', 'SyntaxError', 'RangeError', 'URIError', 'EvalError'].includes(error?.name) ? error.name : 'Unknown';
    errors.push({ kind, name, line: Number(line) || 0, column: Number(column) || 0, situation: situation() });
    if (errors.length > 10) errors.shift();
  };
  window.addEventListener('error', event => record('error', event.error, event.lineno, event.colno));
  window.addEventListener('unhandledrejection', event => record('unhandled rejection', event.reason, 0, 0));
  const details = document.getElementById('diagnostics');
  const summary = details.querySelector('summary');
  const field = details.querySelector('textarea');
  const refresh = () => {
    const [title, help] = labels[document.documentElement.lang] || labels.en;
    summary.textContent = title;
    field.setAttribute('aria-label', title);
    details.querySelector('p').textContent = help;
    const ua = navigator.userAgent;
    const browser = /Firefox\//.test(ua) ? 'Firefox' : /Edg\//.test(ua) ? 'Edge' : /Chrome\//.test(ua) ? 'Chrome' : /Safari\//.test(ua) ? 'Safari' : 'Other';
    const os = /Android/.test(ua) ? 'Android' : /iPhone|iPad|iPod/.test(ua) ? 'iOS' : /Windows/.test(ua) ? 'Windows' : /Mac OS/.test(ua) ? 'macOS' : /Linux/.test(ua) ? 'Linux' : 'Other';
    field.value = JSON.stringify({ game, version, device: { os, browser, viewport: [innerWidth, innerHeight], pixelRatio: devicePixelRatio }, situation: situation(), errors }, null, 2);
  };
  details.addEventListener('toggle', refresh);
  field.addEventListener('focus', refresh);
  new MutationObserver(refresh).observe(document.documentElement, { attributes: true, attributeFilter: ['lang'] });
  refresh();
}
