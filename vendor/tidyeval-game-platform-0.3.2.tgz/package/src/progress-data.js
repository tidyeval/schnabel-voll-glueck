const object = value => value !== null && typeof value === 'object' && !Array.isArray(value);
export const own = (value, key) => Object.prototype.hasOwnProperty.call(value, key);
export function put(value, key, entry) {
  Object.defineProperty(value, key, { value: entry, enumerable: true, configurable: true, writable: true });
}
export function validateJournal(data) {
  if (!object(data) || !own(data, 'base') || (data.base !== null && typeof data.base !== 'string') || !object(data.attempts) || !object(data.settings)) throw new Error('Invalid progress journal; saved data was preserved');
  return data;
}
export function legacyJournal(key, storage) {
  const prefix = `${key}-attempt:`, data = { base: storage.getItem(key), attempts: {}, settings: {} };
  for (let i = 0; i < storage.length; i++) {
    const entry = storage.key(i);
    if (!entry?.startsWith(prefix)) continue;
    const raw = storage.getItem(entry);
    try {
      const attempt = JSON.parse(raw);
      if (attempt && attempt.id === entry.slice(prefix.length) && typeof attempt.id === 'string' && attempt.id) put(data.attempts, attempt.id, attempt);
    } catch { /* Preserve malformed legacy entries without replaying them. */ }
  }
  return data;
}
export function progressFromJournal(data, read, apply) {
  const value = read(data.base);
  for (const attempt of Object.values(data.attempts)) apply(value, attempt);
  const settings = Object.entries(data.settings);
  for (const [name, setting] of settings) put(value, name, setting);
  return settings.length ? read(JSON.stringify(value)) : value;
}
