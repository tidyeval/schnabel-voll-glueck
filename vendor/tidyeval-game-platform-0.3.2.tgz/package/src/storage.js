import { createNativeProgressStore } from './native-storage.js';
import { legacyJournal, progressFromJournal } from './progress-data.js';

/** Mechanics only: the game owns validation, migration and attempt meaning. */
export function createProgressStore({ key, read, apply, durable = false }) {
  if (durable) return createNativeProgressStore({ key, read, apply });
  const prefix = `${key}-attempt:`;
  const load = (storage = localStorage) => progressFromJournal(legacyJournal(key, storage), read, apply);
  return {
    ready: async () => {}, load,
    isKey: entry => entry === key || Boolean(entry?.startsWith(prefix)),
    async saveSetting(name, value, storage = localStorage) {
      if (JSON.stringify(value) === undefined) throw new Error('Cannot save a non-serializable setting');
      const latest = load(storage); latest[name] = value;
      storage.setItem(key, JSON.stringify(latest));
      return latest;
    },
    async saveAttempt(attempt, storage = localStorage) {
      if (!attempt || typeof attempt.id !== 'string' || !attempt.id) throw new Error('Cannot save an attempt without an id');
      storage.setItem(prefix + attempt.id, JSON.stringify(attempt));
      const latest = load(storage);
      storage.setItem(key, JSON.stringify(latest));
      return latest;
    },
  };
}
