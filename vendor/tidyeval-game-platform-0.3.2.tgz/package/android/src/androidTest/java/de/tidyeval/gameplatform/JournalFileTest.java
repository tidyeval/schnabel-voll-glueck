package de.tidyeval.gameplatform;

import androidx.test.platform.app.InstrumentationRegistry;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;
import org.json.JSONObject;
import java.io.File;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.UUID;

public class JournalFileTest {
    private String key;
    private File directory;
    private JournalFile journal;
    private static final String BASELINE = "{\"base\":null,\"attempts\":{},\"settings\":{}}";

    @Before public void setUp() throws Exception {
        key = "test-" + UUID.randomUUID();
        File files = InstrumentationRegistry.getInstrumentation().getTargetContext().getFilesDir();
        directory = new File(files, "game-platform-journals");
        journal = new JournalFile(files);
    }

    @After public void tearDown() throws Exception {
        new File(directory, key + ".json").delete();
        new File(directory, key + ".json.pending").delete();
    }

    private void pending(String raw) throws Exception {
        try (FileOutputStream out = new FileOutputStream(new File(directory, key + ".json.pending"))) {
            out.write(raw.getBytes(StandardCharsets.UTF_8));
            out.getFD().sync();
        }
    }

    @Test public void testBaselineMergeAndDuplicateRetry() throws Exception {
        assertNull(journal.load(key, null));
        assertEquals(0, new JSONObject(journal.load(key, BASELINE)).getLong("revision"));
        journal.commit(key, "{\"type\":\"attempt\",\"attempt\":{\"id\":\"one\",\"score\":7}}");
        JSONObject duplicate = new JSONObject(journal.commit(key, "{\"type\":\"attempt\",\"attempt\":{\"id\":\"one\",\"score\":99}}"));
        assertEquals(2, duplicate.getLong("revision"));
        assertEquals(7, duplicate.getJSONObject("journal").getJSONObject("attempts").getJSONObject("one").getInt("score"));
        JSONObject settings = new JSONObject(journal.commit(key, "{\"type\":\"setting\",\"name\":\"music\",\"value\":false}"));
        assertFalse(settings.getJSONObject("journal").getJSONObject("settings").getBoolean("music"));
        try { journal.commit(key, "{\"type\":\"setting\",\"name\":\"music\"}"); fail("missing value accepted"); } catch (JournalFile.Failure expected) { assertTrue(expected.getMessage().contains("validation")); }
        assertEquals(3, new JSONObject(journal.load(key, null)).getLong("revision"));
    }

    @Test public void testNewerPendingRecoveryAndInvalidPendingPreservation() throws Exception {
        JSONObject main = new JSONObject(journal.load(key, BASELINE));
        main.put("revision", 1);
        main.getJSONObject("journal").getJSONObject("settings").put("music", false);
        pending(main.toString());
        JSONObject recovered = new JSONObject(journal.load(key, null));
        assertEquals(1, recovered.getLong("revision"));
        assertFalse(recovered.getJSONObject("journal").getJSONObject("settings").getBoolean("music"));
        assertFalse(new File(directory, key + ".json.pending").exists());
        JSONObject older = new JSONObject(recovered.toString()).put("revision", 0);
        pending(older.toString());
        assertEquals(1, new JSONObject(journal.load(key, null)).getLong("revision"));
        assertTrue(new File(directory, key + ".json.pending").exists());
        pending("broken");
        assertEquals(1, new JSONObject(journal.load(key, null)).getLong("revision"));
        assertTrue(new File(directory, key + ".json.pending").exists());
    }

    @Test public void testCorruptionInvalidKeysAndOverflowFail() throws Exception {
        journal.load(key, BASELINE);
        try (FileOutputStream out = new FileOutputStream(new File(directory, key + ".json"))) { out.write("bad".getBytes(StandardCharsets.UTF_8)); }
        try { journal.load(key, BASELINE); fail("corruption must not reset progress"); } catch (JournalFile.Failure expected) { assertTrue(expected.getMessage().contains("recovery")); }
        try { journal.load("../escape", null); fail("invalid key accepted"); } catch (JournalFile.Failure expected) { assertTrue(expected.getMessage().contains("key")); }
        JSONObject max = new JSONObject().put("version", 1).put("revision", 9007199254740991L).put("journal", new JSONObject(BASELINE));
        pending(max.toString());
        try { journal.commit(key, "{\"type\":\"setting\",\"name\":\"music\",\"value\":true}"); fail("overflow accepted"); } catch (JournalFile.Failure expected) { assertTrue(expected.getMessage().contains("revision")); }
    }
}
