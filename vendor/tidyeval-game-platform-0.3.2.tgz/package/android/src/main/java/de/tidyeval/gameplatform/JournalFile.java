package de.tidyeval.gameplatform;

import android.system.Os;
import android.system.OsConstants;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.StandardCharsets;
import java.util.Iterator;

final class JournalFile {
    private static final long MAX_REVISION = 9007199254740991L;
    private static final Object LOCK = new Object();
    private final File parent;

    JournalFile(File filesDir) { parent = new File(filesDir, "game-platform-journals"); }

    static final class Failure extends Exception {
        Failure(String stage) { super(stage); }
    }

    String load(String key, String baseline) throws Failure {
        synchronized (LOCK) {
            validateKey(key);
            ensureDirectory();
            JSONObject record = recover(key);
            if (record != null) return record.toString();
            if (baseline == null) return null;
            JSONObject journal = parseJournal(baseline, "baseline validation");
            try {
                record = new JSONObject().put("version", 1).put("revision", 0).put("journal", journal);
            } catch (JSONException e) { throw new Failure("baseline validation"); }
            write(key, record);
            return record.toString();
        }
    }

    String commit(String key, String operation) throws Failure {
        synchronized (LOCK) {
            validateKey(key);
            ensureDirectory();
            JSONObject record = recover(key);
            if (record == null) throw new Failure("missing baseline; initialize and retry");
            try {
                long revision = record.getLong("revision");
                if (revision >= MAX_REVISION) throw new Failure("revision limit");
                JSONObject change = parseObject(operation, "operation validation");
                JSONObject journal = record.getJSONObject("journal");
                String type = requireString(change, "type");
                if ("attempt".equals(type)) {
                    JSONObject attempt = change.getJSONObject("attempt");
                    String id = requireString(attempt, "id");
                    JSONObject attempts = journal.getJSONObject("attempts");
                    if (!attempts.has(id)) attempts.put(id, attempt);
                } else if ("setting".equals(type)) {
                    String name = requireString(change, "name");
                    if (!change.has("value")) throw new JSONException("missing value");
                    journal.getJSONObject("settings").put(name, change.get("value"));
                } else throw new JSONException("unknown operation");
                record.put("revision", revision + 1);
                validateRecord(record);
                write(key, record);
                return record.toString();
            } catch (JSONException e) { throw new Failure("operation validation"); }
        }
    }

    private void validateKey(String key) throws Failure {
        if (key == null || !key.matches("[A-Za-z0-9._-]{1,160}")) throw new Failure("key validation");
    }

    private void ensureDirectory() throws Failure {
        if (!parent.isDirectory() && !parent.mkdir() && !parent.isDirectory()) throw new Failure("create journal directory");
        syncDirectory(parent.getParentFile(), "sync parent directory");
    }

    private JSONObject recover(String key) throws Failure {
        File main = new File(parent, key + ".json"), pending = new File(parent, key + ".json.pending");
        boolean mainExists = main.exists(), pendingExists = pending.exists();
        JSONObject current = readCandidate(main, mainExists), next = readCandidate(pending, pendingExists);
        if (next != null && (current == null || next.optLong("revision", -1) > current.optLong("revision", -1))) {
            syncFile(pending, "sync pending recovery");
            rename(pending, main, "promote pending recovery");
            syncDirectory(parent, "sync recovered journal directory");
            return next;
        }
        if (current != null) {
            syncFile(main, "sync current journal");
            syncDirectory(parent, "sync current journal directory");
            return current;
        }
        if (mainExists || pendingExists) throw new Failure("journal recovery; stored records are invalid");
        return null;
    }

    private JSONObject readCandidate(File file, boolean exists) throws Failure {
        if (!exists) return null;
        try (FileInputStream input = new FileInputStream(file); ByteArrayOutputStream bytes = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[8192];
            for (int n; (n = input.read(buffer)) != -1;) bytes.write(buffer, 0, n);
            String raw = StandardCharsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.REPORT)
                .onUnmappableCharacter(CodingErrorAction.REPORT).decode(ByteBuffer.wrap(bytes.toByteArray())).toString();
            JSONObject record = parseObject(raw, "record validation");
            validateRecord(record);
            return record;
        } catch (CharacterCodingException | JSONException | Failure e) { return null; }
        catch (IOException e) { throw new Failure("read journal"); }
    }

    private static JSONObject parseObject(String raw, String stage) throws Failure {
        if (raw == null) throw new Failure(stage);
        try {
            JSONTokener tokener = new JSONTokener(raw);
            Object value = tokener.nextValue();
            if (!(value instanceof JSONObject) || tokener.nextClean() != 0) throw new JSONException("invalid object");
            return (JSONObject) value;
        } catch (JSONException e) { throw new Failure(stage); }
    }

    private static JSONObject parseJournal(String raw, String stage) throws Failure {
        JSONObject journal = parseObject(raw, stage);
        try { validateJournal(journal); return journal; }
        catch (JSONException e) { throw new Failure(stage); }
    }

    private static void validateRecord(JSONObject record) throws JSONException {
        if (!safeInteger(record.opt("version"), 1, 1) || !safeInteger(record.opt("revision"), 0, MAX_REVISION)) throw new JSONException("invalid version or revision");
        validateJournal(record.getJSONObject("journal"));
    }

    private static void validateJournal(JSONObject journal) throws JSONException {
        if (!journal.has("base") || !(journal.isNull("base") || journal.opt("base") instanceof String)) throw new JSONException("invalid base");
        JSONObject attempts = journal.getJSONObject("attempts");
        journal.getJSONObject("settings");
        Iterator<String> ids = attempts.keys();
        while (ids.hasNext()) {
            String id = ids.next();
            if (id.isEmpty() || !id.equals(requireString(attempts.getJSONObject(id), "id"))) throw new JSONException("invalid attempt");
        }
        if (journal.toString() == null) throw new JSONException("invalid JSON");
    }

    private static String requireString(JSONObject object, String key) throws JSONException {
        Object value = object.get(key);
        if (!(value instanceof String) || ((String) value).isEmpty()) throw new JSONException("invalid string");
        return (String) value;
    }

    private static boolean safeInteger(Object value, long min, long max) {
        if (!(value instanceof Number)) return false;
        try {
            long number = new java.math.BigDecimal(value.toString()).longValueExact();
            return number >= min && number <= max;
        } catch (ArithmeticException | NumberFormatException e) { return false; }
    }

    private void write(String key, JSONObject record) throws Failure {
        File pending = new File(parent, key + ".json.pending"), main = new File(parent, key + ".json");
        try (FileOutputStream output = new FileOutputStream(pending)) {
            output.write(record.toString().getBytes(StandardCharsets.UTF_8));
            output.flush();
            output.getFD().sync();
        } catch (IOException e) { throw new Failure("write and sync pending journal"); }
        rename(pending, main, "replace journal");
        syncDirectory(parent, "sync journal directory");
    }

    private static void syncFile(File file, String stage) throws Failure {
        try (FileOutputStream output = new FileOutputStream(file, true)) { output.getFD().sync(); }
        catch (IOException e) { throw new Failure(stage); }
    }

    private static void rename(File from, File to, String stage) throws Failure {
        try { Os.rename(from.getAbsolutePath(), to.getAbsolutePath()); }
        catch (Exception e) { throw new Failure(stage); }
    }

    private static void syncDirectory(File directory, String stage) throws Failure {
        java.io.FileDescriptor fd = null;
        boolean failed = false;
        try {
            fd = Os.open(directory.getAbsolutePath(), OsConstants.O_RDONLY, 0);
            Os.fsync(fd);
        } catch (Exception e) { failed = true; }
        finally { if (fd != null) try { Os.close(fd); } catch (Exception e) { failed = true; } }
        if (failed) throw new Failure(stage);
    }
}
