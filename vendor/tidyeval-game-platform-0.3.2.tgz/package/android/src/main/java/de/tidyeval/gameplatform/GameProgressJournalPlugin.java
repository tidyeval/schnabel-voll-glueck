package de.tidyeval.gameplatform;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import org.json.JSONObject;

@CapacitorPlugin(name = "GameProgressJournal")
public class GameProgressJournalPlugin extends Plugin {
    @PluginMethod
    public void load(PluginCall call) {
        String key = call.getString("key"), baseline = call.getString("baseline");
        execute(() -> run(call, key, "load", () -> new JournalFile(getContext().getFilesDir()).load(key, baseline)));
    }

    @PluginMethod
    public void commit(PluginCall call) {
        String key = call.getString("key"), operation = call.getString("operation");
        execute(() -> run(call, key, "commit", () -> new JournalFile(getContext().getFilesDir()).commit(key, operation)));
    }

    private interface Action { String run() throws JournalFile.Failure; }

    private void run(PluginCall call, String key, String operation, Action action) {
        try {
            String record = action.run();
            JSObject result = new JSObject();
            result.put("record", record == null ? JSONObject.NULL : record);
            call.resolve(result);
        } catch (JournalFile.Failure error) {
            String label = key != null && key.matches("[A-Za-z0-9._-]{1,160}") ? key : "invalid key";
            call.reject("Progress journal " + label + " " + operation + " failed: " + error.getMessage());
        } catch (RuntimeException error) {
            call.reject("Progress journal " + operation + " failed unexpectedly; retry");
        }
    }
}
