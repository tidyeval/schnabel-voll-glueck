# Shared game platform

Private package for the separate Phaser + Matter editions of Schnabelglück, Bounce & Boo and Santa’s Meltdown. Source owner: this directory. [Architecture, objectives and acceptance](ARCHITECTURE.md).

```sh
npm ci
./check
npm pack --pack-destination /tmp
```

Each game tracks the exact `tidyeval-game-platform-<version>.tgz` under `vendor/`, with a `file:vendor/...` dependency and lockfile integrity. A fresh checkout builds without sibling directories, an npm account or a private registry. Change this source, run the focused source tests, bump the version, pack once, copy that same archive into each consumer and explicitly update their dependency. Then run `./check` to verify adoption as well as the source checks. Never edit the installed or vendored copies. Nothing is published by these commands.

Exports: `runtime` (Phaser scene and scheduling), `lifecycle` (focus/native suspension and audio gestures), `storage` (attempt ledger mechanics), `pwa` (install/update controls), `matter` (physical integration/units and polygon geometry), `build` (offline fingerprint and scoped worker generation). Game-specific rules and data validation stay in each game.

See the implementation and verification evidence in [ARCHITECTURE.md](ARCHITECTURE.md#current-implementation-and-next-work-2026-11-10). `./check` also verifies that the original worktrees and experimental installation identities are isolated.

Dedicated Santa mode checks: `node tests/santa-browser.mjs`. Independent clean installations/builds: `node tests/standalone-builds.mjs` (or `GAME=<edition>` for one affected edition).

Native progress uses `createProgressStore({ durable: true, ... })`: await `ready()` before enabling play, and await every save. Capacitor discovers `GameProgressJournal` from this same installed package during `npx cap sync`; no separate storage dependency is required. Native records use a private, checked file journal with file sync, atomic same-directory replacement and directory sync. Valid newer pending records recover without double counting; corrupt records block initialization rather than overwriting progress. Existing localStorage and 0.3.0 IndexedDB data are imported without rewriting their contents. Web consumers retain the localStorage ledger.

The JavaScript API is unchanged from 0.3.0. The 0.3.1 native transport replaces IndexedDB after actual Android force-stop/cold-VM tests exposed acknowledged writes that later became unreadable in the underlying LevelDB WAL. Final native acceptance results and limits are recorded in the maintained architecture document.
