import Foundation
import CoreFoundation
import Darwin

final class Journal {
    private let directory: URL
    private let maxRevision: Int64 = 9_007_199_254_740_991
    init(directory: URL) { self.directory = directory }

    private func failure(_ stage: String) -> NSError {
        NSError(domain: "GameProgressJournal", code: Int(errno), userInfo: [NSLocalizedDescriptionKey: "Journal \(stage) failed"])
    }
    private func paths(_ key: String) throws -> (URL, URL) {
        guard key.range(of: "^[A-Za-z0-9._-]{1,160}$", options: .regularExpression) != nil else { throw failure("invalid key") }
        let main = directory.appendingPathComponent(key + ".json")
        return (main, directory.appendingPathComponent(key + ".json.pending"))
    }
    private func syncDirectory(_ url: URL) throws {
        let fd = open(url.path, O_RDONLY)
        guard fd >= 0 else { throw failure("open directory") }
        let result = fsync(fd), savedErrno = errno
        let closed = close(fd)
        if result != 0 { errno = savedErrno; throw failure("sync directory") }
        if closed != 0 { throw failure("close directory") }
    }
    private func ensureDirectory(_ url: URL) throws {
        var isDirectory: ObjCBool = false
        if FileManager.default.fileExists(atPath: url.path, isDirectory: &isDirectory) {
            guard isDirectory.boolValue else { throw failure("directory") }
            return
        }
        try ensureDirectory(url.deletingLastPathComponent())
        do { try FileManager.default.createDirectory(at: url, withIntermediateDirectories: false) }
        catch { throw failure("create directory") }
        try syncDirectory(url.deletingLastPathComponent())
        try syncDirectory(url)
    }
    private func validJournal(_ value: Any) -> [String: Any]? {
        guard let object = value as? [String: Any], object["base"] is String || object["base"] is NSNull,
              let attempts = object["attempts"] as? [String: Any], object["settings"] is [String: Any] else { return nil }
        for (id, raw) in attempts {
            guard !id.isEmpty, let attempt = raw as? [String: Any], let storedID = attempt["id"] as? String, storedID == id else { return nil }
        }
        return object
    }
    private func revision(_ value: Any?) -> Int64? {
        guard let number = value as? NSNumber, CFGetTypeID(number) != CFBooleanGetTypeID() else { return nil }
        let double = number.doubleValue
        guard double.isFinite, double >= 0, double <= Double(maxRevision), double.rounded(.towardZero) == double else { return nil }
        return Int64(double)
    }
    private func parseRecord(_ data: Data) -> (Int64, [String: Any])? {
        guard let raw = try? JSONSerialization.jsonObject(with: data), let record = raw as? [String: Any],
              revision(record["version"]) == 1, let rev = revision(record["revision"]),
              let journalValue = record["journal"], let journal = validJournal(journalValue) else { return nil }
        return (rev, journal)
    }
    private func readRecord(_ url: URL) throws -> (Int64, [String: Any])? {
        guard FileManager.default.fileExists(atPath: url.path) else { return nil }
        do { return parseRecord(try Data(contentsOf: url)) }
        catch { throw failure("read record") }
    }
    private func encode(_ revision: Int64, _ journal: [String: Any]) throws -> Data {
        do { return try JSONSerialization.data(withJSONObject: ["version": 1, "revision": revision, "journal": journal], options: [.sortedKeys]) }
        catch { throw failure("encode record") }
    }
    private func syncFile(_ url: URL) throws {
        let fd = open(url.path, O_RDONLY)
        guard fd >= 0 else { throw failure("open pending") }
        let result = fsync(fd), savedErrno = errno
        let closed = close(fd)
        if result != 0 { errno = savedErrno; throw failure("sync pending") }
        if closed != 0 { throw failure("close pending") }
    }
    private func promote(_ pending: URL, _ main: URL) throws {
        try syncFile(pending)
        guard rename(pending.path, main.path) == 0 else { throw failure("rename") }
        try syncDirectory(directory)
    }
    private func recover(_ main: URL, _ pending: URL) throws -> (Int64, [String: Any])? {
        let mainExists = FileManager.default.fileExists(atPath: main.path)
        let pendingExists = FileManager.default.fileExists(atPath: pending.path)
        let current = try readRecord(main), candidate = try readRecord(pending)
        if let candidate, current == nil || candidate.0 > current!.0 {
            try promote(pending, main)
            return candidate
        }
        if let current {
            try syncFile(main)
            try syncDirectory(directory)
            return current
        }
        if mainExists || pendingExists { throw failure("recover invalid files") }
        return nil
    }
    private func persist(_ data: Data, main: URL, pending: URL) throws {
        let fd = open(pending.path, O_WRONLY | O_CREAT | O_TRUNC, mode_t(0o600))
        guard fd >= 0 else { throw failure("open pending") }
        do {
            try data.withUnsafeBytes { raw in
                guard let base = raw.baseAddress else { return }
                var offset = 0
                while offset < raw.count {
                    let written = Darwin.write(fd, base.advanced(by: offset), raw.count - offset)
                    if written < 0 && errno == EINTR { continue }
                    guard written > 0 else { throw failure("write pending") }
                    offset += written
                }
            }
            guard fsync(fd) == 0 else { throw failure("sync pending") }
        } catch { _ = close(fd); throw error }
        guard close(fd) == 0 else { throw failure("close pending") }
        guard rename(pending.path, main.path) == 0 else { throw failure("rename") }
        try syncDirectory(directory)
    }
    func load(key: String, baseline: String?) throws -> String? {
        let (main, pending) = try paths(key)
        try ensureDirectory(directory)
        if let current = try recover(main, pending) { return String(decoding: try encode(current.0, current.1), as: UTF8.self) }
        guard let baseline else { return nil }
        guard let raw = try? JSONSerialization.jsonObject(with: Data(baseline.utf8)), let journal = validJournal(raw) else { throw failure("invalid baseline") }
        let data = try encode(0, journal)
        try persist(data, main: main, pending: pending)
        return String(decoding: data, as: UTF8.self)
    }
    func commit(key: String, operation: String) throws -> String {
        let (main, pending) = try paths(key)
        try ensureDirectory(directory)
        guard let current = try recover(main, pending) else { throw failure("missing baseline") }
        guard current.0 < maxRevision else { throw failure("revision overflow") }
        guard let raw = try? JSONSerialization.jsonObject(with: Data(operation.utf8)), let op = raw as? [String: Any], let type = op["type"] as? String else { throw failure("invalid operation") }
        var journal = current.1
        if type == "attempt", let attempt = op["attempt"] as? [String: Any], let id = attempt["id"] as? String, !id.isEmpty {
            var attempts = journal["attempts"] as! [String: Any]
            if attempts[id] == nil { attempts[id] = attempt }
            journal["attempts"] = attempts
        } else if type == "setting", let name = op["name"] as? String, !name.isEmpty, let value = op["value"] {
            var settings = journal["settings"] as! [String: Any]
            settings[name] = value
            journal["settings"] = settings
        } else { throw failure("invalid operation") }
        let data = try encode(current.0 + 1, journal)
        try persist(data, main: main, pending: pending)
        return String(decoding: data, as: UTF8.self)
    }
}
