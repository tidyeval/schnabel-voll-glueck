import Capacitor
import Foundation

@objc(GameProgressJournalPlugin)
public class GameProgressJournalPlugin: CAPPlugin, CAPBridgedPlugin {
    public let identifier = "GameProgressJournalPlugin"
    public let jsName = "GameProgressJournal"
    public let pluginMethods: [CAPPluginMethod] = [
        CAPPluginMethod(name: "load", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "commit", returnType: CAPPluginReturnPromise)
    ]
    private static let queue = DispatchQueue(label: "game-platform.progress-journal")

    @objc public func load(_ call: CAPPluginCall) {
        guard let key = call.getString("key") else { call.reject("Journal load: missing key"); return }
        let baseline = call.getString("baseline")
        Self.queue.async {
            do {
                let directory = try self.directory()
                let record = try Journal(directory: directory).load(key: key, baseline: baseline)
                call.resolve(["record": record as Any? ?? NSNull()])
            } catch { call.reject("Journal load failed: \(error.localizedDescription)") }
        }
    }
    @objc public func commit(_ call: CAPPluginCall) {
        guard let key = call.getString("key"), let operation = call.getString("operation") else { call.reject("Journal commit: missing key or operation"); return }
        Self.queue.async {
            do {
                let record = try Journal(directory: self.directory()).commit(key: key, operation: operation)
                call.resolve(["record": record])
            } catch { call.reject("Journal commit failed: \(error.localizedDescription)") }
        }
    }
    private func directory() throws -> URL {
        guard let base = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask).first else {
            throw NSError(domain: "GameProgressJournal", code: 1, userInfo: [NSLocalizedDescriptionKey: "Application support directory unavailable"])
        }
        return base.appendingPathComponent("game-platform-journals", isDirectory: true)
    }
}
