# Design ontology and design tokens (format version 1)

Each game keeps its design knowledge in two game-owned JSON files. This package only provides the validator and game-neutral cross-check helpers (`@tidyeval/game-platform/design`). The format is game-neutral: nothing in it is specific to one game. Ownership is described in [ARCHITECTURE.md](ARCHITECTURE.md#design-ontology-and-tokens-036).

```
<game>/design/ontology.json   what exists in the game and which design rules hold
<game>/design/tokens.json     how it looks, moves and sounds: tokens, components, characters
<game>/tests/design.test.js   runs the validator and the game's own cross-checks against code
```

Every factual statement points at the real code through **evidence**: `{ "file": "src/game.js", "contains": "CHASE = {" }`. The file path is relative to the game root, may not leave it, and the file must contain the string verbatim **as whole tokens**: where the string starts or ends with a letter, digit, `_` or `$`, the file may not continue that word or number there (since 0.3.5). So `"STOMP_V = 1050"` does not match `STOMP_V = 10500`, `"0.5"` does not match `10.55`, and `"drawSpike"` does not match `drawSpikes`. Renaming or removing the symbol makes the design test fail, so the files cannot silently drift from the code. Prefer short, stable strings (a constant name, a function name, a CSS selector, a literal value). The same whole-token rule applies to rule check test names.

Version 1 files stay valid across 0.3.x; everything added in 0.3.5 is optional.

Ids start with a letter and use letters, digits, `.`, `_` and `-`. Ids are unique within a file (concepts, entities, relation types and rules share one namespace; tokens, components and characters share another). Unknown fields are errors, so typos are caught.

## `design/ontology.json`

| Field | Required | Content |
| --- | --- | --- |
| `format` | yes | `"tidyeval-design-ontology"` |
| `version` | yes | `1` |
| `game` | yes | Game identifier; must equal `tokens.json`'s `game` |
| `description` | no | Free text |
| `concepts[]` | yes | `{ id, description, label?, parent?, evidence? }`: classes. `parent` must be a concept id; parent chains may not cycle. |
| `entities[]` | yes | `{ id, concept, label?, description?, status?, properties?, evidence }`: instances of a concept. `evidence` is a non-empty list. `properties` is a free JSON object of real values (constants, timings, points), except for the reserved keys below. Where the code has an identifier (an item kind, a stage id), use it as the entity id so tests can compare both sets. |
| `relationTypes[]` | no | `{ id, description, from?, to? }`. Optional `from`/`to` concept ids constrain the endpoints (an entity of that concept or a sub-concept). |
| `relations[]` | no | `{ from, type, to, note?, evidence? }`: typed edges between entity or concept ids; duplicates are errors. |
| `rules[]` | yes | `{ id, statement, rationale?, appliesTo?, check, evidence? }`: design principles the team decided. |

A rule's `check` is one of:

- `{ "test": "tests/game.test.js", "name": "<test name>" }`: an automated check. The test file must exist and contain the name verbatim. Cite the whole name. A name written with an escaped quote (`'the stage\'s moment'`) cannot be cited verbatim, so write such test names in double quotes in the test file (`"the stage's moment"`) and cite them as written. Optional fields:
  - `"runner"`: a lowercase runner name when the test is not a `node --test` file, for example `"playwright"` for `tests/menu.spec.mjs`. The validator only checks that the file contains the name; running it stays with the game.
  - `"covers": "partial"` with `"gap": "<what the test does not cover>"` (at least 10 characters) when the test establishes only part of the rule. `covers` defaults to `"full"`; `gap` is only allowed with `"partial"`.
- a non-empty list of such objects, when several tests together establish the rule; one partial entry makes the rule partial;
- `{ "manual": "<reason>" }`: not automated, with a reason of at least 10 characters (for example subjective feel or device-only behaviour).

### Entity `status`

Optional; without it an entity is `built`. Use it so the files can describe honest gaps without pretending they are features:

| `status` | Meaning |
| --- | --- |
| `built` | In the game and working (default). |
| `partial` | In the game, but only part of it works or is wired. |
| `prototype` | Exists only in a test track, greybox or prototype level. |
| `planned` | Decided, not built yet (evidence points at the plan or a stub). |
| `dormant` | Code exists but nothing in the game can trigger it. |
| `unused` | Declared in the code (a constant, a type member) but never used. |
| `rejected` | Tried and deliberately dropped; kept so it is not reinvented. |

Game-specific life cycles (for example a level that is `greybox`, `locked` or `playable`) stay in `properties` and in the game's own tests.

### Reserved property conventions

- `properties.constants`: `{ "<EXPORT_NAME>": <value>, ... }`. Each key names an export of the game's code, or a dotted path into one (`"GADGETS.zipSpeed"`, `"NEW_KINDS.zombie"`, `"SIZE.0"`; since 0.3.6), and the value is its exact current value (objects and arrays deep-compared). `constantsMatch` checks them against the modules the game passes; numbers stated here need no other evidence.
- `properties.telegraph`: how the player is warned before a hazard can hurt. `{ "channels": [...], "announce": "<game signal>", "danger": "<game moment>", "leadSeconds": <n>, "leadFrom"?: "<code>" or ["<code>", ...], "colour"?: "{color.token}", "probe"?: <any>, "exception"?: "<reason>" }`. `channels` lists the warning cues (sound, pose, colour, text); a channel written as a token reference (`"{sound.howl}"`) must name a token in `tokens.json`. `announce` and `danger` are strings the game's own simulation understands; `leadSeconds` is the promised time between them; `leadFrom` names the code constants or expression the lead time derives from (`"SPIDER.warn + SPIDER.dropTime"`; structure only, the game's test computes it); `colour` must reference a colour token in `tokens.json`; `probe` is free set-up data for the game's simulation and is not a design claim. With `exception` (a reason of at least 10 characters) the other fields become optional and the exception is listed as a warning. The validator checks the structure only; simulating the hazard stays in the game's test.
- `properties.telegraphs`: `{ "<name>": <telegraph>, ... }` for an entity with several attacks.

### Contract entities

A **contract** is an ordinary entity (by convention of a concept `Contract`, id `contract.<topic>`) whose `properties` hold the numbers and field lists a family of game data must satisfy: required and optional fields of a stage, damage bands, pacing points. It has no special engine: the game's test loads the contract entity and checks every stage, hazard or wave against it, so a new stage that breaks the contract fails with a precise message.

## `design/tokens.json`

| Field | Required | Content |
| --- | --- | --- |
| `format` | yes | `"tidyeval-design-tokens"` |
| `version` | yes | `1` |
| `game` | yes | Same as the ontology |
| `description` | no | Free text |
| `tokens` | yes | Object `id → { type, value, description?, evidence? }`. Dotted ids group tokens (`color.button.primary`). |
| `components[]` | no | `{ id, description, label?, selector?, entity?, tokens, variants?, evidence }`. `tokens` maps a property name to a token reference. `variants[]` are `{ id, label?, description?, selector?, tokens, evidence? }`. `entity` must be an ontology entity id. |
| `characters[]` | no | `{ id, label?, description?, entity?, palette, proportions?, expressions?, evidence }`. `palette` maps a role to a colour token reference; `proportions` holds real numeric constants; `expressions[]` are `{ id, description, evidence }`. |

A token value is either a literal or a reference `"{other.token}"` to a token of the same type. Literal values need `evidence`; references inherit it. Reference chains may not cycle.

| Type | Literal value |
| --- | --- |
| `color` | `#rgb`, `#rgba`, `#rrggbb`, `#rrggbbaa`, `rgb(r,g,b)`, `rgba(r,g,b,a)` |
| `gradient` | `[{ "at": 0..1, "color": <color or reference> }, ...]`, at least two stops in ascending order |
| `dimension` | number, `"<n>px|cqw|cqh|%|em|rem|vw|vh|svh|dvh"`, or `clamp()/min()/max()/calc()` |
| `duration` | `"<n>s"` or `"<n>ms"` |
| `number` | finite number |
| `fontFamily`, `string` | non-empty string |
| `fontWeight` | integer 1–1000 |
| `easing` | `cubic-bezier(a,b,c,d)`, `steps(n)`, `linear`, `ease`, `ease-in`, `ease-out`, `ease-in-out` |
| `sound` | tones `{ "notes": [{ "hz", "seconds", "volume"?, "wave"?, "delay"?, "slideTo"? }] }` (`wave`: `sine`, `triangle`, `square`, `sawtooth`); a sample `{ "kind": "sample", "file", "gain"?, "loop"? }` (`file` must exist in the game); or noise `{ "kind": "noise", "duration", "filter"?: { "type", "hz", "q"? }, "gain"? }` (`duration` in seconds, `type` a Web Audio filter type such as `lowpass`) |
| `haptic` | `{ "web": <ms> or [<ms>, ...], "native"?: "<style>" }`: the `navigator.vibrate` pattern and the native impact style name |

Haptics are best kept as `haptic` tokens (one per effect), with a game-owned test that maps each game event to its token and compares the token values with the code's haptic table, rather than as ontology entities.

Any token may be `null` or `"none"` to state that a value is deliberately absent (for example a stage without a tint); it needs no evidence. A gradient whose stops are all references needs no evidence of its own.

## Validator

```js
import { checkDesignFiles, formatDesignErrors } from '@tidyeval/game-platform/design';
const { errors, warnings, stats } = await checkDesignFiles(new URL('../', import.meta.url)); // game root
assert.deepEqual(errors, [], formatDesignErrors(errors));
```

`warnings` lists partly automated rules with their gaps and telegraph exceptions; `stats` counts entities by status, rules as automated / partial / manual, and tokens by type. `validateDesignReport(docs, read)` returns the same `{ errors, warnings, stats }` for parsed documents.

`validateOntology(doc, read)`, `validateTokens(doc, read)` and `validateDesign({ ontology, tokens }, read)` take parsed JSON and a `read(path)` callback that returns a file's text or `null`. They return a list of messages such as

```
ontology entities[shark].evidence[0]: src/game.js does not contain "case 'shark2'"; update the evidence to the current code or restore the symbol
```

The validator never throws for malformed input, and reports invalid JSON, missing files and failing readers as errors. It checks structure only. Whether the *content* matches the game (every encounter kind is an entity, every locale has every key, CSS colours come from tokens) is a cross-check in the game's `tests/design.test.js`, built from the helpers below.

## Cross-check helpers

The game supplies the data (its exports, CSS text, translations); each helper returns a list of actionable messages, empty when fine, and never throws. Use them as `assert.deepEqual(helper(...), [])`.

| Helper | Checks |
| --- | --- |
| `setEquals(expected, actual, what?)` | Both directions of "the code's set equals the declared set"; an object counts by its keys. |
| `entitiesOf(ontology, concept, { descendants? })` | Entities of a concept and (default) its sub-concepts. |
| `relationPairs(ontology, type)` | Sorted `"from > to"` strings of one relation type, to compare with the code. |
| `requireDescriptions(ontology)` | Every entity and concept has a description. |
| `localeParity(translations, { placeholders?, reference?, keys? })` | Every key (nested objects flattened to dotted keys) is a non-empty string in every locale with the same `{placeholder}` set as the reference locale (default: the first); `keys` the code uses must exist too. |
| `cssColourInventory(css, tokens, exceptions, { functions? })` | Every literal colour in the CSS is a token value (colour or gradient stop) or a listed exception (list, or object colour → reason); exceptions that are unused or already tokens are reported. `functions: false` inventories hex colours only. |
| `colourEvidence(tokens, { forms?, gradients? })` | Each literal colour token (and gradient stop) occurs in its own evidence strings; `forms(colour)` adds spellings the code uses, such as `[r, g, b]`. |
| `valueEvidence(tokens, { forms?, measured? })` | Each number in a literal `number`, `fontWeight`, `duration`, `dimension`, `easing`, `sound` or `haptic` token occurs as a whole number in one of its evidence strings (`.5` = `0.5` = `0.50`; a duration also in the other unit, `0.25s` ~ `250`), so a value changed only in tokens.json fails. `forms(value, { id, path, token })` returns extra spellings to look for (a computed delay such as `"i * .055"`); `measured` lists token ids or id prefixes that another test compares with the code (for example sounds generated by running the audio code). |
| `numbersBacked(ontology, { measured?, ignore? })` | Every number in entity `properties` is backed: by `properties.constants` (skipped; `constantsMatch` checks it), by a test that lists its path (`"<entity id>.<property path>"`, prefixes match whole segments: `"boss"`, `"slope."`) in `measured`, or by one evidence string of the same entity that contains it as a whole number. A small integer (below 10) counts only when that evidence string also names the property (its name or a camelCase word of four or more letters, case-, `_`- and `-`-insensitive), so a stray `2` elsewhere does not back `refill: 2`. Telegraph `probe` data is skipped; `ignore` skips further top-level property keys. Call it after the tests that fill `measured`. |
| `cssRules(css)` | The CSS as a flat list of rules `{ index, selectors, body, declarations, atRules }`, comments removed, `@keyframes` skipped. |
| `checkComponents(tokens, css)` | Each component and variant `selector` has a rule with exactly that selector. Each colour or gradient token it names is set (with `var(--x)` substituted) in a rule for that selector, its states, compounds or descendants (`:hover`, `.a.b`, `.a span`), but not in a pseudo-element rule (`::before`, `::after`, `::backdrop`, legacy `:before`) unless the selector itself names that pseudo-element. When the token key is a CSS colour property in camelCase or kebab-case (`background`, `backgroundColor`, `border`, `borderColor`, `color`, `outline`, `boxShadow`, `textShadow`, `caretColor`, `accentColor`, `filter`, ...), the colour must be in that property, its shorthand or a longhand (`background` ~ `background-color`, `border` ~ `border-top-color`); `text` means `color` and `shadow` means `box-shadow`, `text-shadow` or `filter`. Any other key (`edge`, `knob`, `glow`, `fill`) is a design name and may be in any declaration. Finally, no variant declaration may be overridden by its component's rule that wins the cascade (equal specificity and later in the file, higher specificity, or `!important`). |
| `constantsMatch(ontology, modules, { min? })` | `properties.constants` deep-equal the exports of the given module namespace(s); `min` guards against an empty check. |
| `containsExact(text, needle)` | The whole-token match used for evidence. |

```js
import * as GAME from '../src/game.js';
import { translations } from '../src/i18n.js';
import { checkComponents, constantsMatch, cssColourInventory, entitiesOf, localeParity, numbersBacked, setEquals, valueEvidence } from '@tidyeval/game-platform/design';
const measured = new Set(); // simulation tests add the property paths they check

test('hazard entities are exactly the hazard kinds', () => assert.deepEqual(setEquals(Object.keys(GAME.HAZARDS), entitiesOf(ontology, 'Hazard').map(e => e.id), 'Hazard entities'), []));
test('every locale has every key', () => assert.deepEqual(localeParity(translations, { keys: usedKeys }), []));
test('css colours are tokens', () => assert.deepEqual(cssColourInventory(css, tokens, { '#00000055': 'drop shadow' }), []));
test('components match the css', () => assert.deepEqual(checkComponents(tokens, css), []));
test('constants match the code', () => assert.deepEqual(constantsMatch(ontology, GAME, { min: 10 }), []));
test('token values are quoted', () => assert.deepEqual(valueEvidence(tokens, { measured: ['sound.'] }), []));
// Last, after the tests that call measured.add('<entity id>.<property>'):
test('numbers are backed', () => assert.deepEqual(numbersBacked(ontology, { measured }), []));
```

## Game-neutral examples

A hazard with a telegraph, a stage contract and a character (`ontology.json`):

```json
{ "id": "spike", "concept": "Hazard", "description": "Ceiling spike that drops when the hero passes below.",
  "properties": {
    "constants": { "SPIKE": { "dropSpeed": 900, "damage": 1 } },
    "telegraph": { "channels": ["{sound.wind}", "dust falls", "spike shakes"], "announce": "phase:shake", "danger": "phase:drop", "leadSeconds": 0.6, "leadFrom": "SPIKE.shake", "colour": "{color.button.danger}", "probe": { "heroX": 200 } } },
  "evidence": [{ "file": "src/hazards.js", "contains": "function updateSpike" }] },
{ "id": "contract.stage", "concept": "Contract", "description": "Fields and limits every stage must satisfy.",
  "properties": { "fields": ["id", "names", "theme", "waves"], "optionalFields": ["boss"], "minWarningSeconds": 1.5 },
  "evidence": [{ "file": "src/stages.js", "contains": "export const STAGES" }] },
{ "id": "hero", "concept": "Hero", "description": "The player character.", "evidence": [{ "file": "src/hero.js", "contains": "class Hero" }] },
{ "id": "glider", "concept": "Ability", "status": "planned", "description": "Gliding over gaps; designed, not built.", "evidence": [{ "file": "docs/plan.md", "contains": "## Glider" }] }
```

A rule checked partly by a browser test:

```json
{ "id": "menu-reachable", "statement": "The pause menu is reachable with one tap.",
  "check": { "test": "tests/menu.spec.mjs", "name": "pause opens with one tap", "runner": "playwright", "covers": "partial", "gap": "Native apps are checked by hand." } }
```

A component with variants, a character, a sample sound and a haptic (`tokens.json`):

```json
"tokens": {
  "color.button": { "type": "color", "value": "#ffdc86", "evidence": [{ "file": "src/style.css", "contains": "#ffdc86" }] },
  "color.button.danger": { "type": "color", "value": "#e2483d", "evidence": [{ "file": "src/style.css", "contains": "#e2483d" }] },
  "color.stage.tint": { "type": "color", "value": "none" },
  "sound.pop": { "type": "sound", "value": { "kind": "sample", "file": "public/sfx/pop.mp3", "gain": 0.8 }, "evidence": [{ "file": "src/audio.js", "contains": "'sfx/pop.mp3'" }] },
  "sound.wind": { "type": "sound", "value": { "kind": "noise", "duration": 1.2, "filter": { "type": "lowpass", "hz": 600 } }, "evidence": [{ "file": "src/audio.js", "contains": "function wind" }] },
  "haptic.hit": { "type": "haptic", "value": { "web": [30, 20, 30], "native": "Heavy" }, "evidence": [{ "file": "src/haptics.js", "contains": "hit: { web: [30, 20, 30]" }] }
},
"components": [
  { "id": "button", "selector": ".button", "description": "Main action button.", "tokens": { "background": "{color.button}" },
    "variants": [{ "id": "danger", "selector": ".button-danger", "description": "Destructive action.", "tokens": { "background": "{color.button.danger}" } }],
    "evidence": [{ "file": "src/style.css", "contains": ".button {" }] }
],
"characters": [
  { "id": "hero.look", "entity": "hero", "palette": { "body": "{color.button}" }, "proportions": { "headToBody": 0.6 },
    "expressions": [{ "id": "happy", "description": "Smiles after a catch.", "evidence": [{ "file": "src/hero.js", "contains": "mood = 'happy'" }] }],
    "evidence": [{ "file": "src/hero.js", "contains": "function drawHero" }] }
]
```

## Adopting it in a game

1. Adopt the package version that exports `./design` (0.3.6 for all helpers below) as usual: vendored archive, `package.json` and lockfile.
2. Create `design/ontology.json` and `design/tokens.json` from the real code. Give every entity, literal token, component and character evidence. Describe unbuilt or dropped things only with a `status` other than `built`.
3. Map each decided principle to an existing test by its exact name, add a focused test, or mark it `manual` with a reason; mark tests that cover only part of it `"covers": "partial"` with the gap.
4. Add `tests/design.test.js` that runs `checkDesignFiles` and the cross-checks: the shared helpers for the mechanical parts, the game's own code for the rest.
5. Prove the checks bite: rename an evidence symbol, remove a translation, add an unknown kind, and confirm the test fails with a clear message; then revert.

### What stays game-owned

The package owns only mechanics: the file format, the validator and the helpers above. The game owns everything with meaning: its concepts and entities, the lists it compares (which code set is "the hazard kinds", which keys the page uses), colour exceptions and their reasons, contract numbers and the tests that enforce them, telegraph simulations, and rules such as "the boss fight is a duel". There is no shared vocabulary of concepts, no registry and no DSL: the files never drive gameplay, rendering or data loading.
