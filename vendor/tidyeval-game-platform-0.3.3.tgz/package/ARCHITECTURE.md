# Shared games architecture

## Objective and scope

Agreed direction, 2026-11-10: one maintained implementation for platform mechanics across Schnabelglück Bucht, Bounce & Boo and Santa’s Meltdown; independently testable gameplay and separately installable/deployable games. User clarification, 2026-11-10: new Phaser + Matter editions live in separate `*-phaser-matter` worktrees. All previous game worktrees, releases, storage namespaces and native app identities remain intact. The original Schnabelglück, Bucht test and isolated playground/lab remain untouched.

Baseline: platform code copied across three games; Bucht and Bounce own requestAnimationFrame loops, and Bucht separately runs Phaser effects. Target for this change: one Phaser-owned loop and real Matter movement/collision in each experimental game, three real lifecycle/PWA consumers, three real attempt-ledger consumers, and no sibling dependency in a fresh build. Check through source ownership, production browser runs and isolated `npm ci`/build. Device performance remains an acceptance gap until measured on hardware; no efficiency gain is claimed.

## Ownership and interfaces

- Phaser owns the scene lifecycle and scheduling in Bucht/Bounce. A game supplies `create(scene)` and `update(now, seconds)`. Fixed timesteps and direct Canvas vector rendering remain game-owned. Matter owns physical integration and collision; controllers retain game rules such as swim speed, hopping, wall kicks and damage. The shared `matter` module exposes the same Phaser-bundled engine to browser and DOM-free tests. No second physics library is installed. Bucht’s effects camera and world drawing use the same scroll. HTML controls and accessible dialogs stay outside the scene.
- `bindLifecycle` owns browser/native focus and gesture registration. Games supply their suspend, foreground and audio activation actions. Returning to the foreground never resumes a paused round automatically. Native back actions remain game-specific.
- `createProgressStore` owns ledger writes, replay and preference merge. Games own keys, schema migration, validation and idempotent `apply`. Exceptions reach the game’s existing visible error handling; failed snapshots retain attempts for retry. Santa keeps its own backend and progress owner.
- `setupPwa` owns install and update state. Downloaded workers wait; games call the returned action only in their menu with no open dialog. Explicit activation is a deliberate user action. Workers keep their existing game/scope cache namespaces, network-first navigation with bounded offline fallback, and cached versioned assets. First installation does not reload the page.
- Audio synthesis, music mixing, haptics choices, movement controllers, scores, levels, artwork and UI remain game-owned. Shared lifecycle provides audio activation/suspension. No generic game inheritance hierarchy, level DSL, backend, editor or registry is added. No shared registry exists in these game repositories.
- Versioned vendored npm archives keep each game independently buildable. Source is edited here; releases are adopted explicitly. Phaser is pinned to 4.2.1. Each new native app has a separate identifier; each web edition uses a new storage/cache namespace and its own hosting scope. Deployment workflows are disabled in the experimental worktrees. Santa uses its local backend with experiment-specific keys; no existing online scores are written.

## Verification

Reference: committed pre-change game behavior, existing model/browser suites and preserved storage keys. Proposed migration criteria implement the user-approved direction, without claiming new gameplay features.

1. All existing model tests and production builds pass. Existing fish routes, bounce control rules and storage migrations provide the comparison. Matter integration changes are calibrated explicitly; the old solver cannot be retained as a fallback. Original files and saved data must remain unchanged.
2. Chromium and WebKit: real keyboard/pointer input, catch/jump, pause, focus loss, settings, resume, restart and durable progress. Check rendered pixels and simulation separately during pause. No application-owned recursive animation loop remains in Bucht/Bounce.
3. Package controls: a normal ledger save/merge passes; duplicate retry adds nothing; failed snapshot throws and later retry banks once. A blocked storage read must propagate, rather than masquerade as a malformed entry. Browser/native lifecycle must suspend and dispose registrations. Removing the suspend registration must make the corresponding check fail.
4. Real two-build update tests: install, delayed public-file-only update, no activation during gameplay/dialog, menu activation, old saves retained, unrelated origin caches retained and offline relaunch. Root and Pages subpaths must work. A manifest-only change must change the cache version; identical input must not.
5. Fresh isolated game checkout with only its tracked package archive: `npm ci` and production build pass without the source package directory.

Automated checks establish technical behavior, not subjective game feel or GPU/battery cost on phones. Record actual results and remaining gaps here after execution.

## Current implementation and next work (2026-11-10)

The three separate Phaser + Matter editions share `@tidyeval/game-platform` 0.2.3. The package is private and adopted through the same vendored archive in each game. Version 0.2.3 refreshes package documentation; its runtime and type files are unchanged from 0.2.2. Original game revisions are recorded in `original-games.json`. Original sources, installation identities, saved data and deployed releases remain separate. No commit, push or deployment has been made.

- **Schnabelglück Bucht:** one Phaser loop controls world drawing and effects. Pip's native Matter body integrates movement; terrain and net shapes use Matter queries. Restart removes the previous body. The adventure, oxygen, energy, catches, levels and artwork stay game-owned.
- **Bounce & Boo:** the scene's Matter engine integrates a compound torso and centre foot. Native contacts resolve terrain, solids, ceilings and one-way platforms; game rules retain hopping, steps and wall kicks. Convex terrain strips avoid internal triangulation edges, while the leading shoulder preserves real bank clearance. Actual floor penetration resolves through the foot contact. Standing contact follows moving platforms. Contact refresh discards old position impulses; an immobile wall contact cannot trigger another kick. Restart/respawn removes the previous bodies and listener. No manual movement/collision solver remains as a fallback.
- **Santa’s Meltdown:** Phaser owns scheduling and timers. Native bodies resolve Santa, trees, pillars and movable rocks; enemy AI and combat remain game-owned. The sled uses native terrain contacts, gravity, jumps and landings. Level transitions dispose previous physics. Pause freezes both modes and delayed actions. The experimental score backend is local and uses separate keys.

The DOM-free test adapters supply the same geometry to Matter as the game, and discard native contacts when rewinding a look-ahead branch. Scripted players were calibrated for real ceilings and moving platforms: approach the graveyard slab from the side; use the roof edge when climbing frozen orbs; discard commands from the previous boss phase. A predicted target landing now matches the actual bot's immediate replanning there, instead of requiring an extra 1.1 seconds on a blinking platform. Full completion, coin, route, obstacle, event and nine-boss-hit assertions remain in place. No level geometry or completion assertions were removed to obtain passing tests.

### Source verification

| Check | Result |
| --- | --- |
| Shared `./check` | Six package checks, including the missing-suspend negative control; original revision/clean-worktree and installation/cache isolation |
| Bucht `npm test` | 67 passed |
| Bounce `npm test` | 396 passed, including composed routes, all boss phases and native-physics regressions |
| Santa `npm test` | 12 passed |
| Production builds | All three pass; Phaser bundles produce Vite's size advisory |
| Shared browser lifecycle | All three in Chromium and WebKit: actual input, paused world/effect pixels, suspended audio, focus loss and resume |
| Bucht adventure | All four stages in Chromium and WebKit, one banking per attempt, replay, reload and offline |
| Bounce browser suite | Menu/settings/save retry, intro, long level, graveyard, root hosting and scoped offline/update flow |
| Santa mode checks | Chromium/WebKit: top-down movement, sled transition and jump, pause, focus loss, resume/restart and original-score preservation |

A first Bounce browser run timed out on an enemy stomp under concurrent test load; isolated controlled and real-time reruns passed. The current whole browser suite is the release check. The graveyard exit fixture opens the gate and allows the designed 4.5-second walk/fade/light sequence rather than teleporting behind a closed gate with a three-second limit.

### Archive adoption and reproducible checks

Pack this source once, copy the same `tidyeval-game-platform-0.2.3.tgz` to every edition's `vendor/`, and update each dependency/lockfile explicitly. Compare the packaged and installed source/type bytes with the source owner. Remove an obsolete task-created archive only after all consumers have adopted the replacement.

After adopting an archive, run `./check`, `node tests/platform-browser.mjs`, `node tests/pwa-browser.mjs` and `node tests/standalone-builds.mjs` here. Previews are on ports 4183 (Bucht), 4184 (Bounce) and 4185 (Santa). The PWA suite builds and switches two real production versions at a Pages subpath, checking manifest-only version changes, gameplay/dialog deferral, menu activation, retained saves/unrelated caches and offline restart. Standalone checks copy each source to an isolated folder and run normal `npm ci` and production build without sibling source or node_modules. `GAME=<edition>` selects one standalone/PWA consumer; `GAME=bucht|bounce|santa` selects a lifecycle case.

Physical-phone GPU/battery use, native Android/iOS builds and subjective game feel are not established by these automated checks. No efficiency gain is claimed. Existing releases stay intact while the experimental editions are assessed on real devices.


## Accepted outcome objectives (2026-11-11)

This section supersedes the migration-only acceptance scope above. Objective 16 (additional accessibility work) was explicitly excluded by the user; existing accessibility must be preserved. The original eleven technical protections remain required. Historical passes above are not evidence for a later changed build.

| ID | Required outcome | Release acceptance / evidence |
| --- | --- | --- |
| 1 | Durable, identifiable playable test releases | Stable local URLs, immutable build snapshots, source/build fingerprints, every referenced asset loads, actual browser input; reconnect in a separate process after server setup and after the tool session. Previous accepted snapshot remains reachable. |
| 2+3 | Protect originals and ship each edition independently | `./check`: original revision and clean state match `original-games.json`; distinct source, app IDs, saves and caches. Device install/update/uninstall must not affect originals or sibling editions. |
| 4+5 | One maintained technical owner makes fixes reusable | Same versioned archive/source bytes in all three consumers; Phaser schedules gameplay and Matter integrates/resolves bodies. Existing Matter negative control remains mandatory. Adopt shared fixes explicitly; independently build each consumer. |
| 6 | Preserve established behavior and improve feel deliberately | All model and applicable real-browser suites pass; document intentional rule changes with before/after situations and player evidence. No weakening assertions to obtain a pass. |
| 7+9 | Progress survives faults and version changes | Duplicate retries, multiple tabs, read/write failures, older and malformed saves, abrupt close, two production versions, deferred updates and offline relaunch. Valid recoverable records and foreign caches survive. Rollback is tested with actual old/new builds and retained progress. |
| 8 | Interruptions behave predictably | Frozen simulation/render/audio, cleared held inputs, explicit resume, disposed bodies/listeners. On hardware: screen lock, app switch and audio interruption without progress loss, surprise audio or unfair death. |
| 10 | Reproducible delivery and rollback per game | Isolated lockfile/archive `npm ci` + production build; fingerprinted installable artifacts; previous local snapshot can be selected again. Native build and installation evidence is separate from web build evidence. |
| 11 | Measured quality on agreed physical hardware | Minimum matrix: one midrange Android phone with Chrome/native Android, one iPhone with Safari/native iOS; exact models/OS recorded before acceptance. Target 60 fps; at least 95% frames <=20 ms and 99% <=50 ms over a 5-minute representative run, first usable menu <=3 seconds warm and <=5 seconds cold, no crash or unbounded memory growth over 20 minutes. These are proposed initial budgets, not measured achievements. Record thermal/battery observations and portrait/landscape behavior. |
| 12 | First success without explanation | Five unfamiliar people per game; >=4 achieve an intentional first success within two minutes without hints. Use PLAYER-ACCEPTANCE.md. |
| 13 | Defeat is legible and fair | Testers explain cause and a plausible next action after each sampled failure; inspect hitboxes, warnings, difficulty transitions and retry delay. Record contradictions as defects, not tester mistakes. |
| 14 | A concrete reason to return | Each game states its mastery/discovery/progression loop; observe voluntary next rounds and ask about actual return after several days. No synthetic retention claims. |
| 15 | Complete content sustains the experience | Inventory all stages/bosses/transitions and new decisions; complete every intended route with no dead end or unfinished section. Automated bots establish reachability; human play establishes variety and pacing. |
| 17 | Reproducible local error context | User-accessible diagnostic report includes build, environment, current situation and bounded errors without saves/personal data; no automatic remote transmission. Inject an error and reproduce from captured context. |

### Evidence discipline and pending acceptance

Every new result must record date, game, source/build fingerprint, command or human protocol, environment and artifact/result. A model pass does not establish feel; desktop emulation does not establish physical-device performance. Source revision alone does not identify these dirty experimental worktrees: record content fingerprints as well. No remote publication is authorized by this implementation request.

Implementation baseline on 2026-11-11: shared `./check` passes all six package tests and original/edition isolation. Physical-device and unfamiliar-player acceptance is open. Do not label a release accepted until each applicable row has direct evidence.


### Local diagnostics (0.2.4)

The shared diagnostics module collects a bounded in-memory list of uncaught error categories and the game-supplied situation. Each game exposes a localized, selectable report in settings with its version, bundled build fingerprint and coarse device context. Messages, stacks and URLs are excluded; nothing is sent automatically. Human acceptance and physical-device checks remain open.


### Final technical checks for 0.2.4, 2026-11-11

These results supersede the in-progress bullets above. The packaged documentation remains the historical snapshot at archive creation; runtime/type source bytes match all installed consumers.

- All three consumers use the identical 0.2.4 archive, SHA-256 `ba70cf84f3b9b42d5a2fb7061694ad53e4bd996f3caf30700cb1fdd69c1bb7d0`. Installed `src/` bytes match the source owner. Final isolated lockfile/archive installs and builds passed for all three (`test-results/standalone-final-20261111.log`).
- Shared `./check` passes including original/native identity isolation. Diagnostics UI passes Chromium and WebKit for every game: injected error category/location captured, actual build hash present, private error message omitted, report selectable.
- Production update AND rollback, with retained progress/foreign caches and offline restart, pass for every game (`test-results/pwa-rollback-20261111.log`).
- Santa now uses the shared attempt ledger as the third consumer. Its previous adapter silently swallowed write failures, and its result UI claimed success in the error path. Failures now reach a visible retry action; a stable attempt ID and retained ledger prevent duplicate credit. Snapshot failure/restart, stale services, corrupt snapshot and retries after 102 attempts pass. Santa model suite now has 13 passing tests.
- Bucht/Bounce Chromium and WebKit tests close the page after a successful ledger append and failed snapshot, reopen with malformed snapshot, and recover without duplicate credit (`tests/storage-recovery-browser.mjs`). Santa also passes Chromium/WebKit recovery through real enemy-damage game-over and actual submission UI: visible quota failure, exactly one successful retry, then score recovery after closing/reopening with corrupted snapshot.
- Final web assets were synchronized and all three Android debug builds passed with 0.2.4, including Santa's storage correction. Artifact application IDs, sizes and SHA-256 hashes: `test-results/native-20261111.json`. All three iOS attempts failed because the iOS 26.4 Xcode platform is missing. No device installation is claimed.
- Local preview persistence/snapshots and rollback commands: [LOCAL-PREVIEWS.md](LOCAL-PREVIEWS.md). These URLs are accessible only on this Mac; no public deployment was performed.

Post-session check: all three final fingerprints responded from a new tool session on 2026-11-11. Stable-preview rollback to the earlier snapshot and back also passes for all three games, retaining a valid language preference. LaunchAgent running/manual restart observed; no reboot or fresh-login test. Remaining acceptance: human first-success/fairness/content/return sessions; physical-device interruption, installation and performance; final iOS build/installation evidence; complete Santa journey and sled finish demonstration. Objective 16 remains excluded. The overall objective is not complete.


Verification maintenance: `./check` now also runs `tests/package-adoption.mjs`, comparing every archived file with its installed bytes, lockfile SHA-512 integrity, equal archive SHA-256 across all consumers, explicit version adoption and maintained runtime/type source bytes. It passes for all three 0.2.4 consumers. The source-owner block metadata includes the diagnostics contract; released archive metadata/docs retain their creation-time snapshot.


Additional iOS environment checks: explicit installed iOS 26.2 simulator destination and generic simulator destination both fail before compilation. A direct target build with simulator SDK 26.4 passes Swift/framework work but fails storyboard compilation in `ibtool` with “iOS 26.4 Platform Not Installed”. SDK file presence is therefore not proof of an installed usable platform. Logs: `/tmp/bucht-ios-explicit.log`, `/tmp/bucht-ios-generic-simulator.log`, `/tmp/bucht-ios-target.log`. No complete usable iOS app was produced.


The iOS environment blocker was subsequently resolved on 2026-11-11: `xcodebuild -downloadPlatform iOS -architectureVariant arm64` installed the iOS 26.4 (23E244) simulator component successfully. The download was monitored with an 8 GiB minimum-free-space guard; installation finished with about 16 GiB free. The three final unsigned simulator builds are now running; successful installation of a platform component is not yet a successful app build or device test. Earlier failure logs remain historical evidence.


All three final iOS simulator builds subsequently passed with `CODE_SIGNING_ALLOWED=NO`, using the newly installed platform. Actual app-bundle identifiers match the separate experimental IDs. Evidence: `test-results/ios-builds-20261111.json`; build logs `/tmp/{schnabelglueck,bounce-and-boo,santas-meltdown}-final-ios-20261111.log`. Earlier platform failures are resolved. Simulator installation/launch and physical-device acceptance remain separate gates.


Native asset verification: `tests/native-assets.py` compares current production bytes with the Android APK and built iOS app (13 Bucht, 22 Bounce, 45 Santa runtime files). Pass log: `test-results/native-assets-20261111.log`. Santa also has a tracked editor backup `sprite-walking.png~`: the existing Android aapt `!*~` rule excludes it; its iOS bytes were checked separately. It is not referenced by game source/HTML/CSS, and no source backup was deleted. Native installation tests remain distinct from this package-content check.


Full-content runtime evidence, 2026-11-11: Bucht's final-build `node tests/adventure.mjs` passes all four real-input stages in Chromium AND WebKit, including exactly-once banking, replay, reload and offline restart. Log: `test-results/bucht-adventure-final-20261111.log`. Santa's seeded sled finish is demonstrated in both engines using normal firing, dash, grenade and jump controls; no teleport, damage bypass or level shortening. Retained test: `tests/santa-completion-browser.mjs`. Santa's journey/boss still needs completion evidence.

All three iOS apps installed and launched on an isolated iOS 26.4 simulator, and private-container markers survived restart and same-build reinstall. This verifies container retention, not game-progress retention or a cross-version native update. Evidence: `test-results/ios-smoke-20261111-9810/results.json`. Bucht/Bounce menus render; Santa's initial screenshot shows its portrait rotation prompt, so its native landscape/start flow remains under test. No existing simulator was modified.


Native build retention: six content-addressed baseline artifacts (three APKs and three simulator `.app.zip` archives) are retained under `test-results/native-artifacts-20261111/`, with SHA-256, sizes and paths in `manifest.json`. This preserves the successful build baseline independently of temporary Xcode build folders. These artifacts precede the subsequent Santa read-only diagnostic snapshot extension; Santa must be resynchronized/rebuilt before calling a later source state native-verified.

The iOS simulator touch/rotation follow-up could not run because computer-use reported a locked Mac and automatic unlock failed. No lock bypass was attempted. Existing installation/launch/container checks stand, but Santa's native landscape/start and actual native gameplay remain unverified. Manual unlock is needed for that UI route; physical-device acceptance remains open regardless.


Android native acceptance evidence (emulator only): all three apps installed/launched, actual touch started play, Home/background returned to paused state, and explicit resume worked. Bounce cleared held steering; Santa's paused physics stayed frozen. Bucht's attempt ended naturally soon after resume, so sustained gameplay is not established by that smoke. App-scoped logs had no fatal events. Reinstall retained Bucht's private marker; uninstalling Bounce left Bucht/Santa installed with markers, then Bounce was restored. `test-results/android-smoke-20261111/report.json` records exact APK hashes. A private marker establishes sandbox retention, not game-progress migration or hardware audio quality.

Concrete menu defect and correction: Santa's pause panel overflowed the short landscape viewport. The existing panel now has a viewport-relative maximum height and vertical scrolling. `tests/santa-pause-layout.mjs` fails on the old snapshot and passes Chromium/WebKit after the correction. Fresh Android and iOS builds pass; native packaged bytes match the current production files (`test-results/native-assets-snapshot-20261111.log`). The fresh Android follow-up scrolls the real pause panel and taps Restart, successfully returning to play; evidence `test-results/android-santa-pause-20261111/report.json`. The new local preview fingerprint is `382bab538650cc60ce964dea812e69168f93da27139718a8d630979b9a35bbc6`. The original six native artifacts plus two newer Santa artifacts are retained in the native manifest (eight total).

The isolated Android emulator was shut down after these checks; its task-created AVD and evidence are retained. Existing user AVDs were not touched. Reopen `GamePlatformAcceptance20261111` on port 5580 before running `tests/android-smoke.mjs`; the runner refuses a different AVD. `GAME=santa` selects only Santa, and `ANDROID_SMOKE_OUTPUT` selects a separate evidence directory to preserve a baseline.


Latest browser mode check: Chromium passed. One combined-run WebKit check failed the existing movement assertion; the unchanged assertion then passed an isolated rerun and three further sequential WebKit runs. Cause remains unverified; this is not a proven gameplay defect or an unconditional green result. The assertion now includes the full snapshot in its failure message for diagnosis (`tests/santa-browser.mjs`); logs are retained under `test-results/santa-modes-latest-20261111.log` and `santa-webkit-timing-*.log`.


## Objective acceptance audit (2026-11-11, still open)

| Objective | Current direct evidence | Remaining acceptance |
| --- | --- | --- |
| 1 | Three launchd previews, retained content-addressed snapshots, version endpoints, all production files and actual browser input; reopened across tool sessions. | Fresh login/reboot was not tested; URLs are Mac-local. |
| 2 | `./check` confirms original revisions and clean source worktrees; no publication performed. Original keys and caches stay separate. | Physical-device coexistence is tracked under 3; no original source or release was changed. |
| 3 | Distinct native IDs verified in built artifacts; three apps installed together on isolated Android/iOS simulators; sandbox isolation tested. | Physical-device original/new coexistence. |
| 4 | Same 0.3.3 archive, lock SHA-512, every archived/installed byte and maintained source/type bytes checked by `tests/package-adoption.mjs`. | Native durability integration results are recorded below. |
| 5 | Phaser-owned loops, Matter movement/contact model and browser checks, missing-Matter negative control. | Hardware calibration is covered under 11. |
| 6 | 67 Bucht, 396 Bounce and 14 Santa model tests; Bucht four-stage route and Santa complete route both engines; Bounce six WebKit scenarios; native/browser lifecycle and input checks. | Human feel and physical-device calibration remain open. Full-route evidence is version-specific; it is not a universal controller guarantee. |
| 7 | Three shared-store consumers; browser interrupted writes/reopen/duplicate retry tests; 0.3 native strict journal and startup/save UI integration. A real Android force-stop defect in 0.2.5 was found and retained. | Checked native file journal passes simulator termination/recovery tests below. Physical-device acceptance and Android cold launch without re-registration remain open. |
| 8 | Browser frozen pixels/simulation/audio/focus checks; native Android Home→paused→resume and cleared steering tested. | Physical lock/audio interruption; iOS touch route blocked by locked Mac. |
| 9 | Real two-production-version update AND rollback, menu/dialog deferral, retained progress/foreign caches, offline restart all three. | Native cross-version progress update is not established by same-build marker retention. |
| 10 | Three isolated lockfile/archive installs and production builds; Android/iOS simulator builds; retained native artifacts with hashes. | Signed physical-device delivery and installation. |
| 11 | Repeatable desktop timing baseline; Android/iOS simulator evidence. | Exact physical models/OS and 5-minute frame /20-minute stability/audio/touch measurements. |
| 12 | Game-specific first-success protocols and 4-of-5/two-minute target in `PLAYER-ACCEPTANCE.md`. | Five unfamiliar real players per game; no fabricated human results. |
| 13 | Scripted routes and loss/context traces; pause-control defect fixed from actual native screenshot. | Real players explain failures and confirm fair recovery. |
| 14 | Each game's existing mastery/progression/replay loop and 48–96h follow-up protocol inventoried. | Voluntary replay and actual later returns from real players. |
| 15 | Full Bucht route both engines; Bounce campaign/composed routes model coverage; Santa complete start→boss→sled→victory captured in Chromium and WebKit. | Human pacing, variety and voluntary replay acceptance. |
| 16 | Explicitly excluded from new work. Existing controls/accessibility preserved; clipping correction belongs to functional menus. | No additional accessibility programme is claimed. |
| 17 | Shared bounded local reports, actual repeated uncaught errors, build identifiers and selectable/private-message-free output tested both engines/all three. | Real-world bug reports may require additional reproduction details; no automatic transmission. |

The previous intermittent movement check is now causally diagnosed: a seeded tree blocked rightward travel while accepted input, visible/focused document, RAF and Matter time continued. Failure JSON/screenshot are in `test-results/santa-browser-diagnostics/`. The test retains its x/time assertions and uses a verified clear starting fixture (seed 1); three consecutive combined Chromium/WebKit runs and isolated runs pass. No game rules were changed. The captured blocker case happens in Chromium too; the original failing WebKit invocation lacked a snapshot, so that individual historical run cannot be reconstructed with certainty.

Santa full Chromium route proof: `test-results/santa-journey-chromium-2026-11-11.log` and `.meta` retain actual captured stdout and build `382bab538650cc60ce964dea812e69168f93da27139718a8d630979b9a35bbc6`. It proves one full normal-input route, not controller reliability or human acceptance. Two bounded WebKit controller attempts failed; their traces show fuel/range/positioning limits, not proof of an unreachable game. Further work must preserve the victory assertion and authored gameplay.


### First-install update notification correction (0.2.5)

Fresh Chromium and WebKit traces show the first service worker briefly occupies `registration.waiting` while no active worker exists, immediately before automatic activation. The previous shared handler therefore announced a nonexistent pending update on first install. `setupPwa` now requires an existing active worker before showing the menu-update notice. This preserves the real replacement-worker path and changes no game rules. Regression evidence before correction: `test-results/pwa-first-install-20261111/report.json`; retained verifier: `tests/pwa-first-install-browser.mjs`. The correction was packed once and adopted as 0.2.5; the previous 0.2.4 archive and playable snapshots remain intact. Consumer and two-production-version results are recorded below.


0.2.5 verification completed: archive SHA-256 `75ac5217b76f476a1ddc549fa1af7c5d54501f8113ede26295461b9da934e28a` is identical across all three consumers; `./check`, installed/archive/lock/source comparison, all production builds and fresh-install Chromium/WebKit checks pass. Pre-fix first-install evidence is retained; the six post-fix cases are in `test-results/pwa-first-install-0.2.5-20261111/report.json`. Real updates AND rollbacks pass for all three (`test-results/pwa-rollback-0.2.5-20261111.log`), as do isolated installs/builds (`test-results/standalone-0.2.5-20261111.log`). All six native builds and packaged-file comparisons also pass (`test-results/native-assets-0.2.5-20261111.log`). The native artifact manifest now retains 14 baseline/current artifacts without deleting prior versions. These artifacts precede any subsequent Santa visible-collider snapshot extension, which must be rebuilt separately.

Bounce's six browser cases now support `BROWSER=webkit` and all pass with unchanged assertions: menu, intro, graveyard, long level, hosted preview and PWA (`test-results/bounce-webkit-20261111/`). They combine real input with programmatic scenario setup; they are not a natural complete campaign playthrough. This closes the previously missing WebKit scenario coverage, while human play acceptance remains open.


Movement-fixture follow-up: the seed-1 fixture also encountered a blocker in a later WebKit run (`test-results/santa-browser-diagnostics/webkit-1794371276073.json`). The earlier tree diagnosis stands, but changing a global seed alone did not establish a stable clear-lane precondition. Santa's read-only snapshot now exposes only visible active obstacle hitboxes, its player hitbox and camera viewport. A geometry-based clear-corridor input check is being implemented with the same 600 ms hold and stronger relative-displacement / elapsed-Matter-time assertions. No world obstacles are removed and no movement/physics rules are changed. Current source needs the final Santa rebuild after this snapshot extension; 0.2.5 baseline native artifacts remain retained.


The visible-collider snapshot extension has now been rebuilt into Santa's Android and iOS simulator apps; both builds and all native packaged-byte checks pass (`test-results/native-assets-visible-0.2.5-20261111.log`). Local Santa fingerprint: `9c29f9107174eb8a57e9d1521d615e989a0357c62acbbdf7529291ec5046aa78`. Two additional content-addressed Santa artifacts are retained (16 native artifacts total), with no previous artifact deleted. This is a read-only observation change; it does not change input, collision resolution or damage rules.

The exploratory waypoint verifier also had a confirmed test-only defect: it omitted its primary obstacle from first-segment collision checks and could choose a cheaper far-side corner through that obstacle. The corrected helper checks all expanded hitboxes, supports outward contact escape, and retains corner clearance/viewport bounds. Focused checks cover the far-corner regression, outward contact, clear route and enclosed fallback. This explains a test-controller failure mode, not a game physics defect. The follow-up full-route attempt is still pending the movement-fixture run.


### Native progress durability correction (0.3.0)

An actual Android WebView force-stop exposed a confirmed gap in the localStorage ledger: a returned write could disappear on immediate termination. A five-second delay made the same scenario pass, so delayed tests are insufficient. Evidence is retained in `test-results/android-storage-recovery-20261111/` and `android-storage-recovery-settle-20261111/`. A separate native IndexedDB probe awaited strict transaction completion and retained both records after immediate force-stop (`android-idb-durability-20261111/first-run-report.json`). This is emulator evidence, not a physical-device guarantee.

The 0.3.0 interface makes all progress saves asynchronous. Native consumers must await journal hydration before enabling play and await the transaction before reporting success/navigation. One per-game database stores the canonical migrated baseline, attempt IDs and settings; readwrite transactions merge current durable state, validate computed progress before commit and refresh the cache from an independent stored clone. Old keys and foreign data are preserved. Legacy mirror failure still reports failure and offers an idempotent retry; the committed journal remains authoritative across termination. Browser consumers preserve their existing ledger behavior. A failed native initialization blocks play with an explicit reload action rather than saving defaults.

Focused Node and real Chromium/WebKit IndexedDB checks cover migration, concurrent writes, corruption and mirror failure, abort/retry, invalid/unserializable writes, and mutation of submitted DTOs. Packaging, consumer builds and actual native force-stop acceptance remain pending at this source snapshot. Historical 0.2.5 claims above do not establish the corrected native acceptance.


### 0.3.0 integration evidence (2026-11-11)

The same archive SHA-256 `9be3d8c08de27e09f1c5ba7e60d7f897864c4e9052d14257e1382fdef4e95e58` is now adopted by all three games. Shared `./check` passes, including original-source isolation and archive/lock/installed/source-byte comparison. Three standalone `npm ci`/production builds pass (`test-results/standalone-0.3.0-20261111.log`). All six Android/iOS simulator builds pass; all current production runtime files match the APK and iOS bundle (`test-results/native-assets-0.3.0-20261111.log`); the artifact manifest retains 24 artifacts including older versions.

Shared real IndexedDB checks pass in Chromium and WebKit (`storage-idb-0.3.0-20261111.log`), as do Santa's 14 models and focused normal-input/pause/restart checks (`santa-browser-0.3.0-20261111.log`). Native-stub startup/save checks cover blocked play during initialization, visible failure and reload recovery, no default progress writes, pending-save restart protection, missing randomUUID fallback, and same-ID retry after a mirror failure (`santa-native-hydration-2026-11-11.log`). These browser stubs do not replace native termination proof.

Fresh PWA installs pass all three games/both engines (`pwa-first-install-0.3.0-20261111/report.json`). The combined update/rollback run passed Bucht and then exposed an outdated Bounce fixture that opened a hidden settings button before asynchronous menu saving completed; its failure log is retained. The corrected fixture waits for the real menu transition, opens settings before the next safe frame, and asserts dialog visibility. Bounce and Santa two-production-version update/rollback/offline tests pass separately (`pwa-bounce-030-after.log`, `pwa-santa-030-after.log`).

Santa's full WebKit normal-input victory is captured in `santa-telegraph-webkit-seed2-2026-11-11.log`, metadata in `santa-telegraph-webkit-2026-11-11.meta`, on retained snapshot `21921ef2284c3844f2b8aed9b62f12d71ec78dcd4a35d4b855423b1fc89153f9`. This closes the earlier missing route proof; subsequent 0.3 changes affect persistence/startup and not authored game rules. The movement fixture is now geometry-verified with bounded real-input preparation, rather than depending on a global random seed.

Current local previews use 0.3.0 snapshots: Bucht `8f66720e2e915eeea4a6214fe4adeb9754c82db071b2dbf9615f693d2fcbf636`, Bounce `85ced0dc27ac2629eac63a081dbd5bfba046abf764039b857089df00c00fd35a`, Santa `a040a43ac8f8f8b547a2d9b63c353b65415e97d582e66a15e85b8029d9e63fb3`. All prior local snapshots remain retained. No external publication or original game modification was performed.


The final 0.3.0 browser recovery run passes all three games in Chromium and WebKit (`test-results/storage-recovery-all-0.3.0-20261111.log`), retaining once-only totals, snapshot failure/retry and malformed-primary recovery assertions. An earlier Bounce second-drain timeout did not recur in the instrumented or final run; its cause remains unverified. Failure captures now retain mode, focus, visibility, page errors and screenshot instead of silently increasing timeouts.

Current iOS simulator apps were reinstalled and launched on the retained owned simulator, then shut down (`test-results/ios-startup-0.3.0-20261111/report.json`). Screenshots confirm Bucht and Bounce menus after hydration; Santa shows its existing rotate-device overlay. This is startup evidence only. iOS touch/orientation/audio and physical-device acceptance remain open.


The actual 0.3.0 Android UI recovery test now passes on the retained APK SHA-256 `4327e99430b9b6eba0bd31204d367e1268beb8eae204b8f55594e503bfc8c89c` (`test-results/android-storage-recovery-0.3.0-immediate-final-20261111/report.json`). Three real runs raised the existing total from 6 to 9 exactly once. A successful save and an injected localStorage snapshot-mirror failure both survived immediate process termination and fresh app initialization through the authoritative journal. The verifier starts force-stop 0–1 ms after observing terminal UI status, with no intervening screenshot/database read; process stop completed 54–75 ms later. Polling observes UI status rather than measuring the exact app-side commit instant. This is Android 16 / WebView 128 emulator evidence, not physical-device or universal-WebView acceptance.

Earlier 0.3 verifier failures are retained separately: one selected the preceding successful attempt instead of the failed attempt; another compared a normalized progress object with a raw snapshot field. These were verifier defects, corrected before the passing acceptance run. No production assertion or game rule was weakened.

All three current previews were reopened from another process and return HTTP 200 with the recorded snapshot hashes (`test-results/local-previews-0.3.0-20261111.json`). The final common input/pause/focus/audio checks pass all three games in both engines (`platform-browser-0.3.0-20261111.log`).


**Native acceptance reopened:** subsequent runs contradict the first 0.3 native pass. In `test-results/android-storage-recovery-0.3.0-put-trace-20261111/failure.json`, the current native Android context reports a real `progress` readwrite transaction with `durability: strict`, an appended submission UUID and a complete event, followed by UI DONE. Immediate process termination and COLD relaunch return the preceding journal without that UUID. The trace is stronger than the earlier missing-attempt-only failures. The passing report remains retained, but it does not establish reliable durability. Root cause (runtime path, transaction lifecycle or WebView behavior) is under investigation; no fixed delay or weaker assertion is accepted as a correction. Do not mark objective 7 or native termination acceptance complete.


The retained LevelDB WAL now has a concrete structural explanation for the paired-probe failure: 18 CRC32C-valid FULL records end at byte 4884, followed by a zero header while 6,699 nonzero bytes remain in the same <32KiB block. The checksum-valid hidden tail contains the exact test DB metadata and submission UUID. Independent parser/self-check evidence is in `test-results/leveldb-wal-independent-check-20261111.py` and `.txt`, with the original raw archive unchanged. The [upstream LevelDB reader](https://raw.githubusercontent.com/google/leveldb/main/db/log_reader.cc) skips the rest of a block after a zero-type/zero-length header. This explains why strings alone overstated readable persistence; it does not establish the origin of the gap or durability on a fresh profile.

Before resetting only the owned acceptance Santa app for a fresh-profile check, the full private data were backed up and all 63 regular files verified with no missing/extra entries. The backup archive and an APFS clone of the emulator data overlay are retained under `test-results/android-fresh-profile-20261111/`; no original game, other package or user device was reset. Fresh-profile outcomes remain pending.


Fresh-profile counterexample: after the backed-up Santa-only reset, direct strict journal cycles 1–5 and a cold emulator reboot retained exact state. The first subsequent write (cycle 6, held-open connection) acknowledged completion but was missing after immediate app force-stop. Evidence is in `test-results/android-fresh-idb-20261111/progress.json` and its cycle-06 raw archive. Independent CRC32C inspection reproduces a zero header at byte 12271 followed by checksum-valid records from byte 12288, including the lost UUID (`leveldb-wal-fresh-cycle6-independent-20261111.{py,txt}`). The earlier damaged profile alone is therefore insufficient explanation. The same-origin LevelDB backing store is shared by game and diagnostic database connections, so closing only one fixture connection did not test full resource closure. A bounded clean-profile all-connections-closed versus held-open comparison is pending; source and packaged 0.3 remain unchanged.


### Checked native file journal (0.3.1, integration pending)

The clean, static-document close-all-connections case also lost an acknowledged post-cold-reboot IndexedDB write. This rejects simple connection closure as an adequate correction for the observed path. 0.3.1 therefore replaces the native write mechanism with `GameProgressJournal`, shipped inside this same private package. Existing game callers retain their asynchronous ready/save API, pending navigation guards and visible retry UI. Browser storage remains unchanged.

The native plugin owns key validation, a version/revision envelope, serialized per-process load/merge/commit, immutable attempt IDs, preference assignment and recovery. It uses app-private main and pending files; commits check writing, file sync, close, atomic same-directory rename and directory sync before resolving. A valid newer pending revision is promoted; a valid main record remains usable with an invalid pending record; no valid copy means an explicit initialization failure. Duplicate attempts still perform a checked commit, allowing a previously failed acknowledgement to be retried without counting again. No generic storage framework or extra native dependency was added.

JavaScript validates operations before native I/O, handles out-of-order replies monotonically, and mirrors legacy storage only after native commit. Initialization first loads an existing native record; otherwise it reads the previous native IndexedDB journal without writing it, merges visible legacy attempt records, and canonicalizes the game-owned baseline before first native commit. Existing files, source journal and foreign keys remain preserved. Bytes inaccessible through a damaged browser database cannot be reconstructed by this migration; forensic backups are retained for the isolated test profile.

Focused JavaScript tests and real Chromium/WebKit migration checks pass. Android production/instrumentation sources compile in an isolated Gradle fixture; iOS sources type-check against the real simulator SDK and pass focused host filesystem checks. These are preparatory results: final packaged discovery/linking, actual native fault/termination/cold-restart acceptance and physical-device tests remain open.


### Capacitor proxy integration correction (0.3.2 candidate)

The first 0.3.1 native-stub browser run found a real adapter error before native I/O: returning Capacitor's plugin proxy from an async function caused Promise resolution to call its generated `.then` plugin method. 0.3.2 returns a plain load/commit protocol object around the proxy instead. A focused missing-native-plugin negative check now verifies initialization rejects rather than hanging; all 16 common Node checks pass. 0.3.1 Android/iOS candidate linking builds succeeded, but its JavaScript adapter is not accepted. Final native/browser acceptance must use the corrected package.


### Native file-journal acceptance and test-runner packaging (0.3.2 / 0.3.3)

0.3.2's checked native file mechanism passes the previously failing boundaries. Android direct native commits survived ten immediate force-stop/reload cycles on one key/revision chain, split by a cold owned-AVD reboot (`android-filejournal-cycles-2026-11-11/progress.json` plus `android-filejournal-cycles-resume-0.3.2-20261111/report.json`). The emulator lost Santa's package registration at reboot; re-registering the identical APK with `adb install -r` exposed the exact pre-reboot revision-5 private file before app launch, then cycles 6–10 passed. This proves journal survival with re-registration, not normal cold-launch availability in that emulator.

The actual Santa UI three-round test passes: successful submit, snapshot-mirror failure with visible retry, immediate termination and recovery, followed by a new save counting all three IDs once (`android-filejournal-recovery-0.3.2-20261111/report.json`). The first two observed status→force-stop starts are 0–1ms; the third intentionally inspects its app-written mirror before termination. A pending-path directory fault showed failure, preserved main bytes and retried the identical ID once (`android-filejournal-pending-fault-0.3.2-20261111-retry2/report.json`). A separate read-only-directory case rejected during actual pending-file writing, preserved canonical bytes, restored exact permissions and committed the same ID once (`android-filejournal-write-failure-0.3.2-20261111/report.json`). Four pending/corrupt-file recovery cases pass (`android-filejournal-cases-0.3.2-20261111-retry2/report.json`).

The iOS simulator probe compiled the exact packaged Swift journal core for iOS and passed ten ACK→exact-process SIGKILL→fresh-process reads, a simulator shutdown/boot after five, and all four corrupt/pending-file cases (`journal-probe-acb80d42a73e456eac3b5f29ec24d67d.json`). The first probe used temporary storage cleared at reboot and is invalid; it is retained separately. Actual Bucht/Bounce/Santa iOS apps also installed/started the Capacitor plugin and preserved native journal bytes on restart (`ios-startup-0.3.2-20261111/report.json`). This is not a native iOS touch/audio or physical-device test; GUI control remains blocked by the locked Mac.

All three 0.3.2 Android apps pass install, real input, Home/pause/resume smoke checks (`android-smoke-0.3.2-preserve-20261111/report.json`). The destructive Bounce uninstall step was intentionally skipped to retain its private test data. Earlier isolation evidence and distinct compiled identifiers remain retained.

Three Android native instrumentation tests pass with production/test Java sources byte-identical to 0.3.2, but the first distributed test APK lacked its AndroidX runner and crashed before tests. 0.3.3 adds the explicit test-only `androidx.test:runner:1.7.0` dependency so those tests run directly from the package. Production JavaScript, Java, Swift and package interfaces are unchanged. The 0.3.2 archives and 30 native artifacts remain retained. Final 0.3.3 archive adoption, source equivalence, ordinary test APK execution and independent builds are checked after packaging.
