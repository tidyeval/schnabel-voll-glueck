export const DESIGN_FORMAT_VERSION: 1;
export const ONTOLOGY_FORMAT: 'tidyeval-design-ontology';
export const TOKENS_FORMAT: 'tidyeval-design-tokens';
export const TOKEN_TYPES: readonly string[];
/** Returns a game file's text, or null when it does not exist. */
export type DesignReader = (path: string) => string | null;
export function isColor(value: unknown): boolean;
export function validateOntology(doc: unknown, read: DesignReader): string[];
export function validateTokens(doc: unknown, read: DesignReader): string[];
export function validateDesign(docs: { ontology: unknown; tokens: unknown }, read: DesignReader): string[];
export function checkDesignFiles(root: string | URL): Promise<{ errors: string[]; ontology: unknown; tokens: unknown }>;
export function formatDesignErrors(errors: string[]): string;
