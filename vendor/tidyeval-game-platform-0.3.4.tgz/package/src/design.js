// Design ontology and design-token validation, format version 1 (see DESIGN-FORMAT.md).
// Deterministic and dependency-free: every problem is returned as an actionable message;
// nothing is thrown for malformed input. File access goes through a `read(path)` callback
// that returns the file's text, or null when the file does not exist.

export const DESIGN_FORMAT_VERSION = 1;
export const ONTOLOGY_FORMAT = 'tidyeval-design-ontology';
export const TOKENS_FORMAT = 'tidyeval-design-tokens';

const ID = /^[A-Za-z][A-Za-z0-9_.-]*$/;
const REFERENCE = /^\{([A-Za-z][A-Za-z0-9_.-]*)\}$/;
const NUMBER = '[-+]?(?:\\d+\\.?\\d*|\\.\\d+)';
const HEX = /^#(?:[0-9a-fA-F]{3,4}|[0-9a-fA-F]{6}|[0-9a-fA-F]{8})$/;
const RGB = new RegExp(`^rgba?\\(\\s*${NUMBER}\\s*,\\s*${NUMBER}\\s*,\\s*${NUMBER}\\s*(?:,\\s*${NUMBER}\\s*)?\\)$`);
const DIMENSION = new RegExp(`^${NUMBER}(?:px|cqw|cqh|%|em|rem|vw|vh|svh|dvh)$`);
const DIMENSION_FUNCTION = /^(?:clamp|min|max|calc)\(.+\)$/;
const DURATION = new RegExp(`^${NUMBER}(?:ms|s)$`);
const BEZIER = new RegExp(`^cubic-bezier\\(\\s*${NUMBER}\\s*,\\s*${NUMBER}\\s*,\\s*${NUMBER}\\s*,\\s*${NUMBER}\\s*\\)$`);
const EASINGS = ['linear', 'ease', 'ease-in', 'ease-out', 'ease-in-out'];
const WAVES = ['sine', 'triangle', 'square', 'sawtooth'];
export const TOKEN_TYPES = ['color', 'gradient', 'dimension', 'duration', 'number', 'fontFamily', 'fontWeight', 'easing', 'sound', 'string'];

const isObject = value => value !== null && typeof value === 'object' && !Array.isArray(value);
const text = value => typeof value === 'string' && value.trim() !== '';
const quote = value => JSON.stringify(value);

/** True for #rgb, #rgba, #rrggbb, #rrggbbaa, rgb(r,g,b) and rgba(r,g,b,a) with channels in range. */
export function isColor(value) {
  if (typeof value !== 'string') return false;
  if (HEX.test(value)) return true;
  if (!RGB.test(value)) return false;
  const parts = value.slice(value.indexOf('(') + 1, -1).split(',').map(Number);
  return parts.slice(0, 3).every(n => n >= 0 && n <= 255) && (parts.length === 3 || (parts[3] >= 0 && parts[3] <= 1));
}

function reporter(prefix) {
  const errors = [];
  return { errors, add: (where, message) => errors.push(`${prefix}${where ? ` ${where}` : ''}: ${message}`) };
}

function checkKeys(add, where, value, allowed) {
  for (const key of Object.keys(value)) if (!allowed.includes(key)) add(where, `unknown field ${quote(key)} (allowed: ${allowed.join(', ')})`);
}

function checkHeader(add, doc, format) {
  if (doc.format !== format) add('format', `must be ${quote(format)}, found ${quote(doc.format)}`);
  if (doc.version !== DESIGN_FORMAT_VERSION) add('version', `must be ${DESIGN_FORMAT_VERSION}, found ${quote(doc.version)}; this validator only understands format version ${DESIGN_FORMAT_VERSION}`);
  if (!text(doc.game)) add('game', 'must name the game (non-empty string)');
}

function safePath(path) {
  return text(path) && !path.startsWith('/') && !/^[A-Za-z]:/.test(path) && !path.split(/[\\/]/).includes('..');
}

// Reads each path once per validation; a failing reader is reported, not thrown.
function cachedReader(read) {
  const cache = new Map();
  return path => {
    if (!cache.has(path)) {
      let content = null, failure = null;
      try { content = typeof read === 'function' ? read(path) : null; } catch (error) { failure = error?.message || String(error); }
      cache.set(path, { content: typeof content === 'string' ? content : null, failure, missingReader: typeof read !== 'function' });
    }
    return cache.get(path);
  };
}

function checkFileContains(add, where, file, contains, read, what) {
  if (!safePath(file)) { add(where, `${what} file must be a relative path inside the game, found ${quote(file)}`); return; }
  if (!text(contains)) { add(where, `${what} needs a non-empty "contains" string that must occur in ${file}`); return; }
  const result = read(file);
  if (result.missingReader) add(where, `cannot verify ${file}: no read(path) function was supplied`);
  else if (result.failure) add(where, `cannot read ${file}: ${result.failure}`);
  else if (result.content === null) add(where, `${what} file ${file} does not exist; fix the path or remove the reference`);
  else if (!result.content.includes(contains)) add(where, `${file} does not contain ${quote(contains)}; ${what === 'evidence' ? 'update the evidence to the current code or restore the symbol' : 'use the exact current test name or restore the test'}`);
}

function checkEvidence(add, where, evidence, read, required) {
  if (evidence === undefined) { if (required) add(where, 'needs "evidence": a non-empty list of { "file", "contains" } pointing at the real code'); return; }
  if (!Array.isArray(evidence) || (required && evidence.length === 0)) { add(where, '"evidence" must be a non-empty list of { "file", "contains" }'); return; }
  evidence.forEach((entry, i) => {
    const at = `${where}.evidence[${i}]`;
    if (!isObject(entry)) { add(at, 'must be an object { "file", "contains" }'); return; }
    checkKeys(add, at, entry, ['file', 'contains', 'note']);
    checkFileContains(add, at, entry.file, entry.contains, read, 'evidence');
  });
}

function checkList(add, doc, key, required = true) {
  if (doc[key] === undefined && !required) return [];
  if (!Array.isArray(doc[key])) { add(key, 'must be a list'); return []; }
  return doc[key];
}

function registerIds(add, ids, list, kind) {
  list.forEach((item, i) => {
    if (!isObject(item)) { add(`${kind}[${i}]`, 'must be an object'); return; }
    if (typeof item.id !== 'string' || !ID.test(item.id)) add(`${kind}[${i}]`, `id ${quote(item.id)} must start with a letter and use only letters, digits, ".", "_" or "-"`);
    else if (ids.has(item.id)) add(`${kind}[${item.id}]`, `duplicate id (already used by ${ids.get(item.id)}); ids must be unique in the file`);
    else ids.set(item.id, kind);
  });
}

const label = (kind, item, i) => `${kind}[${typeof item?.id === 'string' ? item.id : i}]`;

/**
 * Validate a design ontology document.
 * @param {unknown} doc Parsed design/ontology.json.
 * @param {(path: string) => string | null} read Returns a game file's text or null.
 * @returns {string[]} Actionable errors; empty when valid.
 */
export function validateOntology(doc, read) {
  const { errors, add } = reporter('ontology');
  if (!isObject(doc)) { add('', 'must be a JSON object'); return errors; }
  const source = cachedReader(read);
  checkKeys(add, '', doc, ['format', 'version', 'game', 'description', 'concepts', 'entities', 'relationTypes', 'relations', 'rules']);
  checkHeader(add, doc, ONTOLOGY_FORMAT);
  const concepts = checkList(add, doc, 'concepts'), entities = checkList(add, doc, 'entities');
  const types = checkList(add, doc, 'relationTypes', false), relations = checkList(add, doc, 'relations', false), rules = checkList(add, doc, 'rules');
  const ids = new Map();
  registerIds(add, ids, concepts, 'concepts'); registerIds(add, ids, entities, 'entities');
  registerIds(add, ids, types, 'relationTypes'); registerIds(add, ids, rules, 'rules');
  const conceptById = new Map(concepts.filter(isObject).map(c => [c.id, c]));
  const entityById = new Map(entities.filter(isObject).map(e => [e.id, e]));
  const typeById = new Map(types.filter(isObject).map(t => [t.id, t]));

  concepts.forEach((concept, i) => {
    if (!isObject(concept)) return;
    const at = label('concepts', concept, i);
    checkKeys(add, at, concept, ['id', 'label', 'description', 'parent', 'evidence']);
    if (!text(concept.description)) add(at, 'needs a "description"');
    if (concept.parent !== undefined && !conceptById.has(concept.parent)) add(at, `parent ${quote(concept.parent)} is not a concept id`);
    checkEvidence(add, at, concept.evidence, source, false);
  });
  // Parent chains must end at a root concept.
  for (const concept of conceptById.values()) {
    const seen = new Set([concept.id]);
    for (let parent = concept.parent; parent !== undefined && conceptById.has(parent); parent = conceptById.get(parent).parent) {
      if (seen.has(parent)) { add(`concepts[${concept.id}]`, `parent chain forms a cycle through ${quote(parent)}`); break; }
      seen.add(parent);
    }
  }
  const isA = (conceptId, ancestor) => {
    for (let id = conceptId, steps = 0; id !== undefined && steps <= conceptById.size; id = conceptById.get(id)?.parent, steps++) if (id === ancestor) return true;
    return false;
  };

  entities.forEach((entity, i) => {
    if (!isObject(entity)) return;
    const at = label('entities', entity, i);
    checkKeys(add, at, entity, ['id', 'concept', 'label', 'description', 'properties', 'evidence']);
    if (!conceptById.has(entity.concept)) add(at, `concept ${quote(entity.concept)} is not a concept id`);
    if (entity.properties !== undefined && !isObject(entity.properties)) add(at, '"properties" must be an object');
    checkEvidence(add, at, entity.evidence, source, true);
  });

  types.forEach((type, i) => {
    if (!isObject(type)) return;
    const at = label('relationTypes', type, i);
    checkKeys(add, at, type, ['id', 'description', 'from', 'to']);
    if (!text(type.description)) add(at, 'needs a "description"');
    for (const end of ['from', 'to']) if (type[end] !== undefined && !conceptById.has(type[end])) add(at, `${end} ${quote(type[end])} is not a concept id`);
  });

  const conceptOf = id => entityById.get(id)?.concept ?? (conceptById.has(id) ? id : undefined);
  const triples = new Set();
  relations.forEach((relation, i) => {
    const at = `relations[${i}]`;
    if (!isObject(relation)) { add(at, 'must be an object { "from", "type", "to" }'); return; }
    checkKeys(add, at, relation, ['from', 'type', 'to', 'note', 'evidence']);
    const type = typeById.get(relation.type);
    if (!type) add(at, `type ${quote(relation.type)} is not declared in relationTypes`);
    for (const end of ['from', 'to']) {
      const id = relation[end], concept = conceptOf(id);
      if (concept === undefined) add(at, `${end} ${quote(id)} is not an entity or concept id`);
      else if (type?.[end] !== undefined && !isA(concept, type[end])) add(at, `${end} ${quote(id)} must be a ${type[end]} for relation type ${quote(type.id)} (it is a ${concept})`);
    }
    const key = `${relation.from}\u0000${relation.type}\u0000${relation.to}`;
    if (triples.has(key)) add(at, `duplicate relation ${relation.from} ${relation.type} ${relation.to}`);
    triples.add(key);
    checkEvidence(add, at, relation.evidence, source, false);
  });

  rules.forEach((rule, i) => {
    if (!isObject(rule)) return;
    const at = label('rules', rule, i);
    checkKeys(add, at, rule, ['id', 'statement', 'rationale', 'appliesTo', 'check', 'evidence']);
    if (!text(rule.statement)) add(at, 'needs a "statement"');
    if (rule.appliesTo !== undefined) {
      if (!Array.isArray(rule.appliesTo)) add(at, '"appliesTo" must be a list of entity or concept ids');
      else rule.appliesTo.forEach(id => { if (conceptOf(id) === undefined) add(at, `appliesTo ${quote(id)} is not an entity or concept id`); });
    }
    checkRuleCheck(add, at, rule.check, source);
    checkEvidence(add, at, rule.evidence, source, false);
  });
  return errors;
}

function checkRuleCheck(add, at, check, read) {
  const howTo = 'set "check" to { "test": "<test file>", "name": "<test name>" }, a list of those, or { "manual": "<why it cannot be automated>" }';
  if (check === undefined) { add(at, `has no check; ${howTo}`); return; }
  if (isObject(check) && 'manual' in check) {
    checkKeys(add, `${at}.check`, check, ['manual']);
    if (!text(check.manual) || check.manual.trim().length < 10) add(`${at}.check`, 'a manual check needs a reason of at least 10 characters explaining why it is not automated');
    return;
  }
  const list = Array.isArray(check) ? check : [check];
  if (!list.length) { add(at, `has an empty check list; ${howTo}`); return; }
  list.forEach((entry, i) => {
    const where = Array.isArray(check) ? `${at}.check[${i}]` : `${at}.check`;
    if (!isObject(entry) || !('test' in entry)) { add(where, howTo); return; }
    checkKeys(add, where, entry, ['test', 'name']);
    checkFileContains(add, where, entry.test, entry.name, read, 'check test');
  });
}

function checkTokenValue(add, at, type, value, resolveRef) {
  const ref = typeof value === 'string' ? value.match(REFERENCE) : null;
  if (ref) { resolveRef(ref[1], type, at); return; }
  switch (type) {
    case 'color': if (!isColor(value)) add(at, `${quote(value)} is not a colour (use #rgb, #rgba, #rrggbb, #rrggbbaa, rgb() or rgba())`); break;
    case 'gradient':
      if (!Array.isArray(value) || value.length < 2) { add(at, 'a gradient needs at least two stops [{ "at": 0..1, "color": ... }]'); break; }
      value.forEach((stop, i) => {
        if (!isObject(stop) || typeof stop.at !== 'number' || stop.at < 0 || stop.at > 1) add(`${at}[${i}]`, 'stop needs "at" between 0 and 1');
        else if (i && stop.at < value[i - 1]?.at) add(`${at}[${i}]`, 'stops must be in ascending "at" order');
        if (isObject(stop)) checkTokenValue(add, `${at}[${i}].color`, 'color', stop.color, resolveRef);
      });
      break;
    case 'dimension': if (!(typeof value === 'number' && Number.isFinite(value)) && !(typeof value === 'string' && (DIMENSION.test(value) || DIMENSION_FUNCTION.test(value)))) add(at, `${quote(value)} is not a dimension (number, or e.g. "12px", "4cqw", "clamp(...)")`); break;
    case 'duration': if (!(typeof value === 'string' && DURATION.test(value))) add(at, `${quote(value)} is not a duration (e.g. "0.32s" or "150ms")`); break;
    case 'number': if (typeof value !== 'number' || !Number.isFinite(value)) add(at, `${quote(value)} is not a finite number`); break;
    case 'fontWeight': if (!Number.isInteger(value) || value < 1 || value > 1000) add(at, `${quote(value)} is not a font weight (integer 1-1000)`); break;
    case 'easing': if (!(typeof value === 'string' && (EASINGS.includes(value) || BEZIER.test(value) || /^steps\(\d+(?:,\s*[a-z-]+)?\)$/.test(value)))) add(at, `${quote(value)} is not an easing (cubic-bezier(a,b,c,d), steps(n) or ${EASINGS.join('/')})`); break;
    case 'fontFamily': case 'string': if (!text(value)) add(at, 'must be a non-empty string'); break;
    case 'sound':
      if (!isObject(value) || !Array.isArray(value.notes) || !value.notes.length) { add(at, 'a sound needs { "notes": [{ "hz", "seconds", ... }] }'); break; }
      value.notes.forEach((note, i) => {
        const where = `${at}.notes[${i}]`;
        if (!isObject(note)) { add(where, 'must be an object'); return; }
        checkKeys(add, where, note, ['hz', 'seconds', 'volume', 'wave', 'delay', 'slideTo']);
        if (!(note.hz > 0)) add(where, '"hz" must be a positive number');
        if (!(note.seconds > 0)) add(where, '"seconds" must be a positive number');
        if (note.volume !== undefined && !(note.volume >= 0 && note.volume <= 1)) add(where, '"volume" must be between 0 and 1');
        if (note.wave !== undefined && !WAVES.includes(note.wave)) add(where, `"wave" must be one of ${WAVES.join(', ')}`);
        if (note.delay !== undefined && !(note.delay >= 0)) add(where, '"delay" must be zero or positive');
        if (note.slideTo !== undefined && !(note.slideTo > 0)) add(where, '"slideTo" must be a positive number');
      });
      break;
    default: break;
  }
}

/**
 * Validate a design tokens document (tokens, components, characters).
 * @param {unknown} doc Parsed design/tokens.json.
 * @param {(path: string) => string | null} read Returns a game file's text or null.
 * @returns {string[]} Actionable errors; empty when valid.
 */
export function validateTokens(doc, read) {
  const { errors, add } = reporter('tokens');
  if (!isObject(doc)) { add('', 'must be a JSON object'); return errors; }
  const source = cachedReader(read);
  checkKeys(add, '', doc, ['format', 'version', 'game', 'description', 'tokens', 'components', 'characters']);
  checkHeader(add, doc, TOKENS_FORMAT);
  const tokens = isObject(doc.tokens) ? doc.tokens : (add('tokens', 'must be an object mapping token ids to { "type", "value" }'), {});
  const components = checkList(add, doc, 'components', false), characters = checkList(add, doc, 'characters', false);

  const typeOf = id => isObject(tokens[id]) ? tokens[id].type : undefined;
  const resolveRef = (id, type, at) => {
    if (!Object.hasOwn(tokens, id)) add(at, `reference {${id}} does not name a token`);
    else if (type !== undefined && typeOf(id) !== type) add(at, `reference {${id}} is a ${typeOf(id)} token, expected ${type}`);
  };
  for (const [id, token] of Object.entries(tokens)) {
    const at = `tokens[${id}]`;
    if (!ID.test(id)) add(at, 'token id must start with a letter and use only letters, digits, ".", "_" or "-"');
    if (!isObject(token)) { add(at, 'must be an object { "type", "value" }'); continue; }
    checkKeys(add, at, token, ['type', 'value', 'description', 'evidence']);
    if (!TOKEN_TYPES.includes(token.type)) { add(at, `type ${quote(token.type)} is not one of ${TOKEN_TYPES.join(', ')}`); continue; }
    if (token.value === undefined) { add(at, 'needs a "value"'); continue; }
    checkTokenValue(add, `${at}.value`, token.type, token.value, resolveRef);
    const reference = typeof token.value === 'string' && REFERENCE.test(token.value);
    // Literal values must be traceable to the code; aliases inherit the evidence of their target.
    checkEvidence(add, at, token.evidence, source, !reference);
  }
  // Alias chains must end in a literal value.
  for (const id of Object.keys(tokens)) {
    const seen = new Set([id]);
    for (let value = tokens[id]?.value; typeof value === 'string' && REFERENCE.test(value);) {
      const next = value.match(REFERENCE)[1];
      if (seen.has(next)) { add(`tokens[${id}]`, `reference chain forms a cycle through {${next}}`); break; }
      seen.add(next); value = tokens[next]?.value;
    }
  }

  const ids = new Map(Object.keys(tokens).map(id => [id, 'tokens']));
  registerIds(add, ids, components, 'components'); registerIds(add, ids, characters, 'characters');
  const checkRefs = (at, map, what) => {
    if (!isObject(map)) { add(at, `"${what}" must be an object mapping names to token references like "{color.text}"`); return; }
    for (const [name, value] of Object.entries(map)) {
      const ref = typeof value === 'string' ? value.match(REFERENCE) : null;
      if (!ref) add(`${at}.${what}.${name}`, `must reference a token like "{color.text}", found ${quote(value)}`);
      else resolveRef(ref[1], what === 'palette' ? 'color' : undefined, `${at}.${what}.${name}`);
    }
  };
  components.forEach((component, i) => {
    if (!isObject(component)) return;
    const at = label('components', component, i);
    checkKeys(add, at, component, ['id', 'label', 'description', 'selector', 'entity', 'tokens', 'variants', 'evidence']);
    if (!text(component.description)) add(at, 'needs a "description"');
    checkRefs(at, component.tokens, 'tokens');
    if (component.variants !== undefined) {
      if (!Array.isArray(component.variants)) add(at, '"variants" must be a list');
      else {
        const seen = new Set();
        component.variants.forEach((variant, j) => {
          const where = `${at}.variants[${variant?.id ?? j}]`;
          if (!isObject(variant) || !text(variant.id)) { add(where, 'needs an "id"'); return; }
          if (seen.has(variant.id)) add(where, 'duplicate variant id');
          seen.add(variant.id);
          checkKeys(add, where, variant, ['id', 'label', 'description', 'selector', 'tokens', 'evidence']);
          checkRefs(where, variant.tokens, 'tokens');
          checkEvidence(add, where, variant.evidence, source, false);
        });
      }
    }
    checkEvidence(add, at, component.evidence, source, true);
  });
  characters.forEach((character, i) => {
    if (!isObject(character)) return;
    const at = label('characters', character, i);
    checkKeys(add, at, character, ['id', 'label', 'description', 'entity', 'palette', 'proportions', 'expressions', 'evidence']);
    checkRefs(at, character.palette, 'palette');
    if (character.proportions !== undefined) {
      if (!isObject(character.proportions)) add(at, '"proportions" must be an object of numbers');
      else for (const [name, value] of Object.entries(character.proportions)) if (typeof value !== 'number' || !Number.isFinite(value)) add(`${at}.proportions.${name}`, 'must be a finite number');
    }
    if (character.expressions !== undefined) {
      if (!Array.isArray(character.expressions)) add(at, '"expressions" must be a list');
      else character.expressions.forEach((expression, j) => {
        const where = `${at}.expressions[${expression?.id ?? j}]`;
        if (!isObject(expression) || !text(expression.id) || !text(expression.description)) { add(where, 'needs an "id" and a "description"'); return; }
        checkKeys(add, where, expression, ['id', 'description', 'evidence']);
        checkEvidence(add, where, expression.evidence, source, true);
      });
    }
    checkEvidence(add, at, character.evidence, source, true);
  });
  return errors;
}

/**
 * Validate both documents and the links between them.
 * @param {{ ontology: unknown, tokens: unknown }} docs
 * @param {(path: string) => string | null} read
 * @returns {string[]}
 */
export function validateDesign({ ontology, tokens }, read) {
  const errors = [...validateOntology(ontology, read), ...validateTokens(tokens, read)];
  if (!isObject(ontology) || !isObject(tokens)) return errors;
  if (ontology.game !== tokens.game) errors.push(`tokens game: ${quote(tokens.game)} must match the ontology's game ${quote(ontology.game)}`);
  const entityIds = new Set((Array.isArray(ontology.entities) ? ontology.entities : []).filter(isObject).map(e => e.id));
  for (const kind of ['components', 'characters']) {
    if (!Array.isArray(tokens[kind])) continue;
    tokens[kind].forEach((item, i) => {
      if (isObject(item) && item.entity !== undefined && !entityIds.has(item.entity)) errors.push(`tokens ${label(kind, item, i)}: entity ${quote(item.entity)} is not an entity id in the ontology`);
    });
  }
  return errors;
}

/**
 * Node helper: read `<root>/design/ontology.json` and `<root>/design/tokens.json` and validate them
 * with evidence paths resolved against `root`. JSON syntax errors are reported, not thrown.
 * @param {string | URL} root The game's root directory.
 * @returns {Promise<{ errors: string[], ontology: unknown, tokens: unknown }>}
 */
export async function checkDesignFiles(root) {
  const { readFileSync, existsSync } = await import('node:fs');
  const { fileURLToPath } = await import('node:url');
  const { join } = await import('node:path');
  const base = root instanceof URL ? fileURLToPath(root) : String(root);
  const read = path => existsSync(join(base, path)) ? readFileSync(join(base, path), 'utf8') : null;
  const load = file => {
    const content = read(file);
    if (content === null) return { error: `${file}: file not found under ${base}` };
    try { return { doc: JSON.parse(content) }; } catch (error) { return { error: `${file}: invalid JSON (${error.message})` }; }
  };
  const ontology = load('design/ontology.json'), tokens = load('design/tokens.json');
  const loadErrors = [ontology.error, tokens.error].filter(Boolean);
  if (loadErrors.length) return { errors: loadErrors, ontology: ontology.doc, tokens: tokens.doc };
  return { errors: validateDesign({ ontology: ontology.doc, tokens: tokens.doc }, read), ontology: ontology.doc, tokens: tokens.doc };
}

/** One line per error, for assertion messages. */
export function formatDesignErrors(errors) {
  return errors.length ? `${errors.length} design error(s):\n- ${errors.join('\n- ')}` : 'design files are valid';
}
