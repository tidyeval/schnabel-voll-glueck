# Design ontology and design tokens (format version 1)

Each game keeps its design knowledge in two game-owned JSON files. This package only provides the validator (`@tidyeval/game-platform/design`). The format is game-neutral: nothing in it is specific to one game. Ownership is described in [ARCHITECTURE.md](ARCHITECTURE.md#design-ontology-and-tokens-034).

```
<game>/design/ontology.json   what exists in the game and which design rules hold
<game>/design/tokens.json     how it looks, moves and sounds: tokens, components, characters
<game>/tests/design.test.js   runs the validator and the game's own cross-checks against code
```

Every factual statement points at the real code through **evidence**: `{ "file": "src/game.js", "contains": "CHASE = {" }`. The file path is relative to the game root, may not leave it, and the file must contain the string verbatim. Renaming or removing the symbol makes the design test fail, so the files cannot silently drift from the code. Prefer short, stable strings (a constant name, a function name, a CSS selector, a literal value).

Ids start with a letter and use letters, digits, `.`, `_` and `-`. Ids are unique within a file (concepts, entities, relation types and rules share one namespace; tokens, components and characters share another). Unknown fields are errors, so typos are caught.

## `design/ontology.json`

| Field | Required | Content |
| --- | --- | --- |
| `format` | yes | `"tidyeval-design-ontology"` |
| `version` | yes | `1` |
| `game` | yes | Game identifier; must equal `tokens.json`'s `game` |
| `description` | no | Free text |
| `concepts[]` | yes | `{ id, description, label?, parent?, evidence? }`: classes. `parent` must be a concept id; parent chains may not cycle. |
| `entities[]` | yes | `{ id, concept, label?, description?, properties?, evidence }`: instances of a concept. `evidence` is a non-empty list. `properties` is a free JSON object of real values (constants, timings, points). Where the code has an identifier (an item kind, a stage id), use it as the entity id so tests can compare both sets. |
| `relationTypes[]` | no | `{ id, description, from?, to? }`. Optional `from`/`to` concept ids constrain the endpoints (an entity of that concept or a sub-concept). |
| `relations[]` | no | `{ from, type, to, note?, evidence? }`: typed edges between entity or concept ids; duplicates are errors. |
| `rules[]` | yes | `{ id, statement, rationale?, appliesTo?, check, evidence? }`: design principles the team decided. |

A rule's `check` is one of:

- `{ "test": "tests/game.test.js", "name": "<test name>" }`: an automated check. The test file must exist and contain the name verbatim.
- a non-empty list of such objects, when several tests together establish the rule;
- `{ "manual": "<reason>" }`: not automated, with a reason of at least 10 characters (for example subjective feel or device-only behaviour).

## `design/tokens.json`

| Field | Required | Content |
| --- | --- | --- |
| `format` | yes | `"tidyeval-design-tokens"` |
| `version` | yes | `1` |
| `game` | yes | Same as the ontology |
| `description` | no | Free text |
| `tokens` | yes | Object `id → { type, value, description?, evidence? }`. Dotted ids group tokens (`color.button.primary`). |
| `components[]` | no | `{ id, description, label?, selector?, entity?, tokens, variants?, evidence }`. `tokens` maps a property name to a token reference. `variants[]` are `{ id, label?, description?, selector?, tokens, evidence? }`. `entity` must be an ontology entity id. |
| `characters[]` | no | `{ id, label?, description?, entity?, palette, proportions?, expressions?, evidence }`. `palette` maps a role to a colour token reference; `proportions` holds real numeric constants; `expressions[]` are `{ id, description, evidence }`. |

A token value is either a literal or a reference `"{other.token}"` to a token of the same type. Literal values need `evidence`; references inherit it. Reference chains may not cycle.

| Type | Literal value |
| --- | --- |
| `color` | `#rgb`, `#rgba`, `#rrggbb`, `#rrggbbaa`, `rgb(r,g,b)`, `rgba(r,g,b,a)` |
| `gradient` | `[{ "at": 0..1, "color": <color or reference> }, ...]`, at least two stops in ascending order |
| `dimension` | number, `"<n>px|cqw|cqh|%|em|rem|vw|vh|svh|dvh"`, or `clamp()/min()/max()/calc()` |
| `duration` | `"<n>s"` or `"<n>ms"` |
| `number` | finite number |
| `fontFamily`, `string` | non-empty string |
| `fontWeight` | integer 1–1000 |
| `easing` | `cubic-bezier(a,b,c,d)`, `steps(n)`, `linear`, `ease`, `ease-in`, `ease-out`, `ease-in-out` |
| `sound` | `{ "notes": [{ "hz", "seconds", "volume"?, "wave"?, "delay"?, "slideTo"? }] }`; `wave` is `sine`, `triangle`, `square` or `sawtooth` |

## Validator

```js
import { checkDesignFiles, formatDesignErrors } from '@tidyeval/game-platform/design';
const { errors } = await checkDesignFiles(new URL('../', import.meta.url)); // game root
assert.deepEqual(errors, [], formatDesignErrors(errors));
```

`validateOntology(doc, read)`, `validateTokens(doc, read)` and `validateDesign({ ontology, tokens }, read)` take parsed JSON and a `read(path)` callback that returns a file's text or `null`. They return a list of messages such as

```
ontology entities[shark].evidence[0]: src/game.js does not contain "case 'shark2'"; update the evidence to the current code or restore the symbol
```

The validator never throws for malformed input, and reports invalid JSON, missing files and failing readers as errors. It checks structure only. Whether the *content* matches the game (every encounter kind is an entity, every locale has every key, CSS colours come from tokens) is a game-specific cross-check in the game's `tests/design.test.js`.

## Adopting it in a game

1. Adopt the package version that exports `./design` (0.3.4 or later) as usual: vendored archive, `package.json` and lockfile.
2. Create `design/ontology.json` and `design/tokens.json` from the real code. Give every entity, literal token, component and character evidence. Do not describe features that do not exist.
3. Map each decided principle to an existing test by its exact name, add a focused test, or mark it `manual` with a reason.
4. Add `tests/design.test.js` that runs `checkDesignFiles` and the game's own cross-checks between the ontology and code.
5. Prove the checks bite: rename an evidence symbol, remove a translation, add an unknown kind, and confirm the test fails with a clear message; then revert.
