/** Mechanics only: the game owns validation, migration and attempt meaning. */
export function createProgressStore({ key, read, apply, durable = false }) {
  const prefix = `${key}-attempt:`;
  let database, journal, readyPromise;

  function legacy(storage) {
    const base = storage.getItem(key), attempts = {};
    for (let i = 0; i < storage.length; i++) {
      const entry = storage.key(i);
      if (!entry?.startsWith(prefix)) continue;
      const raw = storage.getItem(entry);
      try {
        const attempt = JSON.parse(raw);
        if (attempt && attempt.id === entry.slice(prefix.length) && typeof attempt.id === 'string' && attempt.id) Object.defineProperty(attempts, attempt.id, { value: attempt, enumerable: true, configurable: true, writable: true });
      } catch { /* Preserve malformed legacy entries without replaying them. */ }
    }
    return { base, attempts, settings: {} };
  }
  function progress(data) {
    const value = read(data.base);
    for (const attempt of Object.values(data.attempts)) apply(value, attempt);
    const settings = Object.entries(data.settings);
    for (const [name, setting] of settings) Object.defineProperty(value, name, { value: setting, enumerable: true, configurable: true, writable: true });
    return settings.length ? read(JSON.stringify(value)) : value;
  }
  function load(storage = localStorage) {
    if (durable && !journal) throw new Error('Progress journal is not ready; retry initialization');
    return progress(durable ? journal : legacy(storage));
  }
  function open() {
    if (database) return Promise.resolve(database);
    return new Promise((resolve, reject) => {
      let request, blocked = false;
      try { request = indexedDB.open(`${key}-journal`, 1); }
      catch (error) { reject(new Error('Cannot open the progress journal', { cause: error })); return; }
      request.onupgradeneeded = () => request.result.createObjectStore('progress');
      request.onblocked = () => { blocked = true; reject(new Error('Progress journal is blocked; close other game windows and retry')); };
      request.onerror = () => reject(new Error('Cannot open the progress journal; retry', { cause: request.error }));
      request.onsuccess = () => { if (blocked) { request.result.close(); return; } database = request.result; database.onversionchange = () => { database.close(); database = null; journal = null; }; resolve(database); };
    });
  }
  function transact(update) {
    return new Promise((resolve, reject) => {
      let transaction, result, failure;
      try { transaction = database.transaction('progress', 'readwrite', { durability: 'strict' }); }
      catch (error) { reject(new Error('Cannot start a durable progress transaction; retry', { cause: error })); return; }
      const store = transaction.objectStore('progress');
      const request = store.get('state');
      request.onsuccess = () => {
        try {
          result = update(request.result);
          JSON.stringify(progress(result));
          store.put(result, 'state');
          store.get('state').onsuccess = event => { result = event.target.result; };
        }
        catch (error) { failure = error; transaction.abort(); }
      };
      transaction.oncomplete = () => { journal = result; resolve(result); };
      transaction.onabort = () => reject(new Error('Progress journal could not be committed; retry', { cause: failure || transaction.error }));
      transaction.onerror = () => { /* onabort reports the failed transaction. */ };
    });
  }
  function ready(storage) {
    if (!durable) return Promise.resolve();
    storage ??= localStorage;
    if (readyPromise) return readyPromise;
    readyPromise = (async () => {
      await open();
      await transact(existing => {
        if (existing) return existing;
        const data = legacy(storage);
        data.base = JSON.stringify(progress(data));
        return data;
      });
    })().finally(() => { readyPromise = null; });
    return readyPromise;
  }
  return {
    ready, load,
    isKey: entry => entry === key || Boolean(entry?.startsWith(prefix)),
    async saveSetting(name, value, storage = localStorage) {
      if (JSON.stringify(value) === undefined) throw new Error('Cannot save a non-serializable setting');
      if (!durable) {
        const latest = load(storage); latest[name] = value;
        storage.setItem(key, JSON.stringify(latest));
        return latest;
      }
      if (!journal) throw new Error('Progress journal is not ready; retry initialization');
      const data = await transact(existing => {
        if (!existing) throw new Error('Progress journal baseline is missing');
        Object.defineProperty(existing.settings, name, { value, enumerable: true, configurable: true, writable: true });
        return existing;
      });
      const latest = progress(data);
      storage.setItem(key, JSON.stringify(latest));
      return latest;
    },
    async saveAttempt(attempt, storage = localStorage) {
      if (!attempt || typeof attempt.id !== 'string' || !attempt.id) throw new Error('Cannot save an attempt without an id');
      if (!durable) {
        storage.setItem(prefix + attempt.id, JSON.stringify(attempt));
        const latest = load(storage);
        storage.setItem(key, JSON.stringify(latest));
        return latest;
      }
      if (!journal) throw new Error('Progress journal is not ready; retry initialization');
      const data = await transact(existing => {
        if (!existing) throw new Error('Progress journal baseline is missing');
        if (!Object.prototype.hasOwnProperty.call(existing.attempts, attempt.id)) Object.defineProperty(existing.attempts, attempt.id, { value: attempt, enumerable: true, configurable: true, writable: true });
        return existing;
      });
      storage.setItem(prefix + attempt.id, JSON.stringify(attempt));
      const latest = progress(data);
      storage.setItem(key, JSON.stringify(latest));
      return latest;
    },
  };
}
